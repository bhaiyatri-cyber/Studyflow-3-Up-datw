import sys
with open('app/src/main/java/com/example/ui/screens/HomeScreen.kt', 'r') as f:
    for i, line in enumerate(f):
        print(f"{i}: {line}", end='')
