import re
with open("app/src/main/java/com/example/ui/screens/ProgressScreen.kt", "r") as f:
    content = f.read()

content = content.replace("actualTimeTakenMs ?: (it.endTimeMs - it.startTimeMs)", "actualTimeTakenMs ?: 0L")
content = content.replace("actualTimeTakenMs ?: (b.endTimeMs - b.startTimeMs)", "actualTimeTakenMs ?: 0L")

with open("app/src/main/java/com/example/ui/screens/ProgressScreen.kt", "w") as f:
    f.write(content)
