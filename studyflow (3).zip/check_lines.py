with open('app/src/main/java/com/example/ui/screens/HomeScreen.kt', 'r') as f:
    lines = f.readlines()

count = 0
for i, line in enumerate(lines):
    in_str = False
    escape = False
    for char in line:
        if escape:
            escape = False
            continue
        if char == '\\':
            escape = True
            continue
        if char == '"' and not in_str:
            in_str = True
            continue
        if char == '"' and in_str:
            in_str = False
            continue
        if not in_str:
            if char == '{':
                count += 1
            elif char == '}':
                count -= 1
    
    if i > 780 and i < 800:
        print(f"Line {i+1} balance: {count} | {line.strip()}")

