import sys
with open('app/src/main/java/com/example/ui/screens/ProgressScreen.kt', 'r') as f:
    content = f.read()

perf_score = '''
                // PERFORMANCE SCORE
                item {
                    val completedCount = todaysCompleted.size
                    val missedCount = todaysMissed.size
                    val totalTasks = todaysBlocks.size
                    val studyMins = todaysCompleted.sumOf { (it.endTimeMs - it.startTimeMs) / 60000 }
                    val studyHourGoal = viewModel.stats.collectAsState().value?.dailyStudyHourGoal ?: 4
                    val taskGoal = viewModel.stats.collectAsState().value?.dailyTaskGoal ?: 5
                    
                    var score = 0f
                    if (totalTasks > 0) {
                        val completionRate = completedCount.toFloat() / totalTasks
                        score += completionRate * 40 // Up to 40 points for completion rate
                    }
                    if (taskGoal > 0) {
                        val goalRate = (completedCount.toFloat() / taskGoal).coerceIn(0f, 1f)
                        score += goalRate * 30 // Up to 30 points for task goal
                    }
                    if (studyHourGoal > 0) {
                        val hours = studyMins / 60f
                        val studyRate = (hours / studyHourGoal).coerceIn(0f, 1f)
                        score += studyRate * 30 // Up to 30 points for study hour goal
                    }
                    
                    val finalScore = score.toInt()
                    val scoreColor = when {
                        finalScore >= 90 -> Color(0xFF4CAF50)
                        finalScore >= 70 -> Color(0xFF2196F3)
                        finalScore >= 50 -> Color(0xFFFF9800)
                        else -> Color(0xFFF44336)
                    }

                    Card(
                        modifier = Modifier.fillMaxWidth().padding(bottom = 24.dp),
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f))
                    ) {
                        Column(modifier = Modifier.padding(24.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                            Text("Daily Performance Score", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                            Spacer(modifier = Modifier.height(16.dp))
                            Box(modifier = Modifier.size(120.dp), contentAlignment = Alignment.Center) {
                                CircularProgressIndicator(progress = { 1f }, modifier = Modifier.fillMaxSize(), color = scoreColor.copy(alpha=0.1f), strokeWidth = 8.dp)
                                CircularProgressIndicator(progress = { score / 100f }, modifier = Modifier.fillMaxSize(), color = scoreColor, strokeWidth = 8.dp)
                                Text("$finalScore", style = MaterialTheme.typography.displayMedium, fontWeight = FontWeight.Bold, color = scoreColor)
                            }
                            Spacer(modifier = Modifier.height(8.dp))
                            val message = when {
                                finalScore >= 90 -> "Excellent work today!"
                                finalScore >= 70 -> "Good job, keep it up!"
                                finalScore >= 50 -> "You're getting there."
                                else -> "Let's try to focus more tomorrow."
                            }
                            Text(message, style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        }
                    }
                }
'''

content = content.replace(
    '// TODAY SECTION\n                item {\n                    Text("Today\'s Overview", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)',
    perf_score + '\n                // TODAY SECTION\n                item {\n                    Text("Today\'s Overview", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)'
)

with open('app/src/main/java/com/example/ui/screens/ProgressScreen.kt', 'w') as f:
    f.write(content)
