import os

code = """package com.example.ui.screens

import androidx.compose.animation.core.*
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.viewmodel.StudyViewModel
import com.example.data.model.TimeBlock
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale
import kotlin.math.roundToInt

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ProgressScreen(
    viewModel: StudyViewModel,
    onNavigateBack: () -> Unit
) {
    val allBlocks by viewModel.allBlocks.collectAsState()
    
    // CALCULATE REAL DATA
    val now = System.currentTimeMillis()
    val calendar = Calendar.getInstance()
    calendar.timeInMillis = now
    calendar.set(Calendar.HOUR_OF_DAY, 0)
    calendar.set(Calendar.MINUTE, 0)
    calendar.set(Calendar.SECOND, 0)
    val startOfToday = calendar.timeInMillis
    
    val evaluatedBlocks = allBlocks.map { block ->
        block.copy(status = com.example.util.ScheduleStatusEngine.calculateStatus(block, now))
    }
    
    // XP & LEVELS
    val completedBlocks = evaluatedBlocks.filter { it.status == "Completed" }
    val totalMins = completedBlocks.sumOf { (it.actualTimeTakenMs ?: (it.endTimeMs - it.startTimeMs)) } / 60000L
    val totalXP = (completedBlocks.size * 50) + totalMins.toInt()
    
    val currentLevel = (totalXP / 500) + 1
    val currentLevelXP = totalXP % 500
    val xpProgress = currentLevelXP.toFloat() / 500f
    
    // Subject Analytics
    val subjectsMap = completedBlocks.groupBy { it.subject }
    val subjectStats = subjectsMap.map { (subject, blocks) ->
        val timeMs = blocks.sumOf { it.actualTimeTakenMs ?: (it.endTimeMs - it.startTimeMs) }
        val sessions = blocks.size
        val avgDuration = if (sessions > 0) timeMs / sessions else 0L
        val lastStudied = blocks.maxOfOrNull { it.endTimeMs } ?: 0L
        
        // Find completion rate: Completed / (Completed + Missed)
        val allSubjBlocks = evaluatedBlocks.filter { it.subject == subject }
        val compCount = allSubjBlocks.count { it.status == "Completed" }
        val missedCount = allSubjBlocks.count { it.status == "Missed" }
        val completionRate = if (compCount + missedCount > 0) compCount.toFloat() / (compCount + missedCount) else 0f
        
        SubjectStat(subject, timeMs, sessions, avgDuration, completionRate, lastStudied)
    }.sortedByDescending { it.timeMs }
    
    val strongestSubject = subjectStats.firstOrNull()?.name ?: "None"
    val weakestSubject = subjectStats.lastOrNull()?.name ?: "None"
    
    // Goal Tracking
    // Using 4 hours as daily goal, 20 hours as weekly goal, 80 hours as monthly
    val todayCompletedMs = completedBlocks.filter { it.startTimeMs >= startOfToday }.sumOf { it.actualTimeTakenMs ?: (it.endTimeMs - it.startTimeMs) }
    val weekCompletedMs = completedBlocks.filter { it.startTimeMs >= startOfToday - 7L*24*3600*1000 }.sumOf { it.actualTimeTakenMs ?: (it.endTimeMs - it.startTimeMs) }
    val monthCompletedMs = completedBlocks.filter { it.startTimeMs >= startOfToday - 30L*24*3600*1000 }.sumOf { it.actualTimeTakenMs ?: (it.endTimeMs - it.startTimeMs) }
    
    val dailyGoalMs = 4 * 3600 * 1000L
    val weeklyGoalMs = 20 * 3600 * 1000L
    val monthlyGoalMs = 80 * 3600 * 1000L
    
    val dailyProgress = (todayCompletedMs.toFloat() / dailyGoalMs).coerceIn(0f, 1f)
    val weeklyProgress = (weekCompletedMs.toFloat() / weeklyGoalMs).coerceIn(0f, 1f)
    val monthlyProgress = (monthCompletedMs.toFloat() / monthlyGoalMs).coerceIn(0f, 1f)
    
    // Streak logic
    var currentStreak = 0
    val studyDays = completedBlocks.map { 
        val c = Calendar.getInstance()
        c.timeInMillis = it.startTimeMs
        c.set(Calendar.HOUR_OF_DAY, 0)
        c.set(Calendar.MINUTE, 0)
        c.set(Calendar.SECOND, 0)
        c.timeInMillis
    }.distinct().sortedDescending()
    
    if (studyDays.isNotEmpty()) {
        currentStreak = 1
        var previousDay = studyDays.first()
        for (i in 1 until studyDays.size) {
            if (previousDay - studyDays[i] <= 24 * 60 * 60 * 1000L + 1000L) {
                currentStreak++
                previousDay = studyDays[i]
            } else {
                break
            }
        }
    }
    
    val totalHours = totalMins / 60f
    
    // Badges
    val isFirstStep = completedBlocks.isNotEmpty()
    val is7DayStreak = currentStreak >= 7
    val is100Hours = totalHours >= 100
    val isMaster = totalHours >= 500
    val isDailyGoal = dailyProgress >= 1f
    val isWeeklyGoal = weeklyProgress >= 1f
    
    // Study Calendar Heatmap mode (7, 30, 365 days)
    var heatmapMode by remember { mutableStateOf(30) } // 7, 30, 365
    var selectedDate by remember { mutableStateOf<Long?>(null) }
    var selectedDayBlocks by remember { mutableStateOf<List<TimeBlock>>(emptyList()) }
    
    val generateHeatmap = { days: Int ->
        val data = mutableListOf<HeatmapDay>()
        for (i in days-1 downTo 0) {
            val dStart = startOfToday - (i * 24 * 60 * 60 * 1000L)
            val dEnd = dStart + (24 * 60 * 60 * 1000L)
            val dayBlocks = completedBlocks.filter { it.startTimeMs in dStart..dEnd }
            val time = dayBlocks.sumOf { it.actualTimeTakenMs ?: (it.endTimeMs - it.startTimeMs) }
            val intensity = when {
                time == 0L -> 0
                time < 1 * 3600 * 1000L -> 1
                time < 2 * 3600 * 1000L -> 2
                time < 4 * 3600 * 1000L -> 3
                else -> 4
            }
            data.add(HeatmapDay(dStart, intensity, time))
        }
        data
    }
    val heatmapData = generateHeatmap(heatmapMode)
    
    // Insights
    val dayMap = completedBlocks.groupBy { 
        val c = Calendar.getInstance()
        c.timeInMillis = it.startTimeMs
        c.get(Calendar.DAY_OF_WEEK)
    }
    val bestDayIndex = dayMap.maxByOrNull { it.value.sumOf { b -> b.actualTimeTakenMs ?: (b.endTimeMs - b.startTimeMs) } }?.key ?: 1
    val daysOfWeekStr = listOf("Sun", "Mon", "Tue", "Wed", "Thu", "Fri", "Sat")
    val bestDay = daysOfWeekStr[bestDayIndex - 1]
    
    val hourMap = completedBlocks.groupBy { 
        val c = Calendar.getInstance()
        c.timeInMillis = it.startTimeMs
        c.get(Calendar.HOUR_OF_DAY)
    }
    val bestHour = hourMap.maxByOrNull { it.value.sumOf { b -> b.actualTimeTakenMs ?: (b.endTimeMs - b.startTimeMs) } }?.key ?: 12
    val bestHourStr = if (bestHour == 0) "12 AM" else if (bestHour < 12) "$bestHour AM" else if (bestHour == 12) "12 PM" else "${bestHour-12} PM"
    
    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Progress & Analytics", fontWeight = FontWeight.Bold) },
                navigationIcon = {
                    IconButton(onClick = onNavigateBack) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back")
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = MaterialTheme.colorScheme.background
                )
            )
        }
    ) { padding ->
        LazyColumn(
            modifier = Modifier
                .padding(padding)
                .fillMaxSize()
                .background(MaterialTheme.colorScheme.background),
            contentPadding = PaddingValues(16.dp),
            verticalArrangement = Arrangement.spacedBy(24.dp)
        ) {
            
            // 2. XP & LEVELS SYSTEM
            item {
                Text("Your Level", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
                Spacer(modifier = Modifier.height(16.dp))
                Card(
                    modifier = Modifier.fillMaxWidth().shadow(8.dp, RoundedCornerShape(24.dp)),
                    shape = RoundedCornerShape(24.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
                ) {
                    Column(modifier = Modifier.padding(24.dp)) {
                        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Box(
                                    modifier = Modifier.size(56.dp).background(MaterialTheme.colorScheme.primaryContainer, CircleShape),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Icon(Icons.Default.Stars, contentDescription = null, modifier = Modifier.size(32.dp), tint = MaterialTheme.colorScheme.onPrimaryContainer)
                                }
                                Spacer(modifier = Modifier.width(16.dp))
                                Column {
                                    Text("Level $currentLevel", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
                                    Text("Scholar", style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.primary)
                                }
                            }
                            Text("$currentLevelXP / 500 XP", style = MaterialTheme.typography.labelLarge, fontWeight = FontWeight.Bold)
                        }
                        Spacer(modifier = Modifier.height(24.dp))
                        AnimatedLinearProgress(progress = xpProgress, color = MaterialTheme.colorScheme.primary)
                        Spacer(modifier = Modifier.height(8.dp))
                        Text("${500 - currentLevelXP} XP to Level ${currentLevel + 1}", style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                }
            }
            
            // 1. STUDY CALENDAR / HEATMAP
            item {
                Text("Study Calendar", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
                Spacer(modifier = Modifier.height(16.dp))
                Card(
                    modifier = Modifier.fillMaxWidth().shadow(8.dp, RoundedCornerShape(24.dp)),
                    shape = RoundedCornerShape(24.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
                ) {
                    Column(modifier = Modifier.padding(20.dp)) {
                        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                            Text("Activity Map", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                FilterChip(selected = heatmapMode == 7, onClick = { heatmapMode = 7; selectedDate = null }, label = { Text("7D") })
                                FilterChip(selected = heatmapMode == 30, onClick = { heatmapMode = 30; selectedDate = null }, label = { Text("30D") })
                                FilterChip(selected = heatmapMode == 365, onClick = { heatmapMode = 365; selectedDate = null }, label = { Text("1Y") })
                            }
                        }
                        Spacer(modifier = Modifier.height(16.dp))
                        
                        PremiumHeatmap(heatmapData, heatmapMode) { day ->
                            selectedDate = day.dateMs
                            val dStart = day.dateMs
                            val dEnd = dStart + (24 * 60 * 60 * 1000L)
                            selectedDayBlocks = evaluatedBlocks.filter { it.startTimeMs in dStart..dEnd }
                        }
                        
                        // Selected Date Info
                        if (selectedDate != null) {
                            val dateFormat = SimpleDateFormat("MMM dd, yyyy", Locale.getDefault())
                            Spacer(modifier = Modifier.height(24.dp))
                            HorizontalDivider(color = MaterialTheme.colorScheme.surfaceVariant)
                            Spacer(modifier = Modifier.height(16.dp))
                            Text(dateFormat.format(Date(selectedDate!!)), style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                            Spacer(modifier = Modifier.height(8.dp))
                            
                            val dayCompleted = selectedDayBlocks.count { it.status == "Completed" }
                            val dayMissed = selectedDayBlocks.count { it.status == "Missed" }
                            val dayTime = selectedDayBlocks.filter { it.status == "Completed" }.sumOf { it.actualTimeTakenMs ?: (it.endTimeMs - it.startTimeMs) }
                            
                            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceAround) {
                                MiniStat("Completed", "$dayCompleted")
                                MiniStat("Missed", "$dayMissed")
                                MiniStat("Hours", String.format("%.1f", dayTime / 3600000f))
                            }
                        }
                    }
                }
            }
            
            // 4. SMART STUDY INSIGHTS
            item {
                Text("Smart Insights", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
                Spacer(modifier = Modifier.height(16.dp))
                Card(
                    modifier = Modifier.fillMaxWidth().shadow(8.dp, RoundedCornerShape(24.dp)),
                    shape = RoundedCornerShape(24.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer)
                ) {
                    Column(modifier = Modifier.padding(24.dp)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Default.Insights, contentDescription = null, tint = MaterialTheme.colorScheme.onPrimaryContainer)
                            Spacer(modifier = Modifier.width(12.dp))
                            Text("Your Focus Trends", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.onPrimaryContainer)
                        }
                        Spacer(modifier = Modifier.height(20.dp))
                        InsightRow(Icons.Default.CalendarToday, "Best Study Day", bestDay)
                        InsightRow(Icons.Default.Schedule, "Most Productive Time", bestHourStr)
                        InsightRow(Icons.Default.Warning, "Weakest Subject", weakestSubject)
                        InsightRow(Icons.Default.TrendingUp, "Strongest Subject", strongestSubject)
                    }
                }
            }
            
            // 3. SUBJECT ANALYTICS
            item {
                Text("Subject Analytics", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
                Spacer(modifier = Modifier.height(16.dp))
                if (subjectStats.isEmpty()) {
                    Text("Complete tasks to see subject analytics.", color = MaterialTheme.colorScheme.onSurfaceVariant)
                } else {
                    subjectStats.forEach { stat ->
                        Card(
                            modifier = Modifier.fillMaxWidth().padding(bottom = 12.dp),
                            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                            elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
                        ) {
                            Column(modifier = Modifier.padding(16.dp)) {
                                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                                    Text(stat.name, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                                    Text(String.format("%.1f hrs", stat.timeMs / 3600000f), style = MaterialTheme.typography.titleMedium, color = MaterialTheme.colorScheme.primary, fontWeight = FontWeight.Bold)
                                }
                                Spacer(modifier = Modifier.height(12.dp))
                                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                                    Column {
                                        Text("Sessions", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                        Text("${stat.sessions}", style = MaterialTheme.typography.bodyLarge, fontWeight = FontWeight.Bold)
                                    }
                                    Column {
                                        Text("Avg. Session", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                        Text("${stat.avgDuration / 60000L}m", style = MaterialTheme.typography.bodyLarge, fontWeight = FontWeight.Bold)
                                    }
                                    Column {
                                        Text("Completion", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                        Text("${(stat.completionRate * 100).toInt()}%", style = MaterialTheme.typography.bodyLarge, fontWeight = FontWeight.Bold)
                                    }
                                }
                            }
                        }
                    }
                }
            }
            
            // 5. GOAL TRACKING
            item {
                Text("Goal Tracking", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
                Spacer(modifier = Modifier.height(16.dp))
                GoalCard("Daily Goal (4h)", dailyProgress, "${String.format("%.1f", todayCompletedMs/3600000f)} / 4 hrs")
                Spacer(modifier = Modifier.height(12.dp))
                GoalCard("Weekly Goal (20h)", weeklyProgress, "${String.format("%.1f", weekCompletedMs/3600000f)} / 20 hrs")
                Spacer(modifier = Modifier.height(12.dp))
                GoalCard("Monthly Goal (80h)", monthlyProgress, "${String.format("%.1f", monthCompletedMs/3600000f)} / 80 hrs")
            }
            
            // 6. BADGES / ACHIEVEMENTS
            item {
                Text("Milestone Badges", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
                Spacer(modifier = Modifier.height(16.dp))
                Card(
                    modifier = Modifier.fillMaxWidth().shadow(4.dp, RoundedCornerShape(24.dp)),
                    shape = RoundedCornerShape(24.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
                ) {
                    Column(modifier = Modifier.padding(20.dp)) {
                        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                            PremiumBadgeItem(icon = Icons.Default.DirectionsWalk, label = "First Step", isUnlocked = isFirstStep, progress = if (isFirstStep) 1f else 0f)
                            PremiumBadgeItem(icon = Icons.Default.LocalFireDepartment, label = "7 Day Streak", isUnlocked = is7DayStreak, progress = (currentStreak / 7f).coerceIn(0f, 1f))
                            PremiumBadgeItem(icon = Icons.Default.AccessTimeFilled, label = "100 Hours", isUnlocked = is100Hours, progress = (totalHours / 100f).coerceIn(0f, 1f))
                        }
                        Spacer(modifier = Modifier.height(24.dp))
                        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                            PremiumBadgeItem(icon = Icons.Default.Star, label = "Master", isUnlocked = isMaster, progress = (totalHours / 500f).coerceIn(0f, 1f))
                            PremiumBadgeItem(icon = Icons.Default.CheckCircle, label = "Daily Goal", isUnlocked = isDailyGoal, progress = dailyProgress)
                            PremiumBadgeItem(icon = Icons.Default.DateRange, label = "Weekly Goal", isUnlocked = isWeeklyGoal, progress = weeklyProgress)
                        }
                    }
                }
                Spacer(modifier = Modifier.height(32.dp))
            }
        }
    }
}

data class SubjectStat(val name: String, val timeMs: Long, val sessions: Int, val avgDuration: Long, val completionRate: Float, val lastStudied: Long)

data class HeatmapDay(val dateMs: Long, val intensity: Int, val timeMs: Long)

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun PremiumHeatmap(data: List<HeatmapDay>, mode: Int, onDayClick: (HeatmapDay) -> Unit) {
    val boxSize = if (mode == 365) 10.dp else if (mode == 30) 24.dp else 36.dp
    val spacing = if (mode == 365) 2.dp else 4.dp
    val primary = MaterialTheme.colorScheme.primary

    FlowRow(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.Start,
        maxItemsInEachRow = if (mode == 365) 26 else if (mode == 30) 10 else 7
    ) {
        data.forEach { day ->
            val color = when (day.intensity) {
                0 -> MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f)
                1 -> primary.copy(alpha = 0.3f)
                2 -> primary.copy(alpha = 0.6f)
                3 -> primary.copy(alpha = 0.8f)
                else -> primary
            }
            Box(
                modifier = Modifier
                    .padding(spacing)
                    .size(boxSize)
                    .clip(RoundedCornerShape(4.dp))
                    .background(color)
                    .clickable { onDayClick(day) }
            )
        }
    }
}

@Composable
fun InsightRow(icon: ImageVector, label: String, value: String) {
    Row(
        modifier = Modifier.fillMaxWidth().padding(vertical = 8.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Icon(icon, contentDescription = null, modifier = Modifier.size(20.dp), tint = MaterialTheme.colorScheme.onPrimaryContainer.copy(alpha = 0.8f))
            Spacer(modifier = Modifier.width(12.dp))
            Text(label, style = MaterialTheme.typography.bodyLarge, color = MaterialTheme.colorScheme.onPrimaryContainer)
        }
        Text(value, style = MaterialTheme.typography.bodyLarge, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.onPrimaryContainer)
    }
}

@Composable
fun GoalCard(title: String, progress: Float, valueStr: String) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                Text(title, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                Text(valueStr, style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
            Spacer(modifier = Modifier.height(12.dp))
            AnimatedLinearProgress(progress = progress, color = MaterialTheme.colorScheme.secondary)
            Spacer(modifier = Modifier.height(8.dp))
            if (progress >= 1f) {
                Text("Goal Completed!", style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.primary, fontWeight = FontWeight.Bold)
            } else {
                Text("${(progress * 100).toInt()}% completed", style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
        }
    }
}

@Composable
fun AnimatedLinearProgress(progress: Float, color: Color) {
    var animationPlayed by remember { mutableStateOf(false) }
    val currentProgress by animateFloatAsState(
        targetValue = if (animationPlayed) progress else 0f,
        animationSpec = tween(durationMillis = 1500),
        label = "progress"
    )
    LaunchedEffect(key1 = true) { animationPlayed = true }
    
    Box(modifier = Modifier.fillMaxWidth().height(8.dp).clip(CircleShape).background(color.copy(alpha = 0.2f))) {
        Box(modifier = Modifier.fillMaxWidth(currentProgress.coerceAtLeast(0.01f)).height(8.dp).clip(CircleShape).background(color))
    }
}

@Composable
fun PremiumBadgeItem(icon: ImageVector, label: String, isUnlocked: Boolean, progress: Float) {
    var animationPlayed by remember { mutableStateOf(false) }
    val currentProgress by animateFloatAsState(
        targetValue = if (animationPlayed) progress else 0f,
        animationSpec = tween(durationMillis = 1500),
        label = "badge"
    )
    LaunchedEffect(key1 = true) { animationPlayed = true }

    Column(horizontalAlignment = Alignment.CenterHorizontally, modifier = Modifier.width(80.dp)) {
        Box(
            modifier = Modifier.size(64.dp),
            contentAlignment = Alignment.Center
        ) {
            Canvas(modifier = Modifier.fillMaxSize()) {
                drawArc(
                    color = MaterialTheme.colorScheme.surfaceVariant,
                    startAngle = 0f, sweepAngle = 360f, useCenter = false,
                    style = Stroke(width = 6.dp.toPx(), cap = StrokeCap.Round)
                )
                if (currentProgress > 0) {
                    drawArc(
                        color = MaterialTheme.colorScheme.primary,
                        startAngle = -90f, sweepAngle = currentProgress * 360f, useCenter = false,
                        style = Stroke(width = 6.dp.toPx(), cap = StrokeCap.Round)
                    )
                }
            }
            Box(
                modifier = Modifier
                    .size(48.dp)
                    .clip(CircleShape)
                    .background(if (isUnlocked) MaterialTheme.colorScheme.primaryContainer else MaterialTheme.colorScheme.surfaceVariant.copy(alpha=0.5f)),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    icon,
                    contentDescription = null,
                    modifier = Modifier.size(24.dp),
                    tint = if (isUnlocked) MaterialTheme.colorScheme.onPrimaryContainer else MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        }
        Spacer(modifier = Modifier.height(8.dp))
        Text(
            label,
            style = MaterialTheme.typography.labelSmall,
            color = if (isUnlocked) MaterialTheme.colorScheme.onSurface else MaterialTheme.colorScheme.onSurfaceVariant,
            textAlign = TextAlign.Center
        )
    }
}

// Ensure the old MiniStat from the original is included to avoid unresolved reference if used anywhere else
@Composable
fun MiniStat(label: String, value: String) {
    Column(horizontalAlignment = Alignment.CenterHorizontally) {
        Text(value, style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary)
        Text(label, style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
    }
}
"""

with open("app/src/main/java/com/example/ui/screens/ProgressScreen.kt", "w", encoding="utf-8") as f:
    f.write(code)

