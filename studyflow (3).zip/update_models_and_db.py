import sys

# 1. Update TimeBlock
with open('app/src/main/java/com/example/data/model/TimeBlock.kt', 'r') as f:
    content = f.read()

if 'val isPinned: Boolean' not in content:
    content = content.replace(
        'val performanceRating: Int? = null // 1 to 5 stars',
        'val performanceRating: Int? = null, // 1 to 5 stars\n    val isPinned: Boolean = false'
    )
    with open('app/src/main/java/com/example/data/model/TimeBlock.kt', 'w') as f:
        f.write(content)

# 2. Update DailyStats
with open('app/src/main/java/com/example/data/model/DailyStats.kt', 'r') as f:
    content = f.read()

if 'val dailyStudyHourGoal' not in content:
    content = content.replace(
        'val lastStudyDateMs: Long = 0L',
        'val lastStudyDateMs: Long = 0L,\n    val dailyStudyHourGoal: Int = 4,\n    val dailyTaskGoal: Int = 5'
    )
    with open('app/src/main/java/com/example/data/model/DailyStats.kt', 'w') as f:
        f.write(content)

# 3. Update AppDatabase
with open('app/src/main/java/com/example/data/local/AppDatabase.kt', 'r') as f:
    content = f.read()

content = content.replace('version = 4', 'version = 5')

with open('app/src/main/java/com/example/data/local/AppDatabase.kt', 'w') as f:
    f.write(content)

# 4. Update StudyViewModel to include Migration
with open('app/src/main/java/com/example/ui/viewmodel/StudyViewModel.kt', 'r') as f:
    content = f.read()

migration_code = '''import androidx.room.migration.Migration
import androidx.sqlite.db.SupportSQLiteDatabase

val MIGRATION_4_5 = object : Migration(4, 5) {
    override fun migrate(db: SupportSQLiteDatabase) {
        db.execSQL("ALTER TABLE time_blocks ADD COLUMN isPinned INTEGER NOT NULL DEFAULT 0")
        db.execSQL("ALTER TABLE daily_stats ADD COLUMN dailyStudyHourGoal INTEGER NOT NULL DEFAULT 4")
        db.execSQL("ALTER TABLE daily_stats ADD COLUMN dailyTaskGoal INTEGER NOT NULL DEFAULT 5")
    }
}'''

if 'MIGRATION_4_5' not in content:
    content = content.replace('import androidx.room.Room', 'import androidx.room.Room\n' + migration_code)
    content = content.replace(
        '''.fallbackToDestructiveMigration().build()''',
        '''.addMigrations(MIGRATION_4_5).fallbackToDestructiveMigration().build()'''
    )
    with open('app/src/main/java/com/example/ui/viewmodel/StudyViewModel.kt', 'w') as f:
        f.write(content)

