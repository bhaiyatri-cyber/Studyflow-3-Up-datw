import re
with open("app/src/main/java/com/example/ui/screens/ChatScreen.kt", "r") as f:
    content = f.read()

target = """            val request = GenerateContentRequest(
                contents = history,
                systemInstruction = Content(
                    role = "system",
                    parts = listOf(Part(text = "You are Flow X AI, a helpful and encouraging study assistant. You help the user with math, science, and revision topics. Keep responses concise and formatted nicely for mobile readability."))
                )
            )"""

replacement = """            
            // Inject system instruction into the first user message to avoid 400 errors completely
            if (history.isNotEmpty() && history[0].role == "user") {
                val sysPrompt = "System: You are Flow X AI, a helpful and encouraging study assistant. You help the user with math, science, and revision topics. Keep responses concise and formatted nicely for mobile readability.\\n\\n"
                val firstText = history[0].parts.firstOrNull()?.text ?: ""
                val newFirstPart = Part(text = sysPrompt + firstText)
                history[0] = Content(role = "user", parts = listOf(newFirstPart))
            }
            
            val request = GenerateContentRequest(
                contents = history,
                systemInstruction = null
            )"""

if target in content:
    content = content.replace(target, replacement)
    print("Removed systemInstruction")

with open("app/src/main/java/com/example/ui/screens/ChatScreen.kt", "w") as f:
    f.write(content)
