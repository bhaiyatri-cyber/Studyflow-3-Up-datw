import re
with open("app/src/main/java/com/example/ui/screens/HomeScreen.kt", "r") as f:
    content = f.read()

target = """            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Default.Schedule, contentDescription = null, tint = contentColor.copy(alpha = 0.7f), modifier = Modifier.size(16.dp))
                Spacer(modifier = Modifier.width(6.dp))
                Text("${timeFormat.format(Date(block.startTimeMs))} - ${timeFormat.format(Date(block.endTimeMs))} ($durationMinutes min)", style = MaterialTheme.typography.bodyMedium, color = contentColor.copy(alpha = 0.9f))
            }
            if (isRunning) {
                var currentNow by remember { mutableStateOf(System.currentTimeMillis()) }
                LaunchedEffect(Unit) {
                    while (true) {
                        currentNow = System.currentTimeMillis()
                        kotlinx.coroutines.delay(1000)
                    }
                }
                Spacer(modifier = Modifier.height(16.dp))
                
                val elapsedMs = (currentNow - block.startTimeMs).coerceAtLeast(0L)
                val remainingMs = (block.endTimeMs - currentNow).coerceAtLeast(0L)
                val progress = (elapsedMs.toFloat() / durationMs.toFloat()).coerceIn(0f, 1f)
                
                val formatTaskTime = { ms: Long ->
                    val hours = ms / 3600000
                    val minutes = (ms / 60000) % 60
                    if (hours > 0) String.format(Locale.getDefault(), "%02dh %02dm", hours, minutes)
                    else String.format(Locale.getDefault(), "%02dm", minutes)
                }
                
                val elapsedStr = formatTaskTime(elapsedMs)
                val remainingStr = formatTaskTime(remainingMs)
                
                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                    Text("Elapsed: $elapsedStr", style = MaterialTheme.typography.labelMedium, color = Color.White.copy(alpha=0.8f))
                    Text("Remaining: $remainingStr", style = MaterialTheme.typography.labelMedium, color = Color.White, fontWeight = FontWeight.Bold)
                }
                Spacer(modifier = Modifier.height(6.dp))
                LinearProgressIndicator(
                    progress = { progress },
                    modifier = Modifier.fillMaxWidth().height(8.dp).clip(RoundedCornerShape(4.dp)),
                    color = Color.White,
                    trackColor = Color.White.copy(alpha = 0.3f),
                )
                Spacer(modifier = Modifier.height(4.dp))
                Text("${(progress * 100).toInt()}% Completed", style = MaterialTheme.typography.labelSmall, color = Color.White.copy(alpha=0.8f), modifier = Modifier.align(Alignment.End))
            }"""

replacement = """
            var currentNow by remember { mutableStateOf(System.currentTimeMillis()) }
            LaunchedEffect(Unit) {
                while (true) {
                    currentNow = System.currentTimeMillis()
                    kotlinx.coroutines.delay(1000)
                }
            }

            val currentStatus = com.example.util.ScheduleStatusEngine.calculateStatus(block, currentNow)
            val isCurrentRunning = currentStatus == "Running" || currentStatus == "Waiting"
            val isCurrentCompleted = currentStatus == "Completed"
            
            val timeStudiedMs = if (isCurrentCompleted) {
                block.actualTimeTakenMs ?: durationMs
            } else if (isCurrentRunning) {
                currentNow - block.startTimeMs
            } else {
                0L
            }
            
            val remainingMs = (durationMs - timeStudiedMs).coerceAtLeast(0L)
            val progress = if (durationMs > 0) (timeStudiedMs.toFloat() / durationMs.toFloat()).coerceIn(0f, 1f) else 0f
            
            val formatTaskTime = { ms: Long ->
                val hours = ms / 3600000
                val minutes = (ms / 60000) % 60
                if (hours > 0) String.format(Locale.getDefault(), "%02dh %02dm", hours, minutes)
                else String.format(Locale.getDefault(), "%02dm", minutes)
            }
            
            val scheduledStr = formatTaskTime(durationMs)
            val studiedStr = formatTaskTime(timeStudiedMs)
            val remainingStr = formatTaskTime(remainingMs)

            Spacer(modifier = Modifier.height(8.dp))
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Default.Schedule, contentDescription = null, tint = contentColor.copy(alpha = 0.7f), modifier = Modifier.size(16.dp))
                Spacer(modifier = Modifier.width(6.dp))
                Text("${timeFormat.format(Date(block.startTimeMs))} - ${timeFormat.format(Date(block.endTimeMs))}  |  Status: $currentStatus", style = MaterialTheme.typography.bodyMedium, color = contentColor.copy(alpha = 0.9f))
            }
            
            Spacer(modifier = Modifier.height(16.dp))
            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                Text("Scheduled: $scheduledStr", style = MaterialTheme.typography.labelMedium, color = contentColor.copy(alpha=0.8f))
                Text("Studied: $studiedStr", style = MaterialTheme.typography.labelMedium, color = contentColor.copy(alpha=0.8f))
                Text("Remaining: $remainingStr", style = MaterialTheme.typography.labelMedium, color = contentColor, fontWeight = FontWeight.Bold)
            }
            Spacer(modifier = Modifier.height(6.dp))
            LinearProgressIndicator(
                progress = { progress },
                modifier = Modifier.fillMaxWidth().height(8.dp).clip(RoundedCornerShape(4.dp)),
                color = contentColor,
                trackColor = contentColor.copy(alpha = 0.3f),
            )
            Spacer(modifier = Modifier.height(4.dp))
            Text("${(progress * 100).toInt()}%", style = MaterialTheme.typography.labelSmall, color = contentColor.copy(alpha=0.8f), modifier = Modifier.align(Alignment.End))
"""

if target in content:
    content = content.replace(target, replacement)
    print("Replaced target.")
else:
    print("Target not found.")

with open("app/src/main/java/com/example/ui/screens/HomeScreen.kt", "w") as f:
    f.write(content)
