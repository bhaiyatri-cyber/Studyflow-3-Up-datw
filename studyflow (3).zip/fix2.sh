sed -i '805d' app/src/main/java/com/example/ui/screens/HomeScreen.kt
sed -i '/item { Spacer(modifier = Modifier.height(80.dp)) }/a \            }\n        }\n    }\n    if (showCustomizeDialog) {' app/src/main/java/com/example/ui/screens/HomeScreen.kt
