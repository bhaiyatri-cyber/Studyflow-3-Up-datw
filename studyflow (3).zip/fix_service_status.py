import re
with open("app/src/main/java/com/example/service/TaskForegroundService.kt", "r") as f:
    content = f.read()

target = """                    val b = db.timeBlockDao().getBlockById(taskId)
                    if (b != null) {
                        db.timeBlockDao().updateBlock(b.copy(
                            actualTimeTakenMs = (b.actualTimeTakenMs ?: 0L) + tickDuration
                        ))
                    }
                } else {"""

replacement = """                    val b = db.timeBlockDao().getBlockById(taskId)
                    if (b != null) {
                        db.timeBlockDao().updateBlock(b.copy(
                            status = "Running",
                            actualTimeTakenMs = (b.actualTimeTakenMs ?: 0L) + tickDuration
                        ))
                    }
                } else {
                    val b = db.timeBlockDao().getBlockById(taskId)
                    if (b != null && b.status == "Running") {
                        db.timeBlockDao().updateBlock(b.copy(status = "Paused"))
                    }"""

if target in content:
    content = content.replace(target, replacement)
    print("Replaced status update in service")

target2 = """                val isStudying = if (studyAppsList.isEmpty()) {
                    isDeviceActive && foregroundApp == packageName
                } else {
                    isDeviceActive && foregroundApp != null && studyAppsList.contains(foregroundApp)
                }"""

replacement2 = """                val isStudying = if (studyAppsList.isEmpty()) {
                    isScreenDownAndStill
                } else {
                    isDeviceActive && foregroundApp != null && studyAppsList.contains(foregroundApp)
                }"""

if target2 in content:
    content = content.replace(target2, replacement2)
    print("Replaced isStudying logic")

with open("app/src/main/java/com/example/service/TaskForegroundService.kt", "w") as f:
    f.write(content)
