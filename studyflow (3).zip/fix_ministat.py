with open("app/src/main/java/com/example/ui/screens/ProgressScreen.kt", "r") as f:
    content = f.read()

# Fix unresolved reference in MiniStat
content = content.replace("color = premiumSkyBlue)", "color = Color(0xFF38BDF8))")

with open("app/src/main/java/com/example/ui/screens/ProgressScreen.kt", "w") as f:
    f.write(content)
