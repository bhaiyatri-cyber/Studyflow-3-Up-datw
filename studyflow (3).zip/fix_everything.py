import re
import os

# 1. Regenerate base file
os.system('python3 generate_progress_screen.py')

with open('app/src/main/java/com/example/ui/screens/ProgressScreen.kt', 'r') as f:
    content = f.read()

# 2. Setup imports and premiumSkyBlue
imports = """
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.rememberScrollState
"""
content = content.replace("import androidx.compose.foundation.layout.*", f"import androidx.compose.foundation.layout.*\n{imports.strip()}")

content = content.replace(
    "@OptIn(ExperimentalMaterial3Api::class)",
    "val premiumSkyBlue = Color(0xFF38BDF8)\n\n@OptIn(ExperimentalMaterial3Api::class)"
)
content = content.replace("MaterialTheme.colorScheme.primary", "premiumSkyBlue")
content = content.replace("val premiumSkyBlue = Color(0xFF38BDF8)", "") # Clean up any local declarations

# 3. Add AchievementBadge
components = """
@Composable
fun AchievementBadge(title: String, icon: ImageVector, color: Color) {
    Card(
        modifier = Modifier
            .size(100.dp)
            .shadow(4.dp, RoundedCornerShape(16.dp)),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.3f)),
        shape = RoundedCornerShape(16.dp)
    ) {
        Column(
            modifier = Modifier.fillMaxSize().padding(8.dp),
            verticalArrangement = Arrangement.Center,
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Icon(icon, contentDescription = null, tint = color, modifier = Modifier.size(32.dp))
            Spacer(modifier = Modifier.height(8.dp))
            Text(title, style = MaterialTheme.typography.labelMedium, fontWeight = FontWeight.Bold, textAlign = TextAlign.Center)
        }
    }
}
"""
if "fun AchievementBadge" not in content:
    content += "\n" + components

# 4. Inject Today's Focus and Lifetime Achievements
injection = """
            // 0. TODAY'S FOCUS & LIFETIME ACHIEVEMENTS
            item {
                val todaysBlocks = allBlocks.filter { it.startTimeMs >= startOfToday && it.startTimeMs < startOfToday + 24*3600*1000L }
                val completed = todaysBlocks.count { it.status == "Completed" }
                val total = todaysBlocks.size
                val progress = if (total > 0) completed.toFloat() / total else 0f
                
                Column(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Text("Today's Focus", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold, modifier = Modifier.align(Alignment.Start))
                    Spacer(modifier = Modifier.height(16.dp))
                    AnimatedCircularProgress(
                        progress = progress,
                        label = "Tasks Completed",
                        valueText = "$completed / $total",
                        primaryColor = premiumSkyBlue,
                        modifier = Modifier.align(Alignment.CenterHorizontally)
                    )
                    Spacer(modifier = Modifier.height(32.dp))
                    
                    Text("Lifetime Achievements", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold, modifier = Modifier.align(Alignment.Start))
                    Spacer(modifier = Modifier.height(16.dp))
                    Row(
                        modifier = Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()),
                        horizontalArrangement = Arrangement.spacedBy(16.dp)
                    ) {
                        AchievementBadge("7 Day Streak", Icons.Default.LocalFireDepartment, Color(0xFFFF9800))
                        AchievementBadge("100 Hours", Icons.Default.AccessTime, premiumSkyBlue)
                        AchievementBadge("Night Owl", Icons.Default.NightsStay, Color(0xFF7C4DFF))
                        AchievementBadge("Early Bird", Icons.Default.WbSunny, Color(0xFFFFC107))
                    }
                }
            }
"""
content = content.replace("            // 1. STUDY CALENDAR / HEATMAP", injection + "\n            // 1. STUDY CALENDAR / HEATMAP")

# 5. Inject Weekly Trend chart
weekly_trend_injection = """
            // 1.5 WEEKLY TREND CHART
            item {
                Text("Weekly Trend", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
                Spacer(modifier = Modifier.height(16.dp))
                Card(
                    modifier = Modifier.fillMaxWidth().shadow(8.dp, RoundedCornerShape(24.dp)),
                    shape = RoundedCornerShape(24.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
                ) {
                    val days = listOf("Mon", "Tue", "Wed", "Thu", "Fri", "Sat", "Sun")
                    val mockData = listOf(2.5f, 4.0f, 3.2f, 5.0f, 1.5f, 6.0f, 3.0f) // Represents hours
                    
                    Column(modifier = Modifier.padding(20.dp)) {
                        AnimatedBarChart(
                            data = mockData,
                            labels = days,
                            barColor = premiumSkyBlue
                        )
                    }
                }
            }
"""
content = content.replace("            // 2. XP & LEVELS SYSTEM", weekly_trend_injection + "\n            // 2. XP & LEVELS SYSTEM")

# 6. Revert Icons (if needed, but wait, the original generate_progress_screen.py already has standard Icons?)
content = content.replace("Icons.Default.TrendingUp", "Icons.AutoMirrored.Filled.TrendingUp")
content = content.replace("Icons.Default.DirectionsWalk", "Icons.AutoMirrored.Filled.DirectionsWalk")
content = content.replace("Icons.Default.ArrowBack", "Icons.AutoMirrored.Filled.ArrowBack")
content = content.replace("Icons.Default.KeyboardArrowLeft", "Icons.AutoMirrored.Filled.KeyboardArrowLeft")
content = content.replace("Icons.Default.KeyboardArrowRight", "Icons.AutoMirrored.Filled.KeyboardArrowRight")

# 7. Fix Canvas MaterialTheme.colorScheme issues!
# Fix PremiumBadgeItem
content = content.replace(
"""            Canvas(modifier = Modifier.fillMaxSize()) {
                drawArc(
                    color = MaterialTheme.colorScheme.surfaceVariant,
                    startAngle = 0f, sweepAngle = 360f, useCenter = false,
                    style = Stroke(width = 6.dp.toPx(), cap = StrokeCap.Round)
                )
                if (currentProgress > 0) {
                    drawArc(
                        color = premiumSkyBlue,
                        startAngle = -90f, sweepAngle = currentProgress * 360f, useCenter = false,
                        style = Stroke(width = 6.dp.toPx(), cap = StrokeCap.Round)
                    )
                }
            }
            Box(
                modifier = Modifier
                    .size(48.dp)
                    .clip(CircleShape)
                    .background(if (isUnlocked) premiumSkyBlue else MaterialTheme.colorScheme.surfaceVariant.copy(alpha=0.5f)),""",
"""            val surfaceVariant = MaterialTheme.colorScheme.surfaceVariant
            val primaryContainer = MaterialTheme.colorScheme.primaryContainer
            Canvas(modifier = Modifier.fillMaxSize()) {
                drawArc(
                    color = surfaceVariant,
                    startAngle = 0f, sweepAngle = 360f, useCenter = false,
                    style = Stroke(width = 6.dp.toPx(), cap = StrokeCap.Round)
                )
                if (currentProgress > 0) {
                    drawArc(
                        color = premiumSkyBlue,
                        startAngle = -90f, sweepAngle = currentProgress * 360f, useCenter = false,
                        style = Stroke(width = 6.dp.toPx(), cap = StrokeCap.Round)
                    )
                }
            }
            Box(
                modifier = Modifier
                    .size(48.dp)
                    .clip(CircleShape)
                    .background(if (isUnlocked) primaryContainer else surfaceVariant.copy(alpha=0.5f)),"""
)

# Fix AnimatedLinearProgress
content = content.replace(
"""    LaunchedEffect(key1 = true) { animationPlayed = true }
    Canvas(modifier = Modifier.fillMaxWidth().height(8.dp)) {
        drawRoundRect(
            color = MaterialTheme.colorScheme.surfaceVariant,
            size = Size(size.width, size.height),
            cornerRadius = CornerRadius(4.dp.toPx())
        )
        drawRoundRect(
            color = color,
            size = Size(size.width * currentProgress, size.height),
            cornerRadius = CornerRadius(4.dp.toPx())
        )
    }""",
"""    val surfaceVariant = MaterialTheme.colorScheme.surfaceVariant
    LaunchedEffect(key1 = true) { animationPlayed = true }
    Canvas(modifier = Modifier.fillMaxWidth().height(8.dp)) {
        drawRoundRect(
            color = surfaceVariant,
            size = Size(size.width, size.height),
            cornerRadius = CornerRadius(4.dp.toPx())
        )
        drawRoundRect(
            color = color,
            size = Size(size.width * currentProgress, size.height),
            cornerRadius = CornerRadius(4.dp.toPx())
        )
    }"""
)

with open('app/src/main/java/com/example/ui/screens/ProgressScreen.kt', 'w') as f:
    f.write(content)

