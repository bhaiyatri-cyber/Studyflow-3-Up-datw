import re

with open('app/src/main/java/com/example/ui/screens/ProgressScreen.kt', 'r') as f:
    content = f.read()

# Add premiumSkyBlue definition if missing
if "val premiumSkyBlue" not in content:
    content = content.replace(
        "    val isMaster = totalHours >= 500",
        "    val isMaster = totalHours >= 500\n    val premiumSkyBlue = Color(0xFF38BDF8)"
    )

# Replace MaterialTheme.colorScheme.primary with premiumSkyBlue
content = content.replace("MaterialTheme.colorScheme.primary", "premiumSkyBlue")

# Insert Today's Focus and Lifetime Achievements
components = """
@Composable
fun AchievementBadge(title: String, icon: ImageVector, color: Color) {
    Card(
        modifier = Modifier
            .size(100.dp)
            .shadow(4.dp, RoundedCornerShape(16.dp)),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.3f)),
        shape = RoundedCornerShape(16.dp)
    ) {
        Column(
            modifier = Modifier.fillMaxSize().padding(8.dp),
            verticalArrangement = Arrangement.Center,
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Icon(icon, contentDescription = null, tint = color, modifier = Modifier.size(32.dp))
            Spacer(modifier = Modifier.height(8.dp))
            Text(title, style = MaterialTheme.typography.labelMedium, fontWeight = FontWeight.Bold, textAlign = TextAlign.Center)
        }
    }
}
"""

if "fun AchievementBadge" not in content:
    content += components

injection = """
            // 0. TODAY'S FOCUS & LIFETIME ACHIEVEMENTS
            item {
                val todaysBlocks = allBlocks.filter { it.startTimeMs >= startOfToday && it.startTimeMs < startOfToday + 24*3600*1000L }
                val completed = todaysBlocks.count { it.status == "Completed" }
                val total = todaysBlocks.size
                val progress = if (total > 0) completed.toFloat() / total else 0f
                
                Column(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Text("Today's Focus", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold, modifier = Modifier.align(Alignment.Start))
                    Spacer(modifier = Modifier.height(16.dp))
                    AnimatedCircularProgress(
                        progress = progress,
                        label = "Tasks Completed",
                        valueText = "$completed / $total",
                        primaryColor = premiumSkyBlue,
                        modifier = Modifier.align(Alignment.CenterHorizontally)
                    )
                    Spacer(modifier = Modifier.height(32.dp))
                    
                    Text("Lifetime Achievements", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold, modifier = Modifier.align(Alignment.Start))
                    Spacer(modifier = Modifier.height(16.dp))
                    Row(
                        modifier = Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()),
                        horizontalArrangement = Arrangement.spacedBy(16.dp)
                    ) {
                        AchievementBadge("7 Day Streak", Icons.Default.LocalFireDepartment, Color(0xFFFF9800))
                        AchievementBadge("100 Hours", Icons.Default.AccessTime, premiumSkyBlue)
                        AchievementBadge("Night Owl", Icons.Default.NightsStay, Color(0xFF7C4DFF))
                        AchievementBadge("Early Bird", Icons.Default.WbSunny, Color(0xFFFFC107))
                    }
                }
            }
"""

content = content.replace("            // 1. STUDY CALENDAR / HEATMAP", injection + "\n            // 1. STUDY CALENDAR / HEATMAP")

# Weekly Trend chart injection
weekly_trend_injection = """
            // 1.5 WEEKLY TREND CHART
            item {
                Text("Weekly Trend", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
                Spacer(modifier = Modifier.height(16.dp))
                Card(
                    modifier = Modifier.fillMaxWidth().shadow(8.dp, RoundedCornerShape(24.dp)),
                    shape = RoundedCornerShape(24.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
                ) {
                    val days = listOf("Mon", "Tue", "Wed", "Thu", "Fri", "Sat", "Sun")
                    val mockData = listOf(2.5f, 4.0f, 3.2f, 5.0f, 1.5f, 6.0f, 3.0f) // Represents hours. Can be derived from real data.
                    
                    Column(modifier = Modifier.padding(20.dp)) {
                        AnimatedBarChart(
                            data = mockData,
                            labels = days,
                            barColor = premiumSkyBlue
                        )
                    }
                }
            }
"""
content = content.replace("            // 2. XP & LEVELS SYSTEM", weekly_trend_injection + "\n            // 2. XP & LEVELS SYSTEM")


# Revert Icon.Default to Icon.AutoMirrored.Filled
content = content.replace("Icons.Default.TrendingUp", "Icons.AutoMirrored.Filled.TrendingUp")
content = content.replace("Icons.Default.DirectionsWalk", "Icons.AutoMirrored.Filled.DirectionsWalk")
content = content.replace("Icons.Default.ArrowBack", "Icons.AutoMirrored.Filled.ArrowBack")
content = content.replace("Icons.Default.KeyboardArrowLeft", "Icons.AutoMirrored.Filled.KeyboardArrowLeft")
content = content.replace("Icons.Default.KeyboardArrowRight", "Icons.AutoMirrored.Filled.KeyboardArrowRight")


with open('app/src/main/java/com/example/ui/screens/ProgressScreen.kt', 'w') as f:
    f.write(content)

