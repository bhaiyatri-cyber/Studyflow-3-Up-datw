import os

content = """package com.example.ui.screens

import androidx.compose.animation.core.*
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.viewmodel.StudyViewModel
import com.example.data.model.TimeBlock
import java.util.Calendar

val premiumSkyBlue = Color(0xFF38BDF8)

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ProgressScreen(
    viewModel: StudyViewModel,
    onNavigateBack: () -> Unit
) {
    val allBlocks by viewModel.allBlocks.collectAsState()
    
    // CALCULATE REAL DATA
    val now = System.currentTimeMillis()
    val calendar = Calendar.getInstance()
    calendar.timeInMillis = now
    calendar.set(Calendar.HOUR_OF_DAY, 0)
    calendar.set(Calendar.MINUTE, 0)
    calendar.set(Calendar.SECOND, 0)
    val startOfToday = calendar.timeInMillis
    
    val evaluatedBlocks = allBlocks.map { block ->
        block.copy(status = com.example.util.ScheduleStatusEngine.calculateStatus(block, now))
    }
    
    val completedBlocks = evaluatedBlocks.filter { it.status == "Completed" }
    
    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Progress & Analytics", fontWeight = FontWeight.Bold) },
                navigationIcon = {
                    IconButton(onClick = onNavigateBack) {
                        Icon(Icons.Default.ArrowBack, contentDescription = "Back")
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = MaterialTheme.colorScheme.background
                )
            )
        }
    ) { padding ->
        if (completedBlocks.isEmpty()) {
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(padding)
                    .padding(32.dp),
                contentAlignment = Alignment.Center
            ) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Icon(
                        Icons.Default.Analytics,
                        contentDescription = null,
                        modifier = Modifier.size(64.dp),
                        tint = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.5f)
                    )
                    Spacer(modifier = Modifier.height(16.dp))
                    Text(
                        "No study data available yet. Complete your first study session to see analytics.",
                        style = MaterialTheme.typography.bodyLarge,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        textAlign = TextAlign.Center
                    )
                }
            }
        } else {
            LazyColumn(
                modifier = Modifier
                    .padding(padding)
                    .fillMaxSize()
                    .background(MaterialTheme.colorScheme.background),
                contentPadding = PaddingValues(16.dp),
                verticalArrangement = Arrangement.spacedBy(24.dp)
            ) {
                val totalMins = completedBlocks.sumOf { (it.actualTimeTakenMs ?: (it.endTimeMs - it.startTimeMs)) } / 60000L
                val totalXP = (completedBlocks.size * 50) + totalMins.toInt()
                val currentLevel = (totalXP / 500) + 1
                val currentLevelXP = totalXP % 500
                val xpProgress = currentLevelXP.toFloat() / 500f
                
                val todaysBlocks = evaluatedBlocks.filter { it.startTimeMs >= startOfToday && it.startTimeMs < startOfToday + 24*3600*1000L }
                val todaysCompleted = todaysBlocks.count { it.status == "Completed" }
                val todaysTotal = todaysBlocks.size
                
                // TODAY'S FOCUS (Only if there are blocks today)
                if (todaysTotal > 0) {
                    item {
                        Column(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalAlignment = Alignment.CenterHorizontally
                        ) {
                            Text("Today's Focus", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold, modifier = Modifier.align(Alignment.Start))
                            Spacer(modifier = Modifier.height(16.dp))
                            AnimatedCircularProgress(
                                progress = todaysCompleted.toFloat() / todaysTotal,
                                label = "Tasks Completed",
                                valueText = "$todaysCompleted / $todaysTotal",
                                primaryColor = premiumSkyBlue,
                                modifier = Modifier.align(Alignment.CenterHorizontally)
                            )
                        }
                    }
                }
                
                // XP & LEVELS SYSTEM
                item {
                    Text("Your Level", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
                    Spacer(modifier = Modifier.height(16.dp))
                    Card(
                        modifier = Modifier.fillMaxWidth().shadow(8.dp, RoundedCornerShape(24.dp)),
                        shape = RoundedCornerShape(24.dp),
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
                    ) {
                        Column(modifier = Modifier.padding(24.dp)) {
                            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Box(
                                        modifier = Modifier.size(56.dp).background(MaterialTheme.colorScheme.primaryContainer, CircleShape),
                                        contentAlignment = Alignment.Center
                                    ) {
                                        Icon(Icons.Default.Stars, contentDescription = null, modifier = Modifier.size(32.dp), tint = MaterialTheme.colorScheme.onPrimaryContainer)
                                    }
                                    Spacer(modifier = Modifier.width(16.dp))
                                    Column {
                                        Text("Level $currentLevel", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
                                        Text("Scholar", style = MaterialTheme.typography.bodyMedium, color = premiumSkyBlue)
                                    }
                                }
                                Text("$currentLevelXP / 500 XP", style = MaterialTheme.typography.labelLarge, fontWeight = FontWeight.Bold)
                            }
                            Spacer(modifier = Modifier.height(24.dp))
                            AnimatedLinearProgress(progress = xpProgress, color = premiumSkyBlue)
                            Spacer(modifier = Modifier.height(8.dp))
                            Text("${500 - currentLevelXP} XP to Level ${currentLevel + 1}", style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        }
                    }
                }

                // WEEKLY TREND CHART
                item {
                    Text("Weekly Trend", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
                    Spacer(modifier = Modifier.height(16.dp))
                    Card(
                        modifier = Modifier.fillMaxWidth().shadow(8.dp, RoundedCornerShape(24.dp)),
                        shape = RoundedCornerShape(24.dp),
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
                    ) {
                        val realData = mutableListOf<Float>()
                        val labels = mutableListOf<String>()
                        val daysStr = listOf("Sun", "Mon", "Tue", "Wed", "Thu", "Fri", "Sat")
                        for (i in 6 downTo 0) {
                            val dStart = startOfToday - (i * 24 * 3600 * 1000L)
                            val dEnd = dStart + (24 * 3600 * 1000L)
                            val cal = Calendar.getInstance()
                            cal.timeInMillis = dStart
                            labels.add(daysStr[cal.get(Calendar.DAY_OF_WEEK) - 1])
                            
                            val dayBlocks = completedBlocks.filter { it.startTimeMs in dStart..dEnd }
                            val time = dayBlocks.sumOf { it.actualTimeTakenMs ?: (it.endTimeMs - it.startTimeMs) }
                            realData.add(time.toFloat() / (1000f * 3600f))
                        }
                        
                        Column(modifier = Modifier.padding(20.dp)) {
                            AnimatedBarChart(
                                data = realData,
                                labels = labels,
                                barColor = premiumSkyBlue
                            )
                        }
                    }
                }
                
                // LIFETIME ACHIEVEMENTS
                item {
                    // Calculate real streak
                    var currentStreak = 0
                    val studyDays = completedBlocks.map { 
                        val c = Calendar.getInstance()
                        c.timeInMillis = it.startTimeMs
                        c.set(Calendar.HOUR_OF_DAY, 0)
                        c.set(Calendar.MINUTE, 0)
                        c.set(Calendar.SECOND, 0)
                        c.timeInMillis
                    }.distinct().sortedDescending()
                    
                    if (studyDays.isNotEmpty()) {
                        currentStreak = 1
                        var previousDay = studyDays.first()
                        for (i in 1 until studyDays.size) {
                            if (previousDay - studyDays[i] <= 24 * 3600 * 1000L + 1000L) {
                                currentStreak++
                                previousDay = studyDays[i]
                            } else {
                                break
                            }
                        }
                    }
                    val totalHours = totalMins / 60f
                    
                    val unlockedBadges = mutableListOf<Pair<String, Pair<ImageVector, Color>>>()
                    if (currentStreak >= 7) unlockedBadges.add("7 Day Streak" to Pair(Icons.Default.LocalFireDepartment, Color(0xFFFF9800)))
                    if (totalHours >= 100) unlockedBadges.add("100 Hours" to Pair(Icons.Default.AccessTime, premiumSkyBlue))
                    
                    val hasNightOwl = completedBlocks.any { 
                        val c = Calendar.getInstance()
                        c.timeInMillis = it.endTimeMs
                        c.get(Calendar.HOUR_OF_DAY) >= 22
                    }
                    if (hasNightOwl) unlockedBadges.add("Night Owl" to Pair(Icons.Default.NightsStay, Color(0xFF7C4DFF)))
                    
                    val hasEarlyBird = completedBlocks.any {
                        val c = Calendar.getInstance()
                        c.timeInMillis = it.startTimeMs
                        c.get(Calendar.HOUR_OF_DAY) < 8
                    }
                    if (hasEarlyBird) unlockedBadges.add("Early Bird" to Pair(Icons.Default.WbSunny, Color(0xFFFFC107)))
                    
                    if (unlockedBadges.isNotEmpty()) {
                        Text("Lifetime Achievements", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
                        Spacer(modifier = Modifier.height(16.dp))
                        Row(
                            modifier = Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()),
                            horizontalArrangement = Arrangement.spacedBy(16.dp)
                        ) {
                            unlockedBadges.forEach { badge ->
                                AchievementBadge(badge.first, badge.second.first, badge.second.second)
                            }
                        }
                    }
                }
                
                // ACTIVITY MAP
                item {
                    Text("Activity Map", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
                    Spacer(modifier = Modifier.height(16.dp))
                    Card(
                        modifier = Modifier.fillMaxWidth().shadow(8.dp, RoundedCornerShape(24.dp)),
                        shape = RoundedCornerShape(24.dp),
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
                    ) {
                        Column(modifier = Modifier.padding(20.dp)) {
                            val data = mutableListOf<HeatmapDay>()
                            for (i in 29 downTo 0) {
                                val dStart = startOfToday - (i * 24 * 3600 * 1000L)
                                val dEnd = dStart + (24 * 3600 * 1000L)
                                val dayBlocks = completedBlocks.filter { it.startTimeMs in dStart..dEnd }
                                val time = dayBlocks.sumOf { it.actualTimeTakenMs ?: (it.endTimeMs - it.startTimeMs) }
                                val intensity = when {
                                    time == 0L -> 0
                                    time < 1 * 3600 * 1000L -> 1
                                    time < 2 * 3600 * 1000L -> 2
                                    time < 4 * 3600 * 1000L -> 3
                                    else -> 4
                                }
                                data.add(HeatmapDay(dStart, intensity, time))
                            }
                            PremiumHeatmap(data)
                        }
                    }
                }
            }
        }
    }
}

data class HeatmapDay(val dateMs: Long, val intensity: Int, val timeMs: Long)

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun PremiumHeatmap(data: List<HeatmapDay>) {
    val primary = premiumSkyBlue
    FlowRow(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.Start,
        maxItemsInEachRow = 10
    ) {
        data.forEach { day ->
            val color = when (day.intensity) {
                0 -> MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f)
                1 -> primary.copy(alpha = 0.3f)
                2 -> primary.copy(alpha = 0.6f)
                3 -> primary.copy(alpha = 0.8f)
                else -> primary
            }
            Box(
                modifier = Modifier
                    .padding(4.dp)
                    .size(24.dp)
                    .clip(RoundedCornerShape(4.dp))
                    .background(color)
            )
        }
    }
}

@Composable
fun AnimatedLinearProgress(progress: Float, color: Color) {
    var animationPlayed by remember { mutableStateOf(false) }
    val currentProgress by animateFloatAsState(
        targetValue = if (animationPlayed) progress else 0f,
        animationSpec = tween(durationMillis = 1500),
        label = "progress"
    )
    LaunchedEffect(key1 = true) { animationPlayed = true }
    
    Box(modifier = Modifier.fillMaxWidth().height(8.dp).clip(CircleShape).background(color.copy(alpha = 0.2f))) {
        Box(modifier = Modifier.fillMaxWidth(currentProgress.coerceAtLeast(0.01f)).height(8.dp).clip(CircleShape).background(color))
    }
}

@Composable
fun AchievementBadge(title: String, icon: ImageVector, color: Color) {
    Card(
        modifier = Modifier
            .size(100.dp)
            .shadow(4.dp, RoundedCornerShape(16.dp)),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.3f)),
        shape = RoundedCornerShape(16.dp)
    ) {
        Column(
            modifier = Modifier.fillMaxSize().padding(8.dp),
            verticalArrangement = Arrangement.Center,
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Icon(icon, contentDescription = null, tint = color, modifier = Modifier.size(32.dp))
            Spacer(modifier = Modifier.height(8.dp))
            Text(title, style = MaterialTheme.typography.labelMedium, fontWeight = FontWeight.Bold, textAlign = TextAlign.Center)
        }
    }
}
"""

with open('app/src/main/java/com/example/ui/screens/ProgressScreen.kt', 'w') as f:
    f.write(content)

