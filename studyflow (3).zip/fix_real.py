import re

with open('app/src/main/java/com/example/ui/screens/ProgressScreen.kt', 'r') as f:
    content = f.read()

# Add premiumSkyBlue globally!
content = content.replace(
    "@OptIn(ExperimentalMaterial3Api::class)",
    "val premiumSkyBlue = Color(0xFF38BDF8)\n@OptIn(ExperimentalMaterial3Api::class)"
)

# Fix premiumSkyBlueContainer which was left unresolved
content = content.replace("premiumSkyBlueContainer", "MaterialTheme.colorScheme.primaryContainer")

with open('app/src/main/java/com/example/ui/screens/ProgressScreen.kt', 'w') as f:
    f.write(content)
