import re

with open('app/src/main/java/com/example/ui/screens/HomeScreen.kt', 'r') as f:
    content = f.read()

# Add imports if missing
imports = [
    'import androidx.compose.ui.platform.LocalConfiguration',
    'import androidx.compose.animation.core.*',
    'import androidx.compose.ui.graphics.Brush',
    'import androidx.compose.foundation.BorderStroke',
    'import androidx.compose.ui.text.style.TextAlign',
    'import androidx.compose.ui.unit.sp',
    'import androidx.compose.ui.draw.alpha',
    'import androidx.compose.ui.draw.scale'
]

for imp in imports:
    if imp not in content:
        content = content.replace('import androidx.compose.foundation.layout.*', f'import androidx.compose.foundation.layout.*\n{imp}')

# Find the Row that holds the profile, greeting and tune/settings icons
# We need to insert the Premium button right before the Tune icon.

target_row = """                Column(modifier = Modifier.weight(1f)) {
                    if (userName != null && userName!!.isNotBlank()) {
                        val currentHour = Calendar.getInstance().get(Calendar.HOUR_OF_DAY)
                        val greeting = when (currentHour) {
                            in 5..11 -> "Good Morning"
                            in 12..16 -> "Good Afternoon"
                            in 17..20 -> "Good Evening"
                            else -> "Good Night"
                        }
                        val subtitle = when (currentHour) {
                            in 5..11 -> "Ready to make today productive?"
                            in 12..16 -> "Keep going, you're making progress."
                            in 17..20 -> "Finish the day with one more step."
                            else -> "Review your progress and prepare for tomorrow."
                        }
                        Text("$greeting, ${userName}", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.onBackground)
                        Text(subtitle, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    } else {
                        Text("Create Local Profile", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.onBackground)
                    }
                }"""

replacement_button = target_row + """
                var showPremiumPopup by remember { mutableStateOf(false) }
                val configuration = LocalConfiguration.current
                val isSmallScreen = configuration.screenWidthDp < 360
                
                val infiniteTransition = rememberInfiniteTransition(label = "premium_glow")
                val glowAlpha by infiniteTransition.animateFloat(
                    initialValue = 0.5f,
                    targetValue = 1f,
                    animationSpec = infiniteRepeatable(
                        animation = tween(1500, easing = LinearEasing),
                        repeatMode = RepeatMode.Reverse
                    ),
                    label = "glow_alpha"
                )

                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier
                        .padding(end = 8.dp)
                        .clip(RoundedCornerShape(20.dp))
                        .clickable { showPremiumPopup = true }
                        .background(
                            brush = Brush.linearGradient(
                                colors = listOf(Color(0xFF2A2A2A), Color(0xFF1A1A1A))
                            )
                        )
                        .border(
                            width = 1.dp,
                            brush = Brush.linearGradient(
                                colors = listOf(Color(0xFFFFD700).copy(alpha = glowAlpha), Color(0xFFDAA520).copy(alpha = glowAlpha))
                            ),
                            shape = RoundedCornerShape(20.dp)
                        )
                        .padding(horizontal = if (isSmallScreen) 10.dp else 12.dp, vertical = 6.dp)
                ) {
                    Text("👑", style = MaterialTheme.typography.bodyMedium)
                    if (!isSmallScreen) {
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = "Premium",
                            style = MaterialTheme.typography.labelMedium,
                            fontWeight = FontWeight.Bold,
                            color = Color(0xFFFFD700)
                        )
                    }
                }
"""

content = content.replace(target_row, replacement_button)

# Add the Premium popup code right after the showProfileDialog block
target_dialogs = """                if (showProfileDialog) {
                    LocalProfileDialog(
                        profilePrefs = profilePrefs,
                        onDismiss = { showProfileDialog = false },
                        onSave = { name, _, _ -> userName = name }
                    )
                }"""

premium_popup = target_dialogs + """
                
                if (showPremiumPopup) {
                    androidx.compose.ui.window.Dialog(
                        onDismissRequest = { showPremiumPopup = false },
                        properties = androidx.compose.ui.window.DialogProperties(usePlatformDefaultWidth = false, decorFitsSystemWindows = false)
                    ) {
                        Box(
                            modifier = Modifier
                                .fillMaxSize()
                                .background(Color.Black.copy(alpha = 0.7f))
                                .clickable(
                                    interactionSource = remember { androidx.compose.foundation.interaction.MutableInteractionSource() },
                                    indication = null,
                                    onClick = { showPremiumPopup = false }
                                ),
                            contentAlignment = Alignment.Center
                        ) {
                            var isVisible by remember { mutableStateOf(false) }
                            LaunchedEffect(Unit) { isVisible = true }
                            val scale by animateFloatAsState(
                                targetValue = if (isVisible) 1f else 0.8f,
                                animationSpec = spring(
                                    dampingRatio = Spring.DampingRatioMediumBouncy,
                                    stiffness = Spring.StiffnessLow
                                ), label = "scale"
                            )
                            val alpha by animateFloatAsState(
                                targetValue = if (isVisible) 1f else 0f,
                                animationSpec = tween(300), label = "alpha"
                            )
            
                            Card(
                                modifier = Modifier
                                    .fillMaxWidth(0.85f)
                                    .scale(scale)
                                    .alpha(alpha)
                                    .clickable(
                                        interactionSource = remember { androidx.compose.foundation.interaction.MutableInteractionSource() },
                                        indication = null,
                                        onClick = {} // Consume clicks inside the card
                                    ),
                                colors = CardDefaults.cardColors(containerColor = Color(0xFF1A1A1A)),
                                shape = RoundedCornerShape(24.dp),
                                border = BorderStroke(1.dp, Brush.linearGradient(
                                    colors = listOf(Color(0xFFFFD700), Color(0xFFDAA520))
                                )),
                                elevation = CardDefaults.cardElevation(defaultElevation = 24.dp)
                            ) {
                                Column(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .padding(32.dp),
                                    horizontalAlignment = Alignment.CenterHorizontally
                                ) {
                                    val infTransition = rememberInfiniteTransition(label = "crown")
                                    val crownScale by infTransition.animateFloat(
                                        initialValue = 1f,
                                        targetValue = 1.15f,
                                        animationSpec = infiniteRepeatable(
                                            animation = tween(1000, easing = FastOutSlowInEasing),
                                            repeatMode = RepeatMode.Reverse
                                        ), label = "crown_scale"
                                    )
                                    Box(
                                        modifier = Modifier
                                            .size(80.dp)
                                            .scale(crownScale)
                                            .background(Color(0xFFFFD700).copy(alpha = 0.15f), CircleShape),
                                        contentAlignment = Alignment.Center
                                    ) {
                                        Text("👑", style = MaterialTheme.typography.displayMedium)
                                    }
                                    
                                    Spacer(modifier = Modifier.height(24.dp))
                                    Text(
                                        text = "StudyFlow Premium",
                                        style = MaterialTheme.typography.headlineSmall,
                                        fontWeight = FontWeight.ExtraBold,
                                        color = Color(0xFFFFD700),
                                        textAlign = TextAlign.Center
                                    )
                                    Spacer(modifier = Modifier.height(8.dp))
                                    Text(
                                        text = "COMING SOON",
                                        style = MaterialTheme.typography.labelLarge,
                                        fontWeight = FontWeight.Bold,
                                        color = Color.White.copy(alpha = 0.9f),
                                        letterSpacing = 2.sp
                                    )
                                    Spacer(modifier = Modifier.height(16.dp))
                                    Text(
                                        text = "Powerful premium features are being prepared for your study journey.",
                                        style = MaterialTheme.typography.bodyMedium,
                                        color = Color.White.copy(alpha = 0.7f),
                                        textAlign = TextAlign.Center
                                    )
                                    Spacer(modifier = Modifier.height(32.dp))
                                    Button(
                                        onClick = { showPremiumPopup = false },
                                        modifier = Modifier.fillMaxWidth().height(50.dp),
                                        colors = ButtonDefaults.buttonColors(
                                            containerColor = Color(0xFFFFD700),
                                            contentColor = Color.Black
                                        ),
                                        shape = RoundedCornerShape(25.dp)
                                    ) {
                                        Text("Got It", fontWeight = FontWeight.Bold, style = MaterialTheme.typography.titleMedium)
                                    }
                                }
                            }
                        }
                    }
                }
"""

content = content.replace(target_dialogs, premium_popup)

with open('app/src/main/java/com/example/ui/screens/HomeScreen.kt', 'w') as f:
    f.write(content)
