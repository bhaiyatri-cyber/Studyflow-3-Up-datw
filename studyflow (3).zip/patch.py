import re

with open('app/src/main/java/com/example/ui/screens/HomeScreen.kt', 'r') as f:
    content = f.read()

modal_code = """
    if (sessionToComplete != null) {
        SessionSummaryModal(
            block = sessionToComplete!!,
            onDismiss = { sessionToComplete = null },
            onSave = { actualTimeMs ->
                viewModel.updateBlock(sessionToComplete!!.copy(
                    status = "Completed",
                    completedOnMs = System.currentTimeMillis(),
                    actualTimeTakenMs = actualTimeMs
                ))
                sessionToComplete = null
            }
        )
    }
"""

target = """        )
    }
}

@Composable"""

replacement = """        )
    }
""" + modal_code + """
}

@Composable"""

content = content.replace(target, replacement)

with open('app/src/main/java/com/example/ui/screens/HomeScreen.kt', 'w') as f:
    f.write(content)
