import re
with open("app/src/main/java/com/example/service/AppAccessibilityService.kt", "r") as f:
    content = f.read()

target = """                        if (isStudying) {
                            timeNotStudyingSeconds = 0
                            val actualTime = (activeBlock.actualTimeTakenMs ?: 0L) + 10000L
                            
                            if (activeBlock.status != "Running") {
                                dao.updateBlock(activeBlock.copy(status = "Running", actualTimeTakenMs = actualTime))
                                showNotification("Study Timer Started", "You are using a study app. Timer is running.")
                            } else {
                                dao.updateBlock(activeBlock.copy(actualTimeTakenMs = actualTime))
                            }
                        } else {
                            if (activeBlock.status == "Running") {
                                // User exited the study app
                                if (now >= activeBlock.endTimeMs) {
                                    dao.updateBlock(activeBlock.copy(status = "Completed", completedOnMs = now))
                                    showNotification("Study Completed", "You exited the study app. Session completed automatically.")
                                    timeNotStudyingSeconds = 0
                                } else {
                                    dao.updateBlock(activeBlock.copy(status = "Upcoming"))
                                    timeNotStudyingSeconds += 10
                                }
                            } else {
                                // User has not started or is not studying
                                timeNotStudyingSeconds += 10
                                if (timeNotStudyingSeconds >= 600) { // 10 minutes
                                    showNotification("Start Studying!", "You have a scheduled study session for ${activeBlock.subject}. Please open your study app.")
                                    timeNotStudyingSeconds = 0
                                }
                            }
                        }"""

replacement = """                        if (isStudying) {
                            timeNotStudyingSeconds = 0
                        } else {
                            // User has not started or is not studying
                            timeNotStudyingSeconds += 10
                            if (timeNotStudyingSeconds >= 600) { // 10 minutes
                                showNotification("Start Studying!", "You have a scheduled study session for ${activeBlock.subject}. Please open your study app.")
                                timeNotStudyingSeconds = 0
                            }
                        }"""

if target in content:
    content = content.replace(target, replacement)
    print("Replaced app accessibility timer logic")

with open("app/src/main/java/com/example/service/AppAccessibilityService.kt", "w") as f:
    f.write(content)
