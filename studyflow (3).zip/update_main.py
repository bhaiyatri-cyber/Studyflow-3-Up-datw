import sys
content = open('app/src/main/java/com/example/MainActivity.kt').read()
content = content.replace('import com.example.ui.screens.OnboardingScreen', 'import com.example.ui.screens.OnboardingScreen\nimport com.example.ui.screens.HistoryScreen')
target = '''                            HomeScreen(
                                viewModel = viewModel,
                                onNavigateToAddBlock = { navController.navigate("add_edit_block/-1") },
                                onNavigateToEditBlock = { block -> navController.navigate("add_edit_block/${block.id}") },
                                onViewProgress = { navController.navigate("progress") }
                            )'''
replacement = '''                            HomeScreen(
                                viewModel = viewModel,
                                onNavigateToAddBlock = { navController.navigate("add_edit_block/-1") },
                                onNavigateToEditBlock = { block -> navController.navigate("add_edit_block/${block.id}") },
                                onViewProgress = { navController.navigate("progress") },
                                onViewHistory = { navController.navigate("history") }
                            )'''
content = content.replace(target, replacement)

target2 = '''                        composable("progress") {
                            ProgressScreen(
                                viewModel = viewModel,
                                onNavigateBack = { navController.popBackStack() }
                            )
                        }'''
replacement2 = '''                        composable("progress") {
                            ProgressScreen(
                                viewModel = viewModel,
                                onNavigateBack = { navController.popBackStack() }
                            )
                        }

                        composable("history") {
                            HistoryScreen(
                                viewModel = viewModel,
                                onNavigateBack = { navController.popBackStack() }
                            )
                        }'''
content = content.replace(target2, replacement2)
open('app/src/main/java/com/example/MainActivity.kt', 'w').write(content)
