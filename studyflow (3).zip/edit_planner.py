import sys

with open('app/src/main/java/com/example/ui/screens/PlannerScreen.kt', 'r') as f:
    content = f.read()

replacement = """
        if (futureBlocks.isEmpty() && blocks.none { it.repeatMode != "None" && it.templateId == null }) {
            Box(modifier = Modifier.padding(padding)) {
                EmptyStateView(onNavigateToAddBlock)
            }
        } else {
            LazyColumn(
                modifier = Modifier.padding(padding).fillMaxSize(),
                contentPadding = PaddingValues(16.dp),
                verticalArrangement = Arrangement.spacedBy(24.dp)
            ) {
                val repeatingTemplates = blocks.filter { it.repeatMode != "None" && it.templateId == null }
                if (repeatingTemplates.isNotEmpty()) {
                    item {
                        SectionHeader("Repeating Plans", Icons.Default.CalendarToday, MaterialTheme.colorScheme.primary)
                    }
                    items(repeatingTemplates) { block ->
                        TaskCard(
                            block = block,
                            timeFormat = timeFormat,
                            onClick = { onNavigateToDetails(block) },
                            onEdit = { onNavigateToEditBlock(block) },
                            onDelete = { viewModel.deleteBlock(block) },
                            onComplete = { viewModel.updateBlock(block.copy(status = "Completed", completedOnMs = System.currentTimeMillis())) },
                            onDuplicate = { viewModel.addBlock(block.copy(id = 0)) }
                        )
                    }
                }

                val oneTimeBlocks = blocks.filter { it.startTimeMs >= startOfTomorrow && it.status != "Completed" && it.repeatMode == "None" && it.templateId == null }.sortedBy { it.startTimeMs }
                val groupedOneTime = oneTimeBlocks.groupBy { 
                    val c = Calendar.getInstance()
                    c.timeInMillis = it.startTimeMs
                    c.set(Calendar.HOUR_OF_DAY, 0)
                    c.set(Calendar.MINUTE, 0)
                    c.set(Calendar.SECOND, 0)
                    c.timeInMillis
                }

                groupedOneTime.forEach { (dateMs, blocksForDate) ->
                    item {
                        SectionHeader(dateFormat.format(Date(dateMs)), Icons.Default.CalendarToday, MaterialTheme.colorScheme.secondary)
                    }
                    items(blocksForDate) { block ->
                        TaskCard(
                            block = block,
                            timeFormat = timeFormat,
                            onClick = { onNavigateToDetails(block) },
                            onEdit = { onNavigateToEditBlock(block) },
                            onDelete = { viewModel.deleteBlock(block) },
                            onComplete = { viewModel.updateBlock(block.copy(status = "Completed", completedOnMs = System.currentTimeMillis())) },
                            onDuplicate = { viewModel.addBlock(block.copy(id = 0)) }
                        )
                    }
                }
                item { Spacer(modifier = Modifier.height(80.dp)) }
            }
        }
"""

start_idx = content.find('if (futureBlocks.isEmpty()) {')
end_idx = content.find('item { Spacer(modifier = Modifier.height(80.dp)) }')
if start_idx != -1 and end_idx != -1:
    content = content[:start_idx] + replacement.strip() + '\n    }\n}\n'

with open('app/src/main/java/com/example/ui/screens/PlannerScreen.kt', 'w') as f:
    f.write(content)
