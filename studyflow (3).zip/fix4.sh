sed -i 's/                } // This one probably closes LazyColumn/                // deleted bracket/g' app/src/main/java/com/example/ui/screens/HomeScreen.kt
