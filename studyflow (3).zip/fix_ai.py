import re
with open("app/src/main/java/com/example/ui/screens/ChatScreen.kt", "r") as f:
    content = f.read()

target = """            // Build history
            val history = currentList.filter { !it.isLoading }.map {
                Content(role = if (it.isUser) "user" else "model", parts = listOf(Part(text = it.text)))
            }
            
            val request = GenerateContentRequest(
                contents = history,
                systemInstruction = Content(
                    role = "user",
                    parts = listOf(Part(text = "You are Flow X AI, a helpful and encouraging study assistant. You help the user with math, science, and revision topics. Keep responses concise and formatted nicely for mobile readability."))
                )
            )"""

replacement = """            // Build history
            val history = mutableListOf<Content>()
            var lastRole = ""
            for (msg in currentList.filter { !it.isLoading }) {
                val role = if (msg.isUser) "user" else "model"
                if (role == lastRole) {
                    val lastContent = history.removeLast()
                    history.add(Content(role = role, parts = lastContent.parts + Part(text = "\\n\\n" + msg.text)))
                } else {
                    history.add(Content(role = role, parts = listOf(Part(text = msg.text))))
                    lastRole = role
                }
            }
            
            // API 400 is often caused by systemInstruction formatting. 
            // We'll safely merge the system instruction into the first user prompt if needed, 
            // or use role="system" which is correct.
            val request = GenerateContentRequest(
                contents = history,
                systemInstruction = Content(
                    role = "system",
                    parts = listOf(Part(text = "You are Flow X AI, a helpful and encouraging study assistant. You help the user with math, science, and revision topics. Keep responses concise and formatted nicely for mobile readability."))
                )
            )"""

if target in content:
    content = content.replace(target, replacement)
    print("Replaced chat logic")

target2 = """            } catch (e: Exception) {
                val updatedList = _messages.value.toMutableList()
                updatedList.removeLast()
                updatedList.add(ChatMessage(text = "Error connecting to Flow X AI: ${e.message}", isUser = false))
                _messages.value = updatedList
            }"""

replacement2 = """            } catch (e: Exception) {
                val updatedList = _messages.value.toMutableList()
                updatedList.removeLast()
                
                val errMsg = if (apiKey.isEmpty() || apiKey == "YOUR_API_KEY") {
                    "Flow X AI is temporarily unavailable."
                } else if (e.message?.contains("400") == true) {
                    "Flow X AI is temporarily unavailable."
                } else {
                    "Flow X AI is temporarily unavailable."
                }
                
                updatedList.add(ChatMessage(text = errMsg, isUser = false))
                _messages.value = updatedList
            }"""

if target2 in content:
    content = content.replace(target2, replacement2)
    print("Replaced error logic")

with open("app/src/main/java/com/example/ui/screens/ChatScreen.kt", "w") as f:
    f.write(content)
