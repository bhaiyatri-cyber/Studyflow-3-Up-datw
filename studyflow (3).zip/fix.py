with open('app/src/main/java/com/example/ui/viewmodel/StudyViewModel.kt', 'r') as f:
    lines = f.readlines()

new_lines = []
for line in lines:
    if line.startswith('val MIGRATION_4_5'):
        new_lines.append('}\n')
        new_lines.append(line)
    elif line.startswith('class StudyViewModel'):
        new_lines.append('}\n')
        new_lines.append(line)
    else:
        new_lines.append(line)

with open('app/src/main/java/com/example/ui/viewmodel/StudyViewModel.kt', 'w') as f:
    f.writelines(new_lines)

