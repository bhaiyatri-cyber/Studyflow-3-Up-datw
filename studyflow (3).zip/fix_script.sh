sed -i '872,873d' app/src/main/java/com/example/ui/screens/HomeScreen.kt
