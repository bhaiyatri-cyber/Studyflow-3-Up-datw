import re
with open("app/src/main/java/com/example/service/TaskForegroundService.kt", "r") as f:
    content = f.read()

target = """                val isStudying = if (studyAppsList.isEmpty()) {
                    val powerManager = getSystemService(Context.POWER_SERVICE) as PowerManager
                    val keyguardManager = getSystemService(Context.KEYGUARD_SERVICE) as KeyguardManager
                    val isScreenOn = powerManager.isInteractive
                    val isUnlocked = !keyguardManager.isKeyguardLocked
                    
                    isScreenDownAndStill && !(isScreenOn && isUnlocked)
                } else {
                    foregroundApp != null && studyAppsList.contains(foregroundApp)
                }"""

replacement = """                val powerManager = getSystemService(Context.POWER_SERVICE) as PowerManager
                val keyguardManager = getSystemService(Context.KEYGUARD_SERVICE) as KeyguardManager
                val isScreenOn = powerManager.isInteractive
                val isUnlocked = !keyguardManager.isKeyguardLocked
                val isDeviceActive = isScreenOn && isUnlocked

                val isStudying = if (studyAppsList.isEmpty()) {
                    isDeviceActive && foregroundApp == packageName
                } else {
                    isDeviceActive && foregroundApp != null && studyAppsList.contains(foregroundApp)
                }"""

if target in content:
    content = content.replace(target, replacement)
    print("Replaced isStudying logic")
else:
    print("Not found isStudying logic")

with open("app/src/main/java/com/example/service/TaskForegroundService.kt", "w") as f:
    f.write(content)
