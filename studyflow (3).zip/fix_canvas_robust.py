import re

with open('app/src/main/java/com/example/ui/screens/ProgressScreen.kt', 'r') as f:
    content = f.read()

# Fix all MaterialTheme inside Canvas!
content = re.sub(
    r'Canvas\(modifier = Modifier\.fillMaxSize\(\)\) \{\s*drawArc\(\s*color = MaterialTheme\.colorScheme\.surfaceVariant,',
    r'val surfaceVar = MaterialTheme.colorScheme.surfaceVariant\n            Canvas(modifier = Modifier.fillMaxSize()) {\n                drawArc(\n                    color = surfaceVar,',
    content
)

with open('app/src/main/java/com/example/ui/screens/ProgressScreen.kt', 'w') as f:
    f.write(content)
