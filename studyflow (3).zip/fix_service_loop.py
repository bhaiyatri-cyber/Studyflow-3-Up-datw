import re
with open("app/src/main/java/com/example/service/TaskForegroundService.kt", "r") as f:
    content = f.read()

target1 = """                if (isStudying) {
                    hideDistractionPopup()
                    hasStartedStudying = true
                    realStudyTimeMs += tickDuration
                    if (foregroundApp != null) {
                        appUsageMap[foregroundApp] = (appUsageMap[foregroundApp] ?: 0L) + tickDuration
                    } else if (studyAppsList.isEmpty()) {
                        appUsageMap["Other"] = (appUsageMap["Other"] ?: 0L) + tickDuration
                    }
                }"""

replacement1 = """                if (isStudying) {
                    hideDistractionPopup()
                    hasStartedStudying = true
                    realStudyTimeMs += tickDuration
                    if (foregroundApp != null) {
                        appUsageMap[foregroundApp] = (appUsageMap[foregroundApp] ?: 0L) + tickDuration
                    } else if (studyAppsList.isEmpty()) {
                        appUsageMap["Other"] = (appUsageMap["Other"] ?: 0L) + tickDuration
                    }
                    
                    val b = db.timeBlockDao().getBlockById(taskId)
                    if (b != null) {
                        db.timeBlockDao().updateBlock(b.copy(
                            actualTimeTakenMs = (b.actualTimeTakenMs ?: 0L) + tickDuration
                        ))
                    }
                }"""

target2 = """                        db.timeBlockDao().updateBlock(finalBlock.copy(
                            status = finalStatus,
                            actualTimeTakenMs = (finalBlock.actualTimeTakenMs ?: 0L) + realStudyTimeMs,
                            appUsageStatsJson = json.toString(),
                            completedOnMs = now
                        ))"""

replacement2 = """                        db.timeBlockDao().updateBlock(finalBlock.copy(
                            status = finalStatus,
                            appUsageStatsJson = json.toString(),
                            completedOnMs = now
                        ))"""

target3 = """                    db.timeBlockDao().updateBlock(block.copy(
                        status = finalStatus,
                        actualTimeTakenMs = (block.actualTimeTakenMs ?: 0L) + time,
                        appUsageStatsJson = mapStr,
                        completedOnMs = System.currentTimeMillis()
                    ))"""

replacement3 = """                    db.timeBlockDao().updateBlock(block.copy(
                        status = finalStatus,
                        appUsageStatsJson = mapStr,
                        completedOnMs = System.currentTimeMillis()
                    ))"""

if target1 in content:
    content = content.replace(target1, replacement1)
    print("Replaced target1")
if target2 in content:
    content = content.replace(target2, replacement2)
    print("Replaced target2")
if target3 in content:
    content = content.replace(target3, replacement3)
    print("Replaced target3")

with open("app/src/main/java/com/example/service/TaskForegroundService.kt", "w") as f:
    f.write(content)
