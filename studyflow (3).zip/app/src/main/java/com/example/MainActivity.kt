package com.example

import android.os.Bundle
import androidx.core.splashscreen.SplashScreen.Companion.installSplashScreen
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.viewModels
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.navigation.NavType
import androidx.navigation.compose.NavHost
import android.content.Context
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import androidx.navigation.navArgument
import com.example.ui.screens.AddEditBlockScreen
import com.example.ui.screens.OnboardingScreen
import com.example.ui.screens.SplashScreen
import com.example.ui.screens.SetupScreen
import com.example.ui.screens.SettingsScreen
import com.example.ui.screens.MainScreen
import com.example.ui.screens.TaskDetailsScreen
import com.example.ui.screens.PermissionsScreen
import com.example.ui.screens.StudyAppsScreen
import com.example.ui.theme.MyApplicationTheme
import com.example.ui.viewmodel.StudyViewModel

class MainActivity : ComponentActivity() {
    private val viewModel: StudyViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        val splashScreen = installSplashScreen()
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        
        val sharedPref = getSharedPreferences("studyflow_prefs", Context.MODE_PRIVATE)
        val hasSeenOnboarding = sharedPref.getBoolean("has_seen_onboarding", false)
        val hasCompletedSetup = sharedPref.getBoolean("has_completed_setup", false)
        
        setContent {
            MyApplicationTheme {
                Surface(
                    modifier = Modifier.fillMaxSize(),
                    color = MaterialTheme.colorScheme.background
                ) {
                    val navController = rememberNavController()
                    
                    NavHost(navController = navController, startDestination = "splash") {
                        composable("splash") {
                            SplashScreen(onTimeout = {
                                if (!hasSeenOnboarding) {
                                    navController.navigate("onboarding") { popUpTo("splash") { inclusive = true } }
                                } else if (!hasCompletedSetup) {
                                    navController.navigate("setup") { popUpTo("splash") { inclusive = true } }
                                } else {
                                    navController.navigate("main") { popUpTo("splash") { inclusive = true } }
                                }
                            })
                        }
                        
                        composable("onboarding") {
                            OnboardingScreen(onFinish = {
                                sharedPref.edit().putBoolean("has_seen_onboarding", true).apply()
                                navController.navigate("setup") {
                                    popUpTo("onboarding") { inclusive = true }
                                }
                            })
                        }
                        
                        composable("setup") {
                            SetupScreen(onComplete = {
                                sharedPref.edit().putBoolean("has_completed_setup", true).apply()
                                navController.navigate("main") {
                                    popUpTo("setup") { inclusive = true }
                                }
                            })
                        }
                        
                        composable("main") {
                            MainScreen(
                                viewModel = viewModel,
                                onNavigateToAddBlock = { navController.navigate("add_edit_block/-1") },
                                onNavigateToEditBlock = { blockId -> navController.navigate("add_edit_block/$blockId") },
                                onNavigateToDetails = { blockId -> navController.navigate("task_details/$blockId") },
                                onNavigateToSettings = { navController.navigate("settings") }
                            )
                        }
                        
                                                                        composable("study_apps") {
                            StudyAppsScreen(onNavigateBack = { navController.popBackStack() })
                        }

                        composable("permissions") {
                            PermissionsScreen(onNavigateBack = { navController.popBackStack() })
                        }

                        composable("settings") {
                            SettingsScreen(onNavigateBack = { navController.popBackStack() }, onNavigateToPermissions = { navController.navigate("permissions") }, onNavigateToStudyApps = { navController.navigate("study_apps") }, viewModel = viewModel)
                        }
                        
                        composable(
                            "add_edit_block/{blockId}",
                            arguments = listOf(navArgument("blockId") { type = NavType.IntType })
                        ) { backStackEntry ->
                            val blockId = backStackEntry.arguments?.getInt("blockId") ?: -1
                            val blocks by viewModel.allBlocks.collectAsState()
                            val blockToEdit = blocks.find { it.id == blockId }
                            
                            AddEditBlockScreen(
                                block = blockToEdit,
                                allBlocks = blocks,
                                onSave = { updatedBlock -> 
                                    if (blockId == -1) viewModel.addBlock(updatedBlock)
                                    else viewModel.updateBlock(updatedBlock)
                                },
                                onDelete = { blockToDelete -> viewModel.deleteBlock(blockToDelete) },
                                onNavigateBack = { navController.popBackStack() }
                            )
                        }
                        
                        composable(
                            "task_details/{blockId}",
                            arguments = listOf(navArgument("blockId") { type = NavType.IntType })
                        ) { backStackEntry ->
                            val blockId = backStackEntry.arguments?.getInt("blockId") ?: -1
                            TaskDetailsScreen(
                                blockId = blockId,
                                viewModel = viewModel,
                                onNavigateBack = { navController.popBackStack() },
                                onNavigateToEdit = { block -> navController.navigate("add_edit_block/${block.id}") }
                            )
                        }
                    }
                }
            }
        }
    }
}
