package com.example.ui.screens

import android.content.pm.PackageManager
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.example.data.model.TimeBlock
import com.example.ui.viewmodel.StudyViewModel
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONObject
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun TaskDetailsScreen(
    blockId: Int,
    viewModel: StudyViewModel,
    onNavigateBack: () -> Unit,
    onNavigateToEdit: (TimeBlock) -> Unit
) {
    val blocks by viewModel.allBlocks.collectAsState()
    val block = blocks.find { it.id == blockId }

    if (block == null) {
        LaunchedEffect(Unit) {
            onNavigateBack()
        }
        Box(modifier = Modifier.fillMaxSize().background(MaterialTheme.colorScheme.background))
        return
    }

    val context = LocalContext.current
    val is24HourFormat = android.text.format.DateFormat.is24HourFormat(context)
    val timeFormatStr = if (is24HourFormat) "HH:mm" else "hh:mm a"
    val timeFormat = SimpleDateFormat(timeFormatStr, Locale.getDefault())
    val dateFormat = SimpleDateFormat("MMM dd, yyyy", Locale.getDefault())

    val now = System.currentTimeMillis()
    val evaluatedStatus = com.example.util.ScheduleStatusEngine.calculateStatus(block, now)
    
    val isRunning = evaluatedStatus == "Running" || evaluatedStatus == "Waiting"
    val isCompleted = evaluatedStatus == "Completed"
    val isMissed = evaluatedStatus == "Missed"
    val isSkipped = evaluatedStatus == "Skipped"
    
    val durationMs = block.endTimeMs - block.startTimeMs
    val durationMins = durationMs / (1000 * 60)
    
    val timeStudiedMs = block.actualTimeTakenMs ?: 0L
    
    val progressTarget = if (durationMs > 0) {
        (timeStudiedMs.toFloat() / durationMs.toFloat()).coerceIn(0f, 1f)
    } else 0f

    val progress by animateFloatAsState(
        targetValue = progressTarget,
        animationSpec = tween(durationMillis = 1000),
        label = "progressAnimation"
    )
    
    val remainingMs = (durationMs - timeStudiedMs).coerceAtLeast(0)
    val remainingMins = remainingMs / (1000 * 60)
    
    var showDeleteConfirm by remember { mutableStateOf(false) }
    
    if (showDeleteConfirm) {
        AlertDialog(
            onDismissRequest = { showDeleteConfirm = false },
            title = { Text("Are you sure?") },
            text = { Text("This action cannot be undone.") },
            confirmButton = {
                TextButton(onClick = {
                    showDeleteConfirm = false
                    viewModel.deleteBlock(block)
                    onNavigateBack()
                }) { Text("Confirm", color = MaterialTheme.colorScheme.error, fontWeight = FontWeight.Bold) }
            },
            dismissButton = {
                TextButton(onClick = { showDeleteConfirm = false }) { Text("Cancel") }
            }
        )
    }
    
    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Task Details", fontWeight = FontWeight.Bold) },
                navigationIcon = {
                    IconButton(onClick = onNavigateBack) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back")
                    }
                },
                actions = {
                    if (!isCompleted && !isMissed && !isSkipped) {
                        IconButton(onClick = { onNavigateToEdit(block) }) {
                            Icon(Icons.Default.Edit, contentDescription = "Edit")
                        }
                    }
                    IconButton(onClick = { showDeleteConfirm = true }) {
                        Icon(Icons.Default.Delete, contentDescription = "Delete", tint = MaterialTheme.colorScheme.error)
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = MaterialTheme.colorScheme.background
                )
            )
        },
        containerColor = MaterialTheme.colorScheme.background
    ) { padding ->
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding),
            contentPadding = PaddingValues(horizontal = 16.dp, vertical = 24.dp),
            verticalArrangement = Arrangement.spacedBy(24.dp)
        ) {
            // 1. Hero Header
            item {
                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .shadow(8.dp, RoundedCornerShape(28.dp)),
                    shape = RoundedCornerShape(28.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
                ) {
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .background(
                                Brush.verticalGradient(
                                    colors = listOf(
                                        Color(block.color).copy(alpha = 0.3f),
                                        MaterialTheme.colorScheme.surface
                                    )
                                )
                            )
                    ) {
                        Column(
                            modifier = Modifier.padding(32.dp),
                            horizontalAlignment = Alignment.CenterHorizontally
                        ) {
                            Box(
                                modifier = Modifier
                                    .size(88.dp)
                                    .shadow(4.dp, CircleShape)
                                    .clip(CircleShape)
                                    .background(Color(block.color)),
                                contentAlignment = Alignment.Center
                            ) {
                                Icon(
                                    Icons.Default.School, // Map real icon here if needed
                                    contentDescription = null,
                                    modifier = Modifier.size(44.dp),
                                    tint = Color.White
                                )
                            }
                            Spacer(modifier = Modifier.height(24.dp))
                            Text(
                                text = block.subject,
                                style = MaterialTheme.typography.headlineLarge,
                                fontWeight = FontWeight.ExtraBold,
                                color = MaterialTheme.colorScheme.onSurface
                            )
                            Spacer(modifier = Modifier.height(12.dp))
                            
                            val statusColor = when {
                                isRunning -> MaterialTheme.colorScheme.primary
                                isCompleted -> MaterialTheme.colorScheme.tertiary
                                isMissed -> MaterialTheme.colorScheme.error
                                isSkipped -> MaterialTheme.colorScheme.outline
                                else -> MaterialTheme.colorScheme.secondary
                            }
                            val statusText = when {
                                isRunning -> "Running"
                                isCompleted -> "Completed"
                                isMissed -> "Missed"
                                isSkipped -> "Skipped"
                                else -> "Upcoming"
                            }
                            
                            Surface(
                                color = statusColor.copy(alpha = 0.15f),
                                shape = RoundedCornerShape(20.dp)
                            ) {
                                Row(
                                    verticalAlignment = Alignment.CenterVertically,
                                    modifier = Modifier.padding(horizontal = 16.dp, vertical = 8.dp)
                                ) {
                                    Box(modifier = Modifier.size(8.dp).clip(CircleShape).background(statusColor))
                                    Spacer(modifier = Modifier.width(8.dp))
                                    Text(
                                        text = statusText.uppercase(),
                                        style = MaterialTheme.typography.labelLarge,
                                        fontWeight = FontWeight.Bold,
                                        color = statusColor
                                    )
                                }
                            }
                        }
                    }
                }
            }
            
            // 2. Progress Section
            item {
                Text(
                    text = "Progress",
                    style = MaterialTheme.typography.titleLarge,
                    fontWeight = FontWeight.Bold,
                    modifier = Modifier.padding(start = 8.dp, bottom = 8.dp)
                )
                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .shadow(4.dp, RoundedCornerShape(24.dp)),
                    shape = RoundedCornerShape(24.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
                ) {
                    Row(
                        modifier = Modifier.padding(24.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Box(
                            modifier = Modifier.size(120.dp),
                            contentAlignment = Alignment.Center
                        ) {
                            CircularProgressIndicator(
                                progress = { 1f },
                                modifier = Modifier.fillMaxSize(),
                                color = MaterialTheme.colorScheme.surfaceVariant,
                                strokeWidth = 10.dp,
                                strokeCap = StrokeCap.Round
                            )
                            CircularProgressIndicator(
                                progress = { progress },
                                modifier = Modifier.fillMaxSize(),
                                color = Color(block.color),
                                strokeWidth = 10.dp,
                                strokeCap = StrokeCap.Round
                            )
                            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                Text(
                                    text = "${(progressTarget * 100).toInt()}%",
                                    style = MaterialTheme.typography.headlineMedium,
                                    fontWeight = FontWeight.ExtraBold,
                                    color = MaterialTheme.colorScheme.onSurface
                                )
                            }
                        }
                        
                        Spacer(modifier = Modifier.width(24.dp))
                        
                        Column(modifier = Modifier.weight(1f)) {
                            PremiumProgressStat(
                                label = "Duration",
                                value = "$durationMins mins",
                                icon = Icons.Default.Schedule,
                                color = MaterialTheme.colorScheme.primary
                            )
                            Spacer(modifier = Modifier.height(16.dp))
                            PremiumProgressStat(
                                label = "Studied",
                                value = "${timeStudiedMs / (1000 * 60)} mins",
                                icon = Icons.Default.PlayArrow,
                                color = MaterialTheme.colorScheme.tertiary
                            )
                            Spacer(modifier = Modifier.height(16.dp))
                            PremiumProgressStat(
                                label = "Remaining",
                                value = "$remainingMins mins",
                                icon = Icons.Default.HourglassEmpty,
                                color = MaterialTheme.colorScheme.secondary
                            )
                        }
                    }
                }
            }

            // 3. Action Buttons
            if (!isCompleted && !isMissed && !isSkipped) {
                item {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(16.dp)
                    ) {
                        if (!isRunning) {
                            Button(
                                onClick = { viewModel.updateBlock(block.copy(status = "Skipped")) },
                                modifier = Modifier
                                    .weight(1f)
                                    .height(64.dp)
                                    .shadow(2.dp, RoundedCornerShape(20.dp)),
                                shape = RoundedCornerShape(20.dp),
                                colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.surfaceVariant, contentColor = MaterialTheme.colorScheme.onSurfaceVariant)
                            ) {
                                Icon(Icons.Default.SkipNext, contentDescription = null)
                                Spacer(modifier = Modifier.width(8.dp))
                                Text("Skip", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                            }
                        }
                    }
                }
            }
            
            // 4. Task Information
            item {
                Text(
                    text = "Task Information",
                    style = MaterialTheme.typography.titleLarge,
                    fontWeight = FontWeight.Bold,
                    modifier = Modifier.padding(start = 8.dp, bottom = 8.dp)
                )
                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .shadow(2.dp, RoundedCornerShape(24.dp)),
                    shape = RoundedCornerShape(24.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
                ) {
                    Column(modifier = Modifier.padding(24.dp)) {
                        PremiumDetailRow("Schedule", "${timeFormat.format(Date(block.startTimeMs))} - ${timeFormat.format(Date(block.endTimeMs))}", Icons.Default.AccessTime)
                        HorizontalDivider(modifier = Modifier.padding(vertical = 16.dp), color = MaterialTheme.colorScheme.surfaceVariant)
                        PremiumDetailRow("Date", dateFormat.format(Date(block.startTimeMs)), Icons.Default.DateRange)
                        HorizontalDivider(modifier = Modifier.padding(vertical = 16.dp), color = MaterialTheme.colorScheme.surfaceVariant)
                        PremiumDetailRow("Priority", block.priority, Icons.Default.Flag)
                        HorizontalDivider(modifier = Modifier.padding(vertical = 16.dp), color = MaterialTheme.colorScheme.surfaceVariant)
                        PremiumDetailRow("Reminders", buildString {
                            if (block.reminderBeforeStart) append("Before Start, ")
                            if (block.notifyStart) append("On Start, ")
                            if (block.reminderBeforeEnd) append("Before End, ")
                            if (block.notifyEnd) append("On End, ")
                            if (isEmpty()) append("None")
                        }.trimEnd(',', ' '), Icons.Default.Notifications)
                        HorizontalDivider(modifier = Modifier.padding(vertical = 16.dp), color = MaterialTheme.colorScheme.surfaceVariant)
                        PremiumDetailRow("Created On", dateFormat.format(Date(block.createdDateMs)), Icons.Default.CalendarToday)
                    }
                }
            }

            // 5. Notes Section
            if (block.notes.isNotEmpty()) {
                item {
                    Text(
                        text = "Notes",
                        style = MaterialTheme.typography.titleLarge,
                        fontWeight = FontWeight.Bold,
                        modifier = Modifier.padding(start = 8.dp, bottom = 8.dp)
                    )
                    Card(
                        modifier = Modifier
                            .fillMaxWidth()
                            .shadow(2.dp, RoundedCornerShape(24.dp)),
                        shape = RoundedCornerShape(24.dp),
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f))
                    ) {
                        Text(
                            text = block.notes,
                            modifier = Modifier.padding(24.dp),
                            style = MaterialTheme.typography.bodyLarge,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }
            }
            
            // 6. Completion Summary / Premium Session Report
            if (block.status == "Completed" || block.status == "Missed" || block.status == "Skipped") {
                item {
                    Text(
                        text = "Session Report",
                        style = MaterialTheme.typography.titleLarge,
                        fontWeight = FontWeight.Bold,
                        modifier = Modifier.padding(start = 8.dp, bottom = 8.dp)
                    )
                    Card(
                        modifier = Modifier
                            .fillMaxWidth()
                            .shadow(4.dp, RoundedCornerShape(24.dp)),
                        shape = RoundedCornerShape(24.dp),
                        colors = CardDefaults.cardColors(
                            containerColor = if (block.status == "Completed") MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.4f)
                            else MaterialTheme.colorScheme.errorContainer.copy(alpha = 0.4f)
                        )
                    ) {
                        Column(modifier = Modifier.padding(24.dp)) {
                            val actualMs = block.actualTimeTakenMs ?: 0L
                            val actualMins = actualMs / (1000 * 60)
                            val pauseMins = Math.max(0, durationMins - actualMins)
                            val focusPercent = if (durationMins > 0) ((actualMins.toFloat() / durationMins.toFloat()) * 100).toInt().coerceAtMost(100) else 0

                            PremiumDetailRow("Final Status", block.status, Icons.Default.AssignmentTurnedIn)
                            HorizontalDivider(modifier = Modifier.padding(vertical = 16.dp), color = MaterialTheme.colorScheme.surfaceVariant)
                            
                            val compDate = block.completedOnMs?.let { dateFormat.format(Date(it)) } ?: "Unknown"
                            val compTime = block.completedOnMs?.let { timeFormat.format(Date(it)) } ?: ""
                            PremiumDetailRow("Completed On", "$compDate $compTime", Icons.Default.EventAvailable)
                            HorizontalDivider(modifier = Modifier.padding(vertical = 16.dp), color = MaterialTheme.colorScheme.surfaceVariant)

                            PremiumDetailRow("Planned Time", "$durationMins mins", Icons.Default.Timelapse)
                            HorizontalDivider(modifier = Modifier.padding(vertical = 16.dp), color = MaterialTheme.colorScheme.surfaceVariant)
                            
                            PremiumDetailRow("Actual Study Time", "$actualMins mins", Icons.Default.Timer)
                            HorizontalDivider(modifier = Modifier.padding(vertical = 16.dp), color = MaterialTheme.colorScheme.surfaceVariant)
                            
                            PremiumDetailRow(if (block.status == "Missed") "Missed Time" else "Pause Time", "$pauseMins mins", Icons.Default.PauseCircle)
                            HorizontalDivider(modifier = Modifier.padding(vertical = 16.dp), color = MaterialTheme.colorScheme.surfaceVariant)
                            
                            PremiumDetailRow("Focus Percentage", "$focusPercent%", Icons.Default.Analytics)
                            
                            if (block.appUsageStatsJson.isNotEmpty() && block.appUsageStatsJson != "{}") {
                                HorizontalDivider(modifier = Modifier.padding(vertical = 16.dp), color = MaterialTheme.colorScheme.surfaceVariant)
                                Text("App Usage Breakdown", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.onSurface)
                                Spacer(modifier = Modifier.height(16.dp))
                                
                                val pm = context.packageManager
                                val json = try { JSONObject(block.appUsageStatsJson) } catch (e: Exception) { JSONObject() }
                                var maxApp = ""
                                var maxTime = -1L
                                
                                val keys = json.keys()
                                while (keys.hasNext()) {
                                    val pkg = keys.next()
                                    val timeMs = json.getLong(pkg)
                                    if (timeMs > maxTime) {
                                        maxTime = timeMs
                                        maxApp = pkg
                                    }
                                    
                                    var appName by remember { mutableStateOf(pkg) }
                                    LaunchedEffect(pkg) {
                                        if (pkg != "Other") {
                                            withContext(Dispatchers.IO) {
                                                try {
                                                    val appInfo = pm.getApplicationInfo(pkg, 0)
                                                    val name = pm.getApplicationLabel(appInfo).toString()
                                                    withContext(Dispatchers.Main) { appName = name }
                                                } catch(e: Exception) {}
                                            }
                                        }
                                    }
                                    
                                    Row(
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .padding(vertical = 6.dp), 
                                        horizontalArrangement = Arrangement.SpaceBetween,
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        Row(verticalAlignment = Alignment.CenterVertically) {
                                            Icon(Icons.Default.Apps, contentDescription = null, modifier = Modifier.size(16.dp), tint = MaterialTheme.colorScheme.primary)
                                            Spacer(modifier = Modifier.width(8.dp))
                                            Text(appName, style = MaterialTheme.typography.bodyLarge)
                                        }
                                        Text("${timeMs / 60000} mins", style = MaterialTheme.typography.bodyLarge, fontWeight = FontWeight.Bold)
                                    }
                                }
                                
                                if (maxApp.isNotEmpty()) {
                                    HorizontalDivider(modifier = Modifier.padding(vertical = 16.dp), color = MaterialTheme.colorScheme.surfaceVariant)
                                    var maxAppName by remember { mutableStateOf(maxApp) }
                                    LaunchedEffect(maxApp) {
                                        if (maxApp != "Other") {
                                            withContext(Dispatchers.IO) {
                                                try {
                                                    val appInfo = pm.getApplicationInfo(maxApp, 0)
                                                    val name = pm.getApplicationLabel(appInfo).toString()
                                                    withContext(Dispatchers.Main) { maxAppName = name }
                                                } catch(e: Exception) {}
                                            }
                                        }
                                    }
                                    PremiumDetailRow("Most Used Study App", maxAppName, Icons.Default.Star)
                                }
                            }
                        }
                    }
                }
            }
            
            if (isMissed) {
                item {
                    Spacer(modifier = Modifier.height(16.dp))
                    Text("Smart Reschedule", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold, modifier = Modifier.padding(start = 8.dp, bottom = 8.dp))
                    
                    val duration = block.endTimeMs - block.startTimeMs
                    val futureBlocks = blocks.filter { it.endTimeMs > now && it.id != block.id }.sortedBy { it.startTimeMs }
                    var suggestedStart = now + 15 * 60 * 1000L // 15 mins from now
                    for (fb in futureBlocks) {
                        if (suggestedStart + duration <= fb.startTimeMs) {
                            break
                        } else {
                            suggestedStart = maxOf(suggestedStart, fb.endTimeMs + 5 * 60 * 1000L)
                        }
                    }
                    val suggestedEnd = suggestedStart + duration
                    
                    var showRescheduleConfirm by remember { mutableStateOf(false) }
                    
                    if (showRescheduleConfirm) {
                        AlertDialog(
                            onDismissRequest = { showRescheduleConfirm = false },
                            title = { Text("Reschedule Task") },
                            text = { Text("Move task to ${timeFormat.format(Date(suggestedStart))} - ${timeFormat.format(Date(suggestedEnd))}?") },
                            confirmButton = {
                                TextButton(onClick = {
                                    val newBlock = block.copy(startTimeMs = suggestedStart, endTimeMs = suggestedEnd, status = "Upcoming")
                                    viewModel.updateBlock(newBlock)
                                    showRescheduleConfirm = false
                                    onNavigateBack()
                                }) { Text("Confirm") }
                            },
                            dismissButton = {
                                TextButton(onClick = { showRescheduleConfirm = false }) { Text("Cancel") }
                            }
                        )
                    }

                    Card(
                        modifier = Modifier.fillMaxWidth().shadow(2.dp, RoundedCornerShape(24.dp)),
                        shape = RoundedCornerShape(24.dp),
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer)
                    ) {
                        Column(modifier = Modifier.padding(24.dp)) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(Icons.Default.AutoAwesome, contentDescription = null, tint = MaterialTheme.colorScheme.onPrimaryContainer)
                                Spacer(modifier = Modifier.width(12.dp))
                                Text("Next Available Slot", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.onPrimaryContainer)
                            }
                            Spacer(modifier = Modifier.height(8.dp))
                            Text("${dateFormat.format(Date(suggestedStart))} at ${timeFormat.format(Date(suggestedStart))} - ${timeFormat.format(Date(suggestedEnd))}", style = MaterialTheme.typography.bodyLarge, color = MaterialTheme.colorScheme.onPrimaryContainer.copy(alpha = 0.8f))
                            Spacer(modifier = Modifier.height(16.dp))
                            Button(
                                onClick = { showRescheduleConfirm = true },
                                modifier = Modifier.fillMaxWidth(),
                                colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.primary, contentColor = MaterialTheme.colorScheme.onPrimary)
                            ) {
                                Text("Reschedule Now", fontWeight = FontWeight.Bold)
                            }
                        }
                    }
                }
            }

            // 7. Timeline Activity
            item {
                Text(
                    text = "Timeline Activity",
                    style = MaterialTheme.typography.titleLarge,
                    fontWeight = FontWeight.Bold,
                    modifier = Modifier.padding(start = 8.dp, bottom = 8.dp)
                )
                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .shadow(2.dp, RoundedCornerShape(24.dp)),
                    shape = RoundedCornerShape(24.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
                ) {
                    Column(modifier = Modifier.padding(24.dp)) {
                        TimelineItem(
                            title = "Task Created",
                            time = dateFormat.format(Date(block.createdDateMs)),
                            icon = Icons.Default.AddCircleOutline,
                            color = MaterialTheme.colorScheme.primary,
                            isLast = !isCompleted && !isMissed && !isSkipped
                        )
                        if (isCompleted || isMissed || isSkipped) {
                            val compDate = block.completedOnMs?.let { dateFormat.format(Date(it)) } ?: "Unknown"
                            val icon = when (block.status) {
                                "Completed" -> Icons.Default.CheckCircle
                                "Missed" -> Icons.Default.Cancel
                                else -> Icons.Default.SkipNext
                            }
                            val color = when (block.status) {
                                "Completed" -> MaterialTheme.colorScheme.tertiary
                                "Missed" -> MaterialTheme.colorScheme.error
                                else -> MaterialTheme.colorScheme.outline
                            }
                            TimelineItem(
                                title = "Task ${block.status}",
                                time = compDate,
                                icon = icon,
                                color = color,
                                isLast = true
                            )
                        }
                    }
                }
            }
            item { Spacer(modifier = Modifier.height(40.dp)) }
        }
    }
}

@Composable
fun PremiumProgressStat(label: String, value: String, icon: ImageVector, color: Color) {
    Row(verticalAlignment = Alignment.CenterVertically) {
        Box(
            modifier = Modifier
                .size(40.dp)
                .clip(CircleShape)
                .background(color.copy(alpha = 0.15f)),
            contentAlignment = Alignment.Center
        ) {
            Icon(
                icon,
                contentDescription = null,
                modifier = Modifier.size(20.dp),
                tint = color
            )
        }
        Spacer(modifier = Modifier.width(16.dp))
        Column {
            Text(text = label, style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
            Text(text = value, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.onSurface)
        }
    }
}

@Composable
fun PremiumDetailRow(label: String, value: String, icon: ImageVector) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Icon(icon, contentDescription = null, modifier = Modifier.size(20.dp), tint = MaterialTheme.colorScheme.onSurfaceVariant)
            Spacer(modifier = Modifier.width(12.dp))
            Text(text = label, style = MaterialTheme.typography.bodyLarge, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
        Text(text = value, style = MaterialTheme.typography.bodyLarge, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.onSurface)
    }
}

@Composable
fun TimelineItem(title: String, time: String, icon: ImageVector, color: Color, isLast: Boolean) {
    Row(modifier = Modifier.fillMaxWidth()) {
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Box(
                modifier = Modifier
                    .size(36.dp)
                    .clip(CircleShape)
                    .background(color.copy(alpha = 0.15f)),
                contentAlignment = Alignment.Center
            ) {
                Icon(icon, contentDescription = null, modifier = Modifier.size(20.dp), tint = color)
            }
            if (!isLast) {
                Box(
                    modifier = Modifier
                        .width(2.dp)
                        .height(36.dp)
                        .background(color.copy(alpha = 0.3f))
                )
            }
        }
        Spacer(modifier = Modifier.width(16.dp))
        Column(modifier = Modifier.padding(top = 8.dp)) {
            Text(text = title, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
            Text(text = time, style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
            if (!isLast) {
                Spacer(modifier = Modifier.height(24.dp))
            }
        }
    }
}
