package com.example.ui.viewmodel

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.local.AppDatabase
import com.example.data.model.DailyStats
import com.example.data.model.TimeBlock
import com.example.data.repository.StudyRepository
import com.example.util.AlarmScheduler
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import androidx.room.Room
import androidx.room.migration.Migration
import androidx.sqlite.db.SupportSQLiteDatabase

val MIGRATION_6_7 = object : Migration(6, 7) {
    override fun migrate(db: SupportSQLiteDatabase) {
        db.execSQL("ALTER TABLE time_blocks ADD COLUMN repeatMode TEXT NOT NULL DEFAULT 'None'")
        db.execSQL("ALTER TABLE time_blocks ADD COLUMN customDays TEXT NOT NULL DEFAULT ''")
        db.execSQL("ALTER TABLE time_blocks ADD COLUMN templateId INTEGER DEFAULT NULL")
    }
}

class StudyViewModel(application: Application) : AndroidViewModel(application) {
    private val db = com.example.data.local.DatabaseProvider.getDatabase(application)

    private val repository = StudyRepository(db.timeBlockDao(), db.statsDao())
    private val alarmScheduler = AlarmScheduler(application)

    val allBlocks: StateFlow<List<TimeBlock>> = repository.getAllBlocks()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val stats: StateFlow<DailyStats?> = repository.getStats()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), null)

    init {
        viewModelScope.launch {
            repository.getStats().collect { currentStats ->
                if (currentStats == null) {
                    repository.insertStats(DailyStats())
                }
            }
        }
    }

    fun addBlock(block: TimeBlock) {
        viewModelScope.launch {
            val id = repository.insertBlock(block)
            val insertedBlock = block.copy(id = id.toInt())
            alarmScheduler.scheduleAlarmsForBlock(insertedBlock)
        }
    }

    fun updateBlock(block: TimeBlock) {
        viewModelScope.launch {
            repository.updateBlock(block)
            alarmScheduler.cancelAlarmsForBlock(block)
            alarmScheduler.scheduleAlarmsForBlock(block)
        }
    }

    fun deleteBlock(block: TimeBlock) {
        viewModelScope.launch {
            repository.deleteBlockById(block.id)
            alarmScheduler.cancelAlarmsForBlock(block)
        }
    }

    fun updateStats(newStats: DailyStats) {
        viewModelScope.launch {
            repository.updateStats(newStats)
        }
    }
}
