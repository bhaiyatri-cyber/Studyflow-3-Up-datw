package com.example.ui.screens

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.example.data.model.TimeBlock
import com.example.ui.viewmodel.StudyViewModel
import java.util.Calendar
import kotlinx.coroutines.launch
import android.widget.Toast
import androidx.compose.ui.graphics.Color
import androidx.compose.foundation.shape.RoundedCornerShape

data class GoalInput(var subject: String = "", var durationMinutes: String = "60")

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AutoScheduleScreen(viewModel: StudyViewModel, onNavigateBack: () -> Unit) {
    var goals by remember { mutableStateOf(listOf(GoalInput())) }
    var breakDurationMinutes by remember { mutableStateOf("15") }
    
    val currentCal = Calendar.getInstance()
    var startHour by remember { mutableStateOf(currentCal.get(Calendar.HOUR_OF_DAY)) }
    var startMinute by remember { mutableStateOf(currentCal.get(Calendar.MINUTE)) }
    
    val coroutineScope = rememberCoroutineScope()
    val context = LocalContext.current

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Auto Schedule", fontWeight = FontWeight.Bold) },
                navigationIcon = {
                    IconButton(onClick = onNavigateBack) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back")
                    }
                }
            )
        }
    ) { padding ->
        Column(
            modifier = Modifier
                .padding(padding)
                .fillMaxSize()
                .padding(16.dp)
        ) {
            Text("Define your study goals for today, and we will automatically create a schedule for you.", style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
            Spacer(modifier = Modifier.height(16.dp))
            
            Text("Start Time", style = MaterialTheme.typography.titleMedium)
            Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.fillMaxWidth()) {
                OutlinedTextField(
                    value = startHour.toString(),
                    onValueChange = { startHour = it.toIntOrNull() ?: 0 },
                    label = { Text("Hour (0-23)") },
                    modifier = Modifier.weight(1f)
                )
                Spacer(modifier = Modifier.width(8.dp))
                OutlinedTextField(
                    value = startMinute.toString(),
                    onValueChange = { startMinute = it.toIntOrNull() ?: 0 },
                    label = { Text("Minute (0-59)") },
                    modifier = Modifier.weight(1f)
                )
            }
            
            Spacer(modifier = Modifier.height(16.dp))
            OutlinedTextField(
                value = breakDurationMinutes,
                onValueChange = { breakDurationMinutes = it },
                label = { Text("Break between sessions (minutes)") },
                modifier = Modifier.fillMaxWidth()
            )
            
            Spacer(modifier = Modifier.height(24.dp))
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.SpaceBetween, modifier = Modifier.fillMaxWidth()) {
                Text("Subjects / Goals", style = MaterialTheme.typography.titleMedium)
                IconButton(onClick = { goals = goals + GoalInput() }) {
                    Icon(Icons.Default.Add, contentDescription = "Add Goal")
                }
            }
            
            LazyColumn(modifier = Modifier.weight(1f)) {
                itemsIndexed(goals) { index, goal ->
                    Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.fillMaxWidth().padding(vertical = 4.dp)) {
                        OutlinedTextField(
                            value = goal.subject,
                            onValueChange = { 
                                val newGoals = goals.toMutableList()
                                newGoals[index] = goal.copy(subject = it)
                                goals = newGoals
                            },
                            label = { Text("Subject") },
                            modifier = Modifier.weight(2f)
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        OutlinedTextField(
                            value = goal.durationMinutes,
                            onValueChange = {
                                val newGoals = goals.toMutableList()
                                newGoals[index] = goal.copy(durationMinutes = it)
                                goals = newGoals
                            },
                            label = { Text("Mins") },
                            modifier = Modifier.weight(1f)
                        )
                        IconButton(onClick = {
                            if (goals.size > 1) {
                                val newGoals = goals.toMutableList()
                                newGoals.removeAt(index)
                                goals = newGoals
                            }
                        }) {
                            Icon(Icons.Default.Delete, contentDescription = "Delete Goal", tint = MaterialTheme.colorScheme.error)
                        }
                    }
                }
            }
            
            Button(
                onClick = {
                    coroutineScope.launch {
                        val breakMs = (breakDurationMinutes.toLongOrNull() ?: 0L) * 60 * 1000
                        val cal = Calendar.getInstance()
                        cal.set(Calendar.HOUR_OF_DAY, startHour)
                        cal.set(Calendar.MINUTE, startMinute)
                        cal.set(Calendar.SECOND, 0)
                        
                        var currentTimeMs = cal.timeInMillis
                        
                        val validGoals = goals.filter { it.subject.isNotBlank() && (it.durationMinutes.toLongOrNull() ?: 0L) > 0 }
                        if (validGoals.isEmpty()) {
                            Toast.makeText(context, "Please add valid goals.", Toast.LENGTH_SHORT).show()
                            return@launch
                        }
                        
                        val colors = listOf(Color(0xFFE57373).value.toInt(), Color(0xFF81C784).value.toInt(), Color(0xFF64B5F6).value.toInt(), Color(0xFFFFB74D).value.toInt())
                        
                        validGoals.forEachIndexed { index, goal ->
                            val durationMs = (goal.durationMinutes.toLongOrNull() ?: 0L) * 60 * 1000
                            val endTimeMs = currentTimeMs + durationMs
                            
                            val block = TimeBlock(
                                subject = goal.subject,
                                startTimeMs = currentTimeMs,
                                endTimeMs = endTimeMs,
                                color = colors[index % colors.size],
                                iconName = "MenuBook",
                                reminderBeforeStart = true,
                                reminderBeforeEnd = true,
                                status = "Upcoming"
                            )
                            viewModel.addBlock(block)
                            
                            currentTimeMs = endTimeMs + breakMs
                        }
                        
                        Toast.makeText(context, "Schedule generated successfully!", Toast.LENGTH_SHORT).show()
                        onNavigateBack()
                    }
                },
                modifier = Modifier.fillMaxWidth().height(56.dp),
                shape = RoundedCornerShape(12.dp)
            ) {
                Text("Generate Schedule", style = MaterialTheme.typography.titleMedium)
            }
            Spacer(modifier = Modifier.height(16.dp))
        }
    }
}
