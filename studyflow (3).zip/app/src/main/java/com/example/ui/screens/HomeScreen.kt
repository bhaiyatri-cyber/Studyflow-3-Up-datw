package com.example.ui.screens

import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.gestures.snapping.rememberSnapFlingBehavior
import androidx.compose.foundation.pager.HorizontalPager
import androidx.compose.foundation.pager.rememberPagerState
import androidx.compose.material.icons.automirrored.filled.MenuBook
import androidx.compose.material.icons.filled.ChevronRight
import androidx.compose.material.icons.filled.DonutLarge
import androidx.compose.material.icons.filled.Flag
import androidx.compose.material.icons.filled.LocalFireDepartment
import androidx.compose.material.icons.filled.PlayCircleFilled
import androidx.compose.material.icons.filled.SkipNext
import androidx.compose.material.icons.filled.Summarize
import androidx.compose.material.icons.filled.Timer
import androidx.compose.material.icons.filled.Insights
import androidx.compose.material.icons.filled.Apps
import androidx.compose.material.icons.filled.DateRange
import androidx.compose.material.icons.filled.EmojiEvents
import androidx.compose.ui.draw.shadow
import java.util.Collections
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.foundation.gestures.detectDragGesturesAfterLongPress
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.animation.core.animateDpAsState
import androidx.compose.material.icons.filled.DragHandle
import androidx.compose.material.icons.filled.KeyboardArrowUp
import androidx.compose.material.icons.filled.KeyboardArrowDown
import androidx.compose.material.icons.filled.Tune
import android.content.Context

import androidx.compose.foundation.background
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.layout.*
import androidx.compose.ui.draw.scale
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.unit.sp
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.foundation.BorderStroke
import androidx.compose.ui.graphics.Brush
import androidx.compose.animation.core.*
import androidx.compose.ui.platform.LocalConfiguration
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Menu
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.automirrored.filled.Chat
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Schedule
import androidx.compose.material.icons.filled.Star
import androidx.compose.material.icons.filled.MoreVert
import androidx.compose.material.icons.filled.ArrowDropDown
import androidx.compose.material.icons.filled.ArrowDropUp
import androidx.compose.material.icons.filled.NotificationsActive
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.Block
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.asImageBitmap
import androidx.core.graphics.drawable.toBitmap
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import androidx.compose.foundation.Image
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.window.PopupProperties
import com.example.data.model.TimeBlock
import com.example.ui.viewmodel.StudyViewModel
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.Calendar
import kotlinx.coroutines.launch

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun HomeScreen(
    viewModel: StudyViewModel,
    onNavigateToAddBlock: () -> Unit,
    onNavigateToDetails: (TimeBlock) -> Unit,
    onNavigateToEditBlock: (TimeBlock) -> Unit,
    onNavigateToSettings: () -> Unit,
    onNavigateToAutoSchedule: () -> Unit = {},
    onNavigateToAssistant: () -> Unit = {},
    onOpenDrawer: () -> Unit = {}
) {
    val blocks by viewModel.allBlocks.collectAsState()
    val stats by viewModel.stats.collectAsState()
    
    val context = androidx.compose.ui.platform.LocalContext.current
    val is24HourFormat = android.text.format.DateFormat.is24HourFormat(context)
    val timeFormatStr = if (is24HourFormat) "HH:mm" else "hh:mm a"
    val timeFormat = SimpleDateFormat(timeFormatStr, Locale.getDefault())
    
    val snackbarHostState = remember { SnackbarHostState() }
    val coroutineScope = rememberCoroutineScope()
    
    val now = System.currentTimeMillis()
    val calendar = Calendar.getInstance()
    calendar.timeInMillis = now
    calendar.set(Calendar.HOUR_OF_DAY, 0)
    calendar.set(Calendar.MINUTE, 0)
    calendar.set(Calendar.SECOND, 0)
    val startOfToday = calendar.timeInMillis
    calendar.add(Calendar.DAY_OF_YEAR, 1)
    val endOfToday = calendar.timeInMillis
    
    // Only Today's tasks
    
    
    val todaysBlocks = blocks.filter { it.startTimeMs in startOfToday until endOfToday }
    
    val evaluatedBlocks = blocks.map { block ->
        block.copy(status = com.example.util.ScheduleStatusEngine.calculateStatus(block, now))
    }
    
    val currentTask = evaluatedBlocks.find { it.status == "Running" || it.status == "Waiting" }
    
    LaunchedEffect(currentTask) {
        if (currentTask != null) {
            try {
                val serviceIntent = android.content.Intent(context, com.example.service.TaskForegroundService::class.java).apply {
                    this.action = com.example.service.TaskForegroundService.ACTION_START
                    putExtra(com.example.service.TaskForegroundService.EXTRA_TASK_ID, currentTask.id)
                    putExtra(com.example.service.TaskForegroundService.EXTRA_TASK_NAME, currentTask.subject)
                    putExtra(com.example.service.TaskForegroundService.EXTRA_START_TIME, currentTask.startTimeMs)
                    putExtra(com.example.service.TaskForegroundService.EXTRA_END_TIME, currentTask.endTimeMs)
                }
                if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.O) {
                    context.startForegroundService(serviceIntent)
                } else {
                    context.startService(serviceIntent)
                }
            } catch (e: Exception) { }
        } else {
            try {
                val serviceIntent = android.content.Intent(context, com.example.service.TaskForegroundService::class.java).apply {
                    this.action = com.example.service.TaskForegroundService.ACTION_STOP
                }
                context.startService(serviceIntent)
            } catch(e: Exception) {}
        }
    }

    val upcomingTasks = evaluatedBlocks.filter { it.status == "Upcoming" }.sortedWith(compareByDescending<TimeBlock> { it.isPinned }.thenBy { it.startTimeMs })
    val completedTasks = evaluatedBlocks.filter { it.status == "Completed" }.sortedByDescending { it.endTimeMs }
    val missedTasks = evaluatedBlocks.filter { it.status == "Missed" }.sortedByDescending { it.endTimeMs }
    val skippedTasks = evaluatedBlocks.filter { it.status == "Skipped" }.sortedByDescending { it.endTimeMs }

    var isTimeVerified by remember { mutableStateOf(true) }
    var sessionToComplete by remember { mutableStateOf<com.example.data.model.TimeBlock?>(null) }
    LaunchedEffect(Unit) {
        isTimeVerified = com.example.util.TimeVerification.verifyDeviceTime()
    }

    val sharedPref = context.getSharedPreferences("dashboard_prefs", Context.MODE_PRIVATE)
    var showCustomizeDialog by remember { mutableStateOf(false) }
    val defaultOrder = listOf(
        "quick_stats", "goal", "ring", "streak", "running", "next", "summary", 
        "hours", "score", "subject", "app_usage", "weekly", "achievements"
    )
    var cardOrder by remember { 
        mutableStateOf(
            sharedPref.getString("card_order", defaultOrder.joinToString(","))?.split(",")?.filter { it.isNotBlank() } ?: defaultOrder
        ) 
    }
    var cardEnabled by remember {
        mutableStateOf(
            defaultOrder.associateWith { 
                if (sharedPref.contains("card_enabled_$it")) {
                    sharedPref.getBoolean("card_enabled_$it", true)
                } else {
                    it in listOf("quick_stats", "goal", "ring", "running", "next", "streak", "hours", "score")
                }
            }
        )
    }
    LaunchedEffect(Unit) {
        val savedOrder = sharedPref.getString("card_order", defaultOrder.joinToString(","))?.split(",")?.filter { it.isNotBlank() } ?: defaultOrder
        val missing = defaultOrder.filter { !savedOrder.contains(it) }
        cardOrder = savedOrder + missing
        cardEnabled = defaultOrder.associateWith { 
            if (sharedPref.contains("card_enabled_$it")) {
                sharedPref.getBoolean("card_enabled_$it", true)
            } else {
                it in listOf("quick_stats", "goal", "ring", "running", "next", "streak", "hours", "score")
            }
        }
    }
    val completedBlocks = todaysBlocks.filter { it.status == "Completed" }
    val todayStudyTimeMs = completedBlocks.sumOf { it.actualTimeTakenMs ?: 0L }
    val todayStudyHours = todayStudyTimeMs / 3600000f
    val currentSubject = currentTask?.subject ?: upcomingTasks.firstOrNull()?.subject ?: "None"
    val nextTask = upcomingTasks.firstOrNull()

    
    val onUndoAction = { message: String, actionLabel: String, onUndo: () -> Unit ->
        coroutineScope.launch {
            val result = snackbarHostState.showSnackbar(message = message, actionLabel = actionLabel, duration = SnackbarDuration.Short)
            if (result == SnackbarResult.ActionPerformed) onUndo()
        }
    }
    
    val premiumSkyBlue = Color(0xFF38BDF8)
    val premiumCyan = Color(0xFF22D3EE)
    val premiumColorScheme = darkColorScheme(
        primary = premiumSkyBlue,
        onPrimary = Color.Black,
        primaryContainer = premiumSkyBlue.copy(alpha = 0.2f),
        onPrimaryContainer = premiumSkyBlue,
        secondary = premiumCyan,
        onSecondary = Color.Black,
        secondaryContainer = premiumCyan.copy(alpha = 0.2f),
        onSecondaryContainer = premiumCyan,
        background = Color.Black,
        surface = Color(0xFF111827),
        surfaceVariant = Color(0xFF1F2937),
        onBackground = Color.White,
        onSurface = Color.White,
        onSurfaceVariant = Color(0xFF94A3B8)
    )

    MaterialTheme(colorScheme = premiumColorScheme) {
    Scaffold(
        floatingActionButton = {
            FloatingActionButton(onClick = onNavigateToAddBlock, containerColor = MaterialTheme.colorScheme.primary) {
                Icon(Icons.Default.Add, contentDescription = "Add Block")
            }
        },
        snackbarHost = { SnackbarHost(snackbarHostState) },
        containerColor = MaterialTheme.colorScheme.background
    ) { padding ->
        
        val profilePrefs = context.getSharedPreferences("local_profile", Context.MODE_PRIVATE)
        var userName by remember { mutableStateOf(profilePrefs.getString("name", null)) }
        var showProfileDialog by remember { mutableStateOf(false) }

        Column(modifier = Modifier.padding(padding).fillMaxSize()) {
            Row(
                modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 8.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Box(
                    modifier = Modifier.size(40.dp).clip(CircleShape).background(MaterialTheme.colorScheme.primaryContainer).clickable { showProfileDialog = true },
                    contentAlignment = Alignment.Center
                ) {
                    if (userName != null && userName!!.isNotBlank()) {
                        Text(userName!!.first().uppercase(), style = MaterialTheme.typography.titleMedium, color = MaterialTheme.colorScheme.onPrimaryContainer, fontWeight = FontWeight.Bold)
                    } else {
                        Icon(Icons.Default.Person, contentDescription = "Profile", tint = MaterialTheme.colorScheme.onPrimaryContainer)
                    }
                }
                Spacer(modifier = Modifier.width(12.dp))
                Column(modifier = Modifier.weight(1f)) {
                    if (userName != null && userName!!.isNotBlank()) {
                        val currentHour = Calendar.getInstance().get(Calendar.HOUR_OF_DAY)
                        val greeting = when (currentHour) {
                            in 5..11 -> "Good Morning"
                            in 12..16 -> "Good Afternoon"
                            in 17..20 -> "Good Evening"
                            else -> "Good Night"
                        }
                        val subtitle = when (currentHour) {
                            in 5..11 -> "Ready to make today productive?"
                            in 12..16 -> "Keep going, you're making progress."
                            in 17..20 -> "Finish the day with one more step."
                            else -> "Review your progress and prepare for tomorrow."
                        }
                        Text("$greeting, ${userName}", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.onBackground)
                        Text(subtitle, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    } else {
                        Text("Create Local Profile", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.onBackground)
                    }
                }
                IconButton(onClick = { showCustomizeDialog = true }) {
                    Icon(Icons.Default.Tune, contentDescription = "Customize Dashboard")
                }
                IconButton(onClick = onNavigateToAutoSchedule) {
                    Icon(Icons.Default.Insights, contentDescription = "Auto Schedule")
                }
                IconButton(onClick = onNavigateToSettings) {
                    Icon(Icons.Default.Settings, contentDescription = "Settings")
                }
                
                if (showProfileDialog) {
                    LocalProfileDialog(
                        profilePrefs = profilePrefs,
                        onDismiss = { showProfileDialog = false },
                        onSave = { name, _, _ -> userName = name }
                    )
                }
                
            }

            // Flow X AI Assistant Card
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp)
                    .clickable { onNavigateToAssistant() },
                colors = CardDefaults.cardColors(
                    containerColor = MaterialTheme.colorScheme.primaryContainer,
                    contentColor = MaterialTheme.colorScheme.onPrimaryContainer
                ),
                elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
                shape = RoundedCornerShape(20.dp)
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(20.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Box(
                        modifier = Modifier
                            .size(48.dp)
                            .background(
                                color = MaterialTheme.colorScheme.primary,
                                shape = CircleShape
                            ),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            Icons.Default.AutoAwesome,
                            contentDescription = "Flow X AI",
                            tint = MaterialTheme.colorScheme.onPrimary,
                            modifier = Modifier.size(24.dp)
                        )
                    }
                    
                    Spacer(modifier = Modifier.width(16.dp))
                    
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            "Chat with Flow X AI",
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold
                        )
                        Spacer(modifier = Modifier.height(2.dp))
                        Text(
                            "Get instant study help & answers",
                            style = MaterialTheme.typography.labelMedium,
                            color = MaterialTheme.colorScheme.onPrimaryContainer.copy(alpha = 0.8f)
                        )
                    }
                    
                    Icon(
                        Icons.Default.ChevronRight,
                        contentDescription = "Open Chat",
                        modifier = Modifier.size(24.dp),
                        tint = MaterialTheme.colorScheme.onPrimaryContainer.copy(alpha = 0.5f)
                    )
                }
            }
            Spacer(modifier = Modifier.height(16.dp))
            if (blocks.isEmpty()) {
            Box(modifier = Modifier.weight(1f)) {
                EmptyStateView(onNavigateToAddBlock)
            }
        } else {
            LazyColumn(
                modifier = Modifier.weight(1f).fillMaxSize(),
                contentPadding = PaddingValues(16.dp),
                verticalArrangement = Arrangement.spacedBy(24.dp)
            ) {
                if (!isTimeVerified) {
                    item {
                    Card(
                            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.errorContainer),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Row(modifier = Modifier.padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
                                Icon(Icons.Default.Info, contentDescription = "Warning", tint = MaterialTheme.colorScheme.error)
                                Spacer(modifier = Modifier.width(16.dp))
                                Text("Your phone date or time may be incorrect. Please enable Automatic Date & Time.", color = MaterialTheme.colorScheme.onErrorContainer)
                            }
                        }
                    }
                }

                // Smart Dashboard Container
                val smartCards = mutableListOf<String>()
                smartCards.add("streak")
                smartCards.add("progress")
                smartCards.add("study_time")
                if (currentTask != null) smartCards.add("running")
                if (nextTask != null) smartCards.add("next")
                smartCards.add("score")
                
                if (smartCards.isNotEmpty()) {
                    item(key = "smart_dashboard_container") {
                        Column(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(vertical = 8.dp)
                        ) {
                            val pagerState = rememberPagerState(pageCount = { smartCards.size })
                            var isTouched by remember { mutableStateOf(false) }

                            // Auto-slide effect
                            if (smartCards.size > 1) {
                                LaunchedEffect(smartCards.size, isTouched) {
                                    while (true) {
                                        kotlinx.coroutines.delay(5000)
                                        if (!isTouched && !pagerState.isScrollInProgress) {
                                            val nextPage = (pagerState.currentPage + 1) % smartCards.size
                                            pagerState.animateScrollToPage(nextPage)
                                        }
                                    }
                                }
                            }

                            HorizontalPager(
                                state = pagerState,
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .pointerInput(Unit) {
                                        awaitPointerEventScope {
                                            while (true) {
                                                val event = awaitPointerEvent()
                                                if (event.type == androidx.compose.ui.input.pointer.PointerEventType.Press) {
                                                    isTouched = true
                                                } else if (event.type == androidx.compose.ui.input.pointer.PointerEventType.Release) {
                                                    isTouched = false
                                                }
                                            }
                                        }
                                    }
                            ) { pageIndex ->
                                val cardId = smartCards.getOrNull(pageIndex) ?: return@HorizontalPager
                                val currentStreak = stats?.currentStreak ?: 0
                                val weeklyScore = if (todaysBlocks.isNotEmpty()) (completedBlocks.size * 100) / todaysBlocks.size else 0
                                
                                when (cardId) {
                                    "streak" -> {
                                        PremiumDashboardCard(
                                            title = "Daily Focus Streak",
                                            icon = Icons.Default.LocalFireDepartment,
                                            iconColor = Color(0xFF38BDF8)
                                        ) {
                                            Row(
                                                modifier = Modifier.fillMaxWidth().padding(horizontal = 8.dp),
                                                verticalAlignment = Alignment.CenterVertically
                                            ) {
                                                Text(
                                                    text = "$currentStreak",
                                                    style = MaterialTheme.typography.displayMedium,
                                                    fontWeight = FontWeight.Bold,
                                                    color = Color.White
                                                )
                                                Spacer(modifier = Modifier.width(16.dp))
                                                Text(
                                                    text = "days in a row.\nKeep the momentum going!",
                                                    style = MaterialTheme.typography.bodyLarge,
                                                    color = Color.White.copy(alpha = 0.7f)
                                                )
                                            }
                                        }
                                    }
                                    "progress" -> {
                                        PremiumDashboardCard(
                                            title = "Today's Progress",
                                            icon = Icons.Default.CheckCircle,
                                            iconColor = Color(0xFF38BDF8)
                                        ) {
                                            var liveNow by remember { mutableStateOf(System.currentTimeMillis()) }
                                            LaunchedEffect(Unit) {
                                                while (true) {
                                                    liveNow = System.currentTimeMillis()
                                                    kotlinx.coroutines.delay(1000)
                                                }
                                            }
                                            
                                            val totalScheduledMs = todaysBlocks.sumOf { it.endTimeMs - it.startTimeMs }.coerceAtLeast(1L)
                                            val completedMs = todaysBlocks.filter { it.status == "Completed" }.sumOf { it.actualTimeTakenMs ?: 0L }
                                            val runningMs = todaysBlocks.filter { it.status == "Running" || it.status == "Paused" }.sumOf { it.actualTimeTakenMs ?: 0L }
                                            val progressMs = completedMs + runningMs
                                            val completionRate = (progressMs.toFloat() / totalScheduledMs.toFloat()).coerceIn(0f, 1f)
                                            
                                            val formatTime = { ms: Long ->
                                                val hours = ms / 3600000
                                                val minutes = (ms / 60000) % 60
                                                if (hours > 0) "${hours}h ${minutes}m" else "${minutes}m"
                                            }

                                            Row(
                                                modifier = Modifier.fillMaxWidth(),
                                                horizontalArrangement = Arrangement.SpaceBetween,
                                                verticalAlignment = Alignment.CenterVertically
                                            ) {
                                                Column(modifier = Modifier.weight(1f)) {
                                                    Text(
                                                        text = "${(completionRate * 100).toInt()}% Done",
                                                        style = MaterialTheme.typography.displaySmall,
                                                        fontWeight = FontWeight.Bold,
                                                        color = Color(0xFF38BDF8)
                                                    )
                                                    Text(
                                                        text = "${formatTime(progressMs)} of ${formatTime(totalScheduledMs)}",
                                                        style = MaterialTheme.typography.bodyLarge,
                                                        color = Color.White.copy(alpha = 0.7f)
                                                    )
                                                }
                                                CircularProgressIndicator(
                                                    progress = { completionRate },
                                                    modifier = Modifier.size(72.dp),
                                                    color = Color(0xFF38BDF8),
                                                    strokeWidth = 6.dp,
                                                    trackColor = Color.White.copy(alpha = 0.1f)
                                                )
                                            }
                                        }
                                    }
                                    "study_time" -> {
                                        PremiumDashboardCard(
                                            title = "Study Time Today",
                                            icon = Icons.Default.Timer,
                                            iconColor = Color(0xFF38BDF8)
                                        ) {
                                            Row(
                                                modifier = Modifier.fillMaxWidth().padding(horizontal = 8.dp),
                                                verticalAlignment = Alignment.CenterVertically
                                            ) {
                                                Text(
                                                    text = String.format(Locale.US, "%.1f", todayStudyHours),
                                                    style = MaterialTheme.typography.displayMedium,
                                                    fontWeight = FontWeight.Bold,
                                                    color = Color.White
                                                )
                                                Text(
                                                    text = " hours",
                                                    style = MaterialTheme.typography.titleLarge,
                                                    color = Color(0xFF38BDF8),
                                                    modifier = Modifier.padding(top = 12.dp)
                                                )
                                                Spacer(modifier = Modifier.width(16.dp))
                                                Text(
                                                    text = "Dedicated to\nlearning.",
                                                    style = MaterialTheme.typography.bodyLarge,
                                                    color = Color.White.copy(alpha = 0.7f)
                                                )
                                            }
                                        }
                                    }
                                    "running" -> {
                                        PremiumDashboardCard(
                                            title = "Running Task",
                                            icon = Icons.Default.PlayCircleFilled,
                                            iconColor = Color(0xFF38BDF8),
                                            onClick = { currentTask?.let { onNavigateToDetails(it) } }
                                        ) {
                                            Column {
                                                Text(
                                                    text = currentTask?.subject ?: "No task",
                                                    style = MaterialTheme.typography.headlineSmall,
                                                    fontWeight = FontWeight.Bold,
                                                    color = Color.White
                                                )
                                                Spacer(modifier = Modifier.height(8.dp))
                                                Row(verticalAlignment = Alignment.CenterVertically) {
                                                    Icon(Icons.Default.Schedule, contentDescription = null, tint = Color(0xFF38BDF8), modifier = Modifier.size(16.dp))
                                                    Spacer(modifier = Modifier.width(4.dp))
                                                    Text(
                                                        "Focusing right now...",
                                                        style = MaterialTheme.typography.bodyMedium,
                                                        color = Color(0xFF38BDF8)
                                                    )
                                                }
                                            }
                                        }
                                    }
                                    "next" -> {
                                        PremiumDashboardCard(
                                            title = "Next Task",
                                            icon = Icons.Default.SkipNext,
                                            iconColor = Color(0xFF38BDF8),
                                            onClick = { nextTask?.let { onNavigateToDetails(it) } }
                                        ) {
                                            Column {
                                                Text(
                                                    text = nextTask?.subject ?: "No task",
                                                    style = MaterialTheme.typography.headlineSmall,
                                                    fontWeight = FontWeight.Bold,
                                                    color = Color.White
                                                )
                                                Spacer(modifier = Modifier.height(8.dp))
                                                Row(verticalAlignment = Alignment.CenterVertically) {
                                                    Icon(Icons.Default.Schedule, contentDescription = null, tint = Color(0xFF38BDF8), modifier = Modifier.size(16.dp))
                                                    Spacer(modifier = Modifier.width(4.dp))
                                                    Text(
                                                        if (nextTask != null) "${timeFormat.format(Date(nextTask.startTimeMs))} - ${timeFormat.format(Date(nextTask.endTimeMs))}" else "Upcoming",
                                                        style = MaterialTheme.typography.bodyMedium,
                                                        color = Color.White.copy(alpha = 0.7f)
                                                    )
                                                }
                                            }
                                        }
                                    }
                                    "score" -> {
                                        PremiumDashboardCard(
                                            title = "Performance Score",
                                            icon = Icons.Default.EmojiEvents,
                                            iconColor = Color(0xFF38BDF8)
                                        ) {
                                            Row(
                                                modifier = Modifier.fillMaxWidth(),
                                                horizontalArrangement = Arrangement.SpaceBetween,
                                                verticalAlignment = Alignment.CenterVertically
                                            ) {
                                                Column(modifier = Modifier.weight(1f)) {
                                                    Text(
                                                        text = "$weeklyScore",
                                                        style = MaterialTheme.typography.displaySmall,
                                                        fontWeight = FontWeight.Bold,
                                                        color = Color(0xFF38BDF8)
                                                    )
                                                    Text(
                                                        text = "Weekly XP",
                                                        style = MaterialTheme.typography.bodyLarge,
                                                        color = Color.White.copy(alpha = 0.7f)
                                                    )
                                                }
                                                Icon(
                                                    Icons.Default.EmojiEvents,
                                                    contentDescription = null,
                                                    tint = Color(0xFF38BDF8),
                                                    modifier = Modifier.size(72.dp)
                                                )
                                            }
                                        }
                                    }
                                }
                            }
                            
                            // Page indicators below the card
                            if (smartCards.size > 1) {
                                Spacer(modifier = Modifier.height(10.dp))
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.Center,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    repeat(smartCards.size) { iteration ->
                                        val isSelected = pagerState.currentPage == iteration
                                        val size = if (isSelected) 8.dp else 6.dp
                                        val color = if (isSelected) Color(0xFF38BDF8) else Color(0xFF38BDF8).copy(alpha = 0.3f)
                                        Box(
                                            modifier = Modifier
                                                .padding(horizontal = 4.dp)
                                                .clip(CircleShape)
                                                .background(color)
                                                .size(size)
                                        )
                                    }
                                }
                            }
                        }
                    }
                }
                
                if (currentTask != null) {
                    item {
                        SectionHeader("Running Now", Icons.Default.PlayArrow, MaterialTheme.colorScheme.primary)
                        Spacer(modifier = Modifier.height(8.dp))
                        TaskCard(
                            block = currentTask,
                            timeFormat = timeFormat,
                            isRunning = true,
                            onClick = { onNavigateToDetails(currentTask) },
                            onEdit = { onNavigateToEditBlock(currentTask) },
                            onActionClick = {},
                            onDelete = { viewModel.deleteBlock(currentTask) },
                            onComplete = { sessionToComplete = currentTask },
                            onDuplicate = { viewModel.addBlock(currentTask.copy(id = 0)) },    
                            onPin = { viewModel.updateBlock(currentTask.copy(isPinned = !currentTask.isPinned)) }
                        )
                        Spacer(modifier = Modifier.height(16.dp))
                    }
                }
                
                if (nextTask != null) {
                    item {
                        SectionHeader("Next Task", Icons.Default.SkipNext, MaterialTheme.colorScheme.secondary)
                        Spacer(modifier = Modifier.height(8.dp))
                        TaskCard(
                            block = nextTask,
                            timeFormat = timeFormat,
                            onClick = { onNavigateToDetails(nextTask) },
                            onEdit = { onNavigateToEditBlock(nextTask) },
                            onDelete = { viewModel.deleteBlock(nextTask) },
                            onComplete = { sessionToComplete = nextTask },
                            onDuplicate = { viewModel.addBlock(nextTask.copy(id = 0)) },
                            onUpdate = { viewModel.updateBlock(it) }
                        )
                        Spacer(modifier = Modifier.height(16.dp))
                    }
                }

                // Middle: Today's schedule cards only
                val otherUpcoming = upcomingTasks.filter { it.id != nextTask?.id }
                if (otherUpcoming.isNotEmpty()) {
                    item { SectionHeader("Today's Schedule", Icons.Default.Schedule, MaterialTheme.colorScheme.primary) }
                    items(otherUpcoming) { block ->
                        TaskCard(
                            block = block,
                            timeFormat = timeFormat,
                            onClick = { onNavigateToDetails(block) },
                            onEdit = { onNavigateToEditBlock(block) },
                            onDelete = { viewModel.deleteBlock(block) },
                            onComplete = { sessionToComplete = block },
                            onDuplicate = { viewModel.addBlock(block.copy(id = 0)) },
                            onUpdate = { viewModel.updateBlock(it) }
                        )
                    }
                }
                
                if (missedTasks.isNotEmpty()) {
                    item { SectionHeader("Missed", Icons.Default.Refresh, MaterialTheme.colorScheme.error) }
                    items(missedTasks) { block ->
                        TaskCard(
                            block = block,
                            timeFormat = timeFormat,
                            isMissed = true,
                            onClick = { onNavigateToDetails(block) },
                            onEdit = { onNavigateToEditBlock(block) },
                            onDelete = { viewModel.deleteBlock(block) },
                            onComplete = { sessionToComplete = block },
                            onActionClick = { onNavigateToDetails(block) },
                            onDuplicate = { viewModel.addBlock(block.copy(id = 0)) },
                            onUpdate = { viewModel.updateBlock(it) }
                        )
                    }
                }
                
                if (skippedTasks.isNotEmpty()) {
                    item { SectionHeader("Skipped", Icons.Default.Block, Color(0xFFFF9800)) }
                    items(skippedTasks) { block ->
                        TaskCard(
                            block = block,
                            timeFormat = timeFormat,
                            isSkipped = true,
                            onClick = { onNavigateToDetails(block) },
                            onEdit = { onNavigateToEditBlock(block) },
                            onDelete = { viewModel.deleteBlock(block) },
                            onComplete = {},
                            onDuplicate = { viewModel.addBlock(block.copy(id = 0)) },
                            onUpdate = { viewModel.updateBlock(it) }
                        )
                    }
                }
                if (completedTasks.isNotEmpty()) {
                    item { SectionHeader("Completed", Icons.Default.CheckCircle, MaterialTheme.colorScheme.tertiary) }
                    items(completedTasks) { block ->
                        TaskCard(
                            block = block,
                            timeFormat = timeFormat,
                            isCompleted = true,
                            onClick = { onNavigateToDetails(block) },
                            onEdit = { onNavigateToEditBlock(block) },
                            onDelete = { viewModel.deleteBlock(block) },
                            onComplete = {},
                            onDuplicate = { viewModel.addBlock(block.copy(id = 0)) },
                            onUpdate = { viewModel.updateBlock(it) }
                        )
                    }
                }
                if (todaysBlocks.isEmpty()) {
                    item {
                        Column(
                            modifier = Modifier.fillMaxWidth().padding(32.dp),
                            horizontalAlignment = Alignment.CenterHorizontally
                        ) {
                            Icon(Icons.Default.CheckCircle, contentDescription = "No tasks", modifier = Modifier.size(64.dp), tint = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.5f))
                            Spacer(modifier = Modifier.height(16.dp))
                            Text("No tasks scheduled for today.", style = MaterialTheme.typography.bodyLarge, color = MaterialTheme.colorScheme.onSurfaceVariant)
                            Spacer(modifier = Modifier.height(8.dp))
                            Button(onClick = onNavigateToAutoSchedule) {
                                Text("Auto Schedule")
                            }
                        }
                    }
                }

                
                item { Spacer(modifier = Modifier.height(80.dp)) }
            }
        }
    }

    if (showCustomizeDialog) {
        CustomizeDashboardDialog(
            currentOrder = cardOrder,
            currentEnabled = cardEnabled,
            onDismiss = { showCustomizeDialog = false },
            onSave = { newOrder, newEnabled ->
                cardOrder = newOrder
                cardEnabled = newEnabled
                sharedPref.edit().apply {
                    putString("card_order", newOrder.joinToString(","))
                    newEnabled.forEach { (k, v) -> putBoolean("card_enabled_$k", v) }
                }.apply()
                showCustomizeDialog = false
            }
        )
    }

    }
}
    }


@Composable
fun SectionHeader(title: String, icon: androidx.compose.ui.graphics.vector.ImageVector, color: Color) {
    Row(verticalAlignment = Alignment.CenterVertically) {
        Icon(icon, contentDescription = null, tint = color, modifier = Modifier.size(20.dp))
        Spacer(modifier = Modifier.width(8.dp))
        Text(title, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold, color = color)
    }
}

@OptIn(ExperimentalFoundationApi::class)
@Composable
fun TaskCard(
    block: TimeBlock,
    timeFormat: SimpleDateFormat,
    isRunning: Boolean = false,
    isMissed: Boolean = false,
    isSkipped: Boolean = false,
    isCompleted: Boolean = false,
    onClick: () -> Unit,
    onEdit: () -> Unit,
    onActionClick: (() -> Unit)? = null,
    onDelete: () -> Unit,
    onComplete: () -> Unit,
    onDuplicate: () -> Unit,
    onPin: () -> Unit = {},
    onUpdate: ((TimeBlock) -> Unit)? = null
) {
    val durationMs = block.endTimeMs - block.startTimeMs
    val hasAnyReminder = block.reminderBeforeStart || block.notifyStart || block.notifyDuring || block.notifyEnd
    val durationMinutes = durationMs / (1000 * 60)
    
    val containerColor = when {
        isSkipped -> Color(0xFFFF9800)
        isRunning -> Color(block.color)
        isCompleted -> Color(0xFF2E7D32).copy(alpha = 0.8f) // Farming green
        isMissed -> MaterialTheme.colorScheme.errorContainer.copy(alpha = 0.5f)
        else -> MaterialTheme.colorScheme.surface
    }
    
    val contentColor = when {
        isSkipped -> Color.White
        isRunning -> Color.White
        isCompleted -> Color.White.copy(alpha = 0.9f)
        isMissed -> MaterialTheme.colorScheme.onErrorContainer
        else -> MaterialTheme.colorScheme.onSurface
    }
    
    val shadowElevation = if (isRunning) 12.dp else 2.dp

    var showMenu by remember { mutableStateOf(false) }
    var confirmAction by remember { mutableStateOf<String?>(null) }
    
    if (confirmAction != null) {
        AlertDialog(
            onDismissRequest = { confirmAction = null },
            title = { Text("Are you sure?") },
            text = { Text("This action cannot be undone.") },
            confirmButton = {
                TextButton(onClick = {
                    when (confirmAction) {
                        "Complete" -> onComplete()
                        "Skip" -> if (onUpdate != null) onUpdate(block.copy(status = "Skipped"))
                        "Delete" -> onDelete()
                    }
                    confirmAction = null
                }) { Text("Confirm", color = MaterialTheme.colorScheme.primary, fontWeight = FontWeight.Bold) }
            },
            dismissButton = {
                TextButton(onClick = { confirmAction = null }) { Text("Cancel") }
            }
        )
    }

    
    
    Card(
        modifier = Modifier.fillMaxWidth().combinedClickable(onClick = onClick, onLongClick = { showMenu = true }),
        colors = CardDefaults.cardColors(containerColor = containerColor),
        elevation = CardDefaults.cardElevation(defaultElevation = shadowElevation),
        shape = RoundedCornerShape(20.dp)
    ) {
        Column(modifier = Modifier.padding(20.dp)) {
            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.weight(1f)) {
                    if (!isRunning && !isCompleted && !isMissed) {
                        Box(modifier = Modifier.size(12.dp).background(Color(block.color), shape = CircleShape))
                        Spacer(modifier = Modifier.width(12.dp))
                    }
                    Text(block.subject, style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold, color = contentColor, maxLines = 1, overflow = androidx.compose.ui.text.style.TextOverflow.Ellipsis)
                }
                
                Box {
                    if (isCompleted) {
                        Icon(Icons.Default.CheckCircle, contentDescription = "Completed", tint = contentColor)
                    } else {
                        IconButton(onClick = { showMenu = true }) {
                            Icon(Icons.Default.MoreVert, contentDescription = "More", tint = contentColor)
                        }
                    }
                    val onSkip = { if (onUpdate != null) onUpdate(block.copy(status = "Skipped")) }
                    DropdownMenu(expanded = showMenu, onDismissRequest = { showMenu = false }, properties = PopupProperties(focusable = true)) {
                        if (!isCompleted && !isMissed && !isSkipped) {
                            DropdownMenuItem(text = { Text("Edit") }, onClick = { showMenu = false; onEdit() })
                            DropdownMenuItem(text = { Text(if (block.isPinned) "Unpin" else "Pin") }, onClick = { showMenu = false; onPin() })
                            DropdownMenuItem(text = { Text("Skip") }, onClick = { showMenu = false; confirmAction = "Skip" })
                        }
                        DropdownMenuItem(text = { Text("Duplicate") }, onClick = { showMenu = false; onDuplicate() })
                        DropdownMenuItem(text = { Text("Delete", color = MaterialTheme.colorScheme.error) }, onClick = { showMenu = false; confirmAction = "Delete" })
                    }
                }
            }
            Spacer(modifier = Modifier.height(12.dp))

            var currentNow by remember { mutableStateOf(System.currentTimeMillis()) }
            LaunchedEffect(Unit) {
                while (true) {
                    currentNow = System.currentTimeMillis()
                    kotlinx.coroutines.delay(1000)
                }
            }

            val currentStatus = com.example.util.ScheduleStatusEngine.calculateStatus(block, currentNow)
            val isCurrentRunning = currentStatus == "Running" || currentStatus == "Waiting"
            val isCurrentCompleted = currentStatus == "Completed"
            
            val timeStudiedMs = block.actualTimeTakenMs ?: 0L
            
            val remainingMs = (durationMs - timeStudiedMs).coerceAtLeast(0L)
            val progress = if (durationMs > 0) (timeStudiedMs.toFloat() / durationMs.toFloat()).coerceIn(0f, 1f) else 0f
            
            val formatTaskTime = { ms: Long ->
                val hours = ms / 3600000
                val minutes = (ms / 60000) % 60
                if (hours > 0) String.format(Locale.getDefault(), "%02dh %02dm", hours, minutes)
                else String.format(Locale.getDefault(), "%02dm", minutes)
            }
            
            val scheduledStr = formatTaskTime(durationMs)
            val studiedStr = formatTaskTime(timeStudiedMs)
            val remainingStr = formatTaskTime(remainingMs)

            Spacer(modifier = Modifier.height(8.dp))
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Default.Schedule, contentDescription = null, tint = contentColor.copy(alpha = 0.7f), modifier = Modifier.size(16.dp))
                Spacer(modifier = Modifier.width(6.dp))
                Text("${timeFormat.format(Date(block.startTimeMs))} - ${timeFormat.format(Date(block.endTimeMs))}  |  Status: $currentStatus", style = MaterialTheme.typography.bodyMedium, color = contentColor.copy(alpha = 0.9f))
            }
            
            Spacer(modifier = Modifier.height(16.dp))
            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                Text("Scheduled: $scheduledStr", style = MaterialTheme.typography.labelMedium, color = contentColor.copy(alpha=0.8f))
                Text("Studied: $studiedStr", style = MaterialTheme.typography.labelMedium, color = contentColor.copy(alpha=0.8f))
                Text("Remaining: $remainingStr", style = MaterialTheme.typography.labelMedium, color = contentColor, fontWeight = FontWeight.Bold)
            }
            Spacer(modifier = Modifier.height(6.dp))
            LinearProgressIndicator(
                progress = { progress },
                modifier = Modifier.fillMaxWidth().height(8.dp).clip(RoundedCornerShape(4.dp)),
                color = contentColor,
                trackColor = contentColor.copy(alpha = 0.3f),
            )
            Spacer(modifier = Modifier.height(4.dp))
            Text("${(progress * 100).toInt()}%", style = MaterialTheme.typography.labelSmall, color = contentColor.copy(alpha=0.8f), modifier = Modifier.align(Alignment.End))

            
                        val studyAppsList = block.studyApps.split(",").filter { it.isNotEmpty() }
            if (studyAppsList.isNotEmpty()) {
                Spacer(modifier = Modifier.height(12.dp))
                Text("Study Apps", style = MaterialTheme.typography.labelLarge, color = contentColor, fontWeight = FontWeight.Bold)
                Spacer(modifier = Modifier.height(6.dp))
                
                val context = LocalContext.current
                val pm = context.packageManager
                
                studyAppsList.forEach { packageName ->
                    var appName by remember { mutableStateOf(packageName) }
                    var appIcon by remember { mutableStateOf<android.graphics.Bitmap?>(null) }
                    
                    LaunchedEffect(packageName) {
                        withContext(Dispatchers.IO) {
                            try {
                                val appInfo = pm.getApplicationInfo(packageName, 0)
                                val name = pm.getApplicationLabel(appInfo).toString()
                                val icon = pm.getApplicationIcon(appInfo).toBitmap(48, 48)
                                withContext(Dispatchers.Main) {
                                    appName = name
                                    appIcon = icon
                                }
                            } catch (e: Exception) {}
                        }
                    }
                    
                    Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.padding(start = 8.dp, top = 2.dp, bottom = 2.dp)) {
                        if (appIcon != null) {
                            Image(bitmap = appIcon!!.asImageBitmap(), contentDescription = null, modifier = Modifier.size(20.dp))
                        } else {
                            Icon(Icons.Default.PlayArrow, contentDescription = null, modifier = Modifier.size(20.dp), tint = contentColor.copy(alpha = 0.7f))
                        }
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(appName, style = MaterialTheme.typography.bodyMedium, color = contentColor.copy(alpha = 0.9f))
                    }
                }
            }
            
            // Reminders Section
            if (hasAnyReminder && onUpdate != null) {
                var expanded by remember { mutableStateOf(false) }
                Spacer(modifier = Modifier.height(12.dp))
                Row(
                    modifier = Modifier.fillMaxWidth().combinedClickable(onClick = { expanded = !expanded }),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(
                        if (expanded) Icons.Default.ArrowDropUp else Icons.Default.ArrowDropDown,
                        contentDescription = "Toggle Reminders",
                        tint = contentColor
                    )
                    Spacer(modifier = Modifier.width(4.dp))
                    Text("Reminders", style = MaterialTheme.typography.labelLarge, color = contentColor, fontWeight = FontWeight.Bold)
                }
                
                if (expanded) {
                    Spacer(modifier = Modifier.height(8.dp))
                    Column(modifier = Modifier.fillMaxWidth().padding(start = 12.dp)) {
                        ReminderCheckbox(label = "15 Minutes Before", checked = block.reminderBeforeStart, color = contentColor) {
                            onUpdate(block.copy(reminderBeforeStart = it))
                        }
                        ReminderCheckbox(label = "At Start Time", checked = block.notifyStart, color = contentColor) {
                            onUpdate(block.copy(notifyStart = it))
                        }
                        ReminderCheckbox(label = "During Study", checked = block.notifyDuring, color = contentColor) {
                            onUpdate(block.copy(notifyDuring = it))
                        }
                        ReminderCheckbox(label = "At End Time", checked = block.notifyEnd, color = contentColor) {
                            onUpdate(block.copy(notifyEnd = it))
                        }
                    }
                }
            }
        }
    }
    
    if (hasAnyReminder && !isRunning && !isCompleted && !isMissed) {
        Spacer(modifier = Modifier.height(8.dp))
        Card(
            modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer.copy(alpha=0.6f)),
            shape = RoundedCornerShape(12.dp)
        ) {
            Column(modifier = Modifier.padding(16.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Default.NotificationsActive, contentDescription = null, tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(16.dp))
                    Spacer(modifier = Modifier.width(8.dp))
                    Text("Notifications Enabled", style = MaterialTheme.typography.labelLarge, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary)
                }
                Spacer(modifier = Modifier.height(8.dp))
                if (block.reminderBeforeStart) Text("• 15 Minutes Before", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                if (block.notifyStart) Text("• At Start Time", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                if (block.notifyDuring) Text("• During Study", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                if (block.notifyEnd) Text("• At End Time", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
        }
    }
}

@Composable
fun ReminderCheckbox(label: String, checked: Boolean, color: Color, onCheckedChange: (Boolean) -> Unit) {
    Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.fillMaxWidth().padding(vertical = 4.dp)) {
        Checkbox(
            checked = checked,
            onCheckedChange = onCheckedChange,
            colors = CheckboxDefaults.colors(checkedColor = color, uncheckedColor = color.copy(alpha=0.5f), checkmarkColor = if (color == Color.White) Color.Black else Color.White)
        )
        Text(label, style = MaterialTheme.typography.bodyMedium, color = color)
    }
}


@Composable
fun EmptyStateView(onAddBlock: () -> Unit) {
    Column(modifier = Modifier.fillMaxSize(), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Center) {
        Box(modifier = Modifier.size(120.dp).background(MaterialTheme.colorScheme.primaryContainer, CircleShape), contentAlignment = Alignment.Center) {
            Icon(Icons.Default.Schedule, contentDescription = null, modifier = Modifier.size(64.dp), tint = MaterialTheme.colorScheme.onPrimaryContainer)
        }
        Spacer(modifier = Modifier.height(24.dp))
        Text("Your schedule is clear", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
        Spacer(modifier = Modifier.height(8.dp))
        Text("Add your first task and start focusing.", style = MaterialTheme.typography.bodyLarge, color = MaterialTheme.colorScheme.onSurfaceVariant)
        Spacer(modifier = Modifier.height(32.dp))
        Button(onClick = onAddBlock, modifier = Modifier.height(56.dp).padding(horizontal = 32.dp), shape = RoundedCornerShape(28.dp)) {
            Icon(Icons.Default.Add, contentDescription = null)
            Spacer(modifier = Modifier.width(8.dp))
            Text("Create Task", fontWeight = FontWeight.Bold)
        }
    }
}

@Composable
fun PremiumDashboardCard(
    modifier: Modifier = Modifier,
    title: String,
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    iconColor: Color = Color(0xFF38BDF8),
    onClick: () -> Unit = {},
    content: @Composable ColumnScope.() -> Unit
) {
    val gradientBrush = androidx.compose.ui.graphics.Brush.linearGradient(
        colors = listOf(
            Color(0xFF38BDF8).copy(alpha = 0.15f),
            Color(0xFF22D3EE).copy(alpha = 0.05f)
        )
    )
    Card(
        modifier = modifier
            .fillMaxWidth()
            .height(180.dp)
            .shadow(
                elevation = 16.dp,
                shape = RoundedCornerShape(24.dp),
                clip = false,
                ambientColor = Color(0xFF38BDF8).copy(alpha = 0.3f),
                spotColor = Color(0xFF38BDF8).copy(alpha = 0.5f)
            )
            .clickable(onClick = onClick),
        shape = RoundedCornerShape(24.dp),
        colors = CardDefaults.cardColors(containerColor = Color(0xFF1E293B)),
        border = BorderStroke(1.dp, Color(0xFF38BDF8).copy(alpha = 0.3f))
    ) {
        Box(
            modifier = Modifier
                .fillMaxSize()
                .background(gradientBrush)
        ) {
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(20.dp),
                verticalArrangement = Arrangement.SpaceBetween
            ) {
                // Header
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Box(
                            modifier = Modifier
                                .size(36.dp)
                                .background(
                                    color = Color(0xFF38BDF8).copy(alpha = 0.1f),
                                    shape = RoundedCornerShape(10.dp)
                                ),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                imageVector = icon,
                                contentDescription = null,
                                tint = iconColor,
                                modifier = Modifier.size(20.dp)
                            )
                        }
                        Spacer(modifier = Modifier.width(12.dp))
                        Text(
                            text = title,
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold,
                            color = Color.White
                        )
                    }
                    
                    Icon(
                        imageVector = Icons.Default.ChevronRight,
                        contentDescription = "View details",
                        tint = Color.White.copy(alpha = 0.4f),
                        modifier = Modifier.size(20.dp)
                    )
                }
                
                // Body content
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .weight(1f)
                        .padding(top = 12.dp, bottom = 4.dp),
                    verticalArrangement = Arrangement.Center
                ) {
                    content()
                }
            }
        }
    }
}
