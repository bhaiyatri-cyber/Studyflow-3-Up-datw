package com.example.ui.screens

import androidx.compose.animation.core.*
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.viewmodel.StudyViewModel
import com.example.data.model.TimeBlock
import com.example.data.model.DailyStats
import java.util.Calendar

val premiumSkyBlue = Color(0xFF38BDF8)

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ProgressScreen(
    viewModel: StudyViewModel,
    onNavigateBack: () -> Unit
) {
    val allBlocks by viewModel.allBlocks.collectAsState()
    val stats by viewModel.stats.collectAsState()
    
    // CALCULATE REAL DATA
    val now = System.currentTimeMillis()
    val calendar = Calendar.getInstance()
    calendar.timeInMillis = now
    calendar.set(Calendar.HOUR_OF_DAY, 0)
    calendar.set(Calendar.MINUTE, 0)
    calendar.set(Calendar.SECOND, 0)
    val startOfToday = calendar.timeInMillis
    
    val evaluatedBlocks = allBlocks.map { block ->
        block.copy(status = com.example.util.ScheduleStatusEngine.calculateStatus(block, now))
    }
    
    val completedBlocks = evaluatedBlocks.filter { it.status == "Completed" }
    
    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Progress & Analytics", fontWeight = FontWeight.Bold) },
                navigationIcon = {
                    IconButton(onClick = onNavigateBack) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back")
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = MaterialTheme.colorScheme.background
                )
            )
        }
    ) { padding ->
        if (completedBlocks.isEmpty()) {
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(padding)
                    .padding(32.dp),
                contentAlignment = Alignment.Center
            ) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Icon(
                        Icons.Default.Analytics,
                        contentDescription = null,
                        modifier = Modifier.size(64.dp),
                        tint = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.5f)
                    )
                    Spacer(modifier = Modifier.height(16.dp))
                    Text(
                        "No study sessions yet.",
                        style = MaterialTheme.typography.titleLarge,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.onSurface
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                    Text(
                        "Complete your first study session to unlock analytics.",
                        style = MaterialTheme.typography.bodyLarge,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        textAlign = TextAlign.Center
                    )
                }
            }
        } else {
            LazyColumn(
                modifier = Modifier
                    .padding(padding)
                    .fillMaxSize()
                    .background(MaterialTheme.colorScheme.background),
                contentPadding = PaddingValues(16.dp),
                verticalArrangement = Arrangement.spacedBy(24.dp)
            ) {
                val totalMins = completedBlocks.sumOf { (it.actualTimeTakenMs ?: 0L) } / 60000L
                val totalXP = (completedBlocks.size * 50) + totalMins.toInt()
                val currentLevel = (totalXP / 500) + 1
                val currentLevelXP = totalXP % 500
                val xpProgress = currentLevelXP.toFloat() / 500f
                val totalHours = totalMins / 60f
                
                val todaysBlocks = evaluatedBlocks.filter { it.startTimeMs >= startOfToday && it.startTimeMs < startOfToday + 24*3600*1000L }
                val todaysCompleted = todaysBlocks.count { it.status == "Completed" }
                val todaysTotal = todaysBlocks.size
                
                // TODAY'S FOCUS (Only if there are blocks today)
                if (todaysTotal > 0) {
                    item {
                        Column(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalAlignment = Alignment.CenterHorizontally
                        ) {
                            Text("Today's Focus", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold, modifier = Modifier.align(Alignment.Start))
                            Spacer(modifier = Modifier.height(16.dp))
                            AnimatedCircularProgress(
                                progress = todaysCompleted.toFloat() / todaysTotal,
                                label = "Tasks Completed",
                                valueText = "$todaysCompleted / $todaysTotal",
                                primaryColor = premiumSkyBlue,
                                modifier = Modifier.align(Alignment.CenterHorizontally)
                            )
                        }
                    }
                }
                
                // XP & LEVELS SYSTEM
                item {
                    Text("Your Level", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
                    Spacer(modifier = Modifier.height(16.dp))
                    Card(
                        modifier = Modifier.fillMaxWidth().shadow(8.dp, RoundedCornerShape(24.dp)),
                        shape = RoundedCornerShape(24.dp),
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
                    ) {
                        Column(modifier = Modifier.padding(24.dp)) {
                            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Box(
                                        modifier = Modifier.size(56.dp).background(MaterialTheme.colorScheme.primaryContainer, CircleShape),
                                        contentAlignment = Alignment.Center
                                    ) {
                                        Icon(Icons.Default.Stars, contentDescription = null, modifier = Modifier.size(32.dp), tint = MaterialTheme.colorScheme.onPrimaryContainer)
                                    }
                                    Spacer(modifier = Modifier.width(16.dp))
                                    Column {
                                        Text("Level $currentLevel", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
                                        Text("Scholar", style = MaterialTheme.typography.bodyMedium, color = premiumSkyBlue)
                                    }
                                }
                                Text("$currentLevelXP / 500 XP", style = MaterialTheme.typography.labelLarge, fontWeight = FontWeight.Bold)
                            }
                            Spacer(modifier = Modifier.height(24.dp))
                            AnimatedLinearProgress(progress = xpProgress, color = premiumSkyBlue)
                            Spacer(modifier = Modifier.height(8.dp))
                            Text("${500 - currentLevelXP} XP to Level ${currentLevel + 1}", style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        }
                    }
                }

                // WEEKLY TREND CHART
                item {
                    Text("Weekly Trend", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
                    Spacer(modifier = Modifier.height(16.dp))
                    Card(
                        modifier = Modifier.fillMaxWidth().shadow(8.dp, RoundedCornerShape(24.dp)),
                        shape = RoundedCornerShape(24.dp),
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
                    ) {
                        val realData = mutableListOf<Float>()
                        val labels = mutableListOf<String>()
                        val daysStr = listOf("Sun", "Mon", "Tue", "Wed", "Thu", "Fri", "Sat")
                        for (i in 6 downTo 0) {
                            val dStart = startOfToday - (i * 24 * 3600 * 1000L)
                            val dEnd = dStart + (24 * 3600 * 1000L)
                            val cal = Calendar.getInstance()
                            cal.timeInMillis = dStart
                            labels.add(daysStr[cal.get(Calendar.DAY_OF_WEEK) - 1])
                            
                            val dayBlocks = completedBlocks.filter { it.startTimeMs in dStart..dEnd }
                            val time = dayBlocks.sumOf { it.actualTimeTakenMs ?: 0L }
                            realData.add(time.toFloat() / (1000f * 3600f))
                        }
                        
                        Column(modifier = Modifier.padding(20.dp)) {
                            AnimatedBarChart(
                                data = realData,
                                labels = labels,
                                barColor = premiumSkyBlue
                            )
                        }
                    }
                }
                
                // Calculate streak for achievements and badges
                var currentStreak = 0
                val studyDays = completedBlocks.map { 
                    val c = Calendar.getInstance()
                    c.timeInMillis = it.startTimeMs
                    c.set(Calendar.HOUR_OF_DAY, 0)
                    c.set(Calendar.MINUTE, 0)
                    c.set(Calendar.SECOND, 0)
                    c.timeInMillis
                }.distinct().sortedDescending()
                
                if (studyDays.isNotEmpty()) {
                    currentStreak = 1
                    var previousDay = studyDays.first()
                    for (i in 1 until studyDays.size) {
                        if (previousDay - studyDays[i] <= 24 * 3600 * 1000L + 1000L) {
                            currentStreak++
                            previousDay = studyDays[i]
                        } else {
                            break
                        }
                    }
                }
                
                // LIFETIME ACHIEVEMENTS
                item {
                    val unlockedBadges = mutableListOf<Pair<String, Pair<ImageVector, Color>>>()
                    if (currentStreak >= 7) unlockedBadges.add("7 Day Streak" to Pair(Icons.Default.LocalFireDepartment, Color(0xFFFF9800)))
                    if (totalHours >= 100) unlockedBadges.add("100 Hours" to Pair(Icons.Default.AccessTime, premiumSkyBlue))
                    
                    val hasNightOwl = completedBlocks.any { 
                        val c = Calendar.getInstance()
                        c.timeInMillis = it.endTimeMs
                        c.get(Calendar.HOUR_OF_DAY) >= 22
                    }
                    if (hasNightOwl) unlockedBadges.add("Night Owl" to Pair(Icons.Default.NightsStay, Color(0xFF7C4DFF)))
                    
                    val hasEarlyBird = completedBlocks.any {
                        val c = Calendar.getInstance()
                        c.timeInMillis = it.startTimeMs
                        c.get(Calendar.HOUR_OF_DAY) < 8
                    }
                    if (hasEarlyBird) unlockedBadges.add("Early Bird" to Pair(Icons.Default.WbSunny, Color(0xFFFFC107)))
                    
                    if (unlockedBadges.isNotEmpty()) {
                        Text("Lifetime Achievements", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
                        Spacer(modifier = Modifier.height(16.dp))
                        Row(
                            modifier = Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()),
                            horizontalArrangement = Arrangement.spacedBy(16.dp)
                        ) {
                            unlockedBadges.forEach { badge ->
                                AchievementBadge(badge.first, badge.second.first, badge.second.second)
                            }
                        }
                    }
                }
                
                // SMART INSIGHTS
                item {
                    val dayMap = completedBlocks.groupBy { 
                        val c = Calendar.getInstance()
                        c.timeInMillis = it.startTimeMs
                        c.get(Calendar.DAY_OF_WEEK)
                    }
                    val bestDayIndex = dayMap.maxByOrNull { it.value.sumOf { b -> b.actualTimeTakenMs ?: 0L } }?.key ?: 1
                    val daysOfWeekStr = listOf("Sun", "Mon", "Tue", "Wed", "Thu", "Fri", "Sat")
                    val bestDay = daysOfWeekStr[bestDayIndex - 1]
                    
                    val hourMap = completedBlocks.groupBy { 
                        val c = Calendar.getInstance()
                        c.timeInMillis = it.startTimeMs
                        c.get(Calendar.HOUR_OF_DAY)
                    }
                    val bestHour = hourMap.maxByOrNull { it.value.sumOf { b -> b.actualTimeTakenMs ?: 0L } }?.key ?: 12
                    val bestHourStr = if (bestHour == 0) "12 AM" else if (bestHour < 12) "$bestHour AM" else if (bestHour == 12) "12 PM" else "${bestHour-12} PM"
                    
                    val subjectsMap = completedBlocks.groupBy { it.subject }
                    val subjectStats = subjectsMap.map { (subject, blocks) ->
                        val timeMs = blocks.sumOf { it.actualTimeTakenMs ?: 0L }
                        val allSubjBlocks = evaluatedBlocks.filter { it.subject == subject }
                        val compCount = allSubjBlocks.count { it.status == "Completed" }
                        val missedCount = allSubjBlocks.count { it.status == "Missed" }
                        val completionRate = if (compCount + missedCount > 0) compCount.toFloat() / (compCount + missedCount) else 0f
                        SubjectStat(subject, timeMs, blocks.size, if (blocks.isNotEmpty()) timeMs / blocks.size else 0L, completionRate)
                    }.sortedByDescending { it.timeMs }
                    
                    val strongestSubject = subjectStats.firstOrNull()?.name ?: "None"
                    val weakestSubject = subjectStats.lastOrNull()?.name ?: "None"

                    Text("Smart Insights", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
                    Spacer(modifier = Modifier.height(16.dp))
                    Card(
                        modifier = Modifier.fillMaxWidth().shadow(8.dp, RoundedCornerShape(24.dp)),
                        shape = RoundedCornerShape(24.dp),
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer)
                    ) {
                        Column(modifier = Modifier.padding(24.dp)) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(Icons.Default.Insights, contentDescription = null, tint = MaterialTheme.colorScheme.onPrimaryContainer)
                                Spacer(modifier = Modifier.width(12.dp))
                                Text("Your Focus Trends", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.onPrimaryContainer)
                            }
                            Spacer(modifier = Modifier.height(20.dp))
                            InsightRow(Icons.Default.CalendarToday, "Best Study Day", bestDay)
                            InsightRow(Icons.Default.Schedule, "Most Productive Time", bestHourStr)
                            InsightRow(Icons.Default.Warning, "Weakest Subject", weakestSubject)
                            InsightRow(Icons.AutoMirrored.Filled.TrendingUp, "Strongest Subject", strongestSubject)
                        }
                    }
                    
                    Spacer(modifier = Modifier.height(24.dp))
                    
                    // SUBJECT ANALYTICS
                    Text("Subject Analytics", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
                    Spacer(modifier = Modifier.height(16.dp))
                    subjectStats.forEach { stat ->
                        Card(
                            modifier = Modifier.fillMaxWidth().padding(bottom = 12.dp),
                            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                            elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
                        ) {
                            Column(modifier = Modifier.padding(16.dp)) {
                                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                                    Text(stat.name, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                                    Text(String.format("%.1f hrs", stat.timeMs / 3600000f), style = MaterialTheme.typography.titleMedium, color = premiumSkyBlue, fontWeight = FontWeight.Bold)
                                }
                                Spacer(modifier = Modifier.height(12.dp))
                                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                                    Column {
                                        Text("Sessions", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                        Text("${stat.sessions}", style = MaterialTheme.typography.bodyLarge, fontWeight = FontWeight.Bold)
                                    }
                                    Column {
                                        Text("Avg. Session", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                        Text("${stat.avgDuration / 60000L}m", style = MaterialTheme.typography.bodyLarge, fontWeight = FontWeight.Bold)
                                    }
                                    Column {
                                        Text("Completion", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                        Text("${(stat.completionRate * 100).toInt()}%", style = MaterialTheme.typography.bodyLarge, fontWeight = FontWeight.Bold)
                                    }
                                }
                            }
                        }
                    }
                }
                
                // GOAL TRACKING
                item {
                    val dailyGoalHours = stats?.dailyStudyHourGoal?.toFloat() ?: 4f
                    val dailyGoalMs = (dailyGoalHours * 3600 * 1000L).toLong()
                    val weeklyGoalMs = dailyGoalMs * 5 // Weekly goal is 5x daily
                    val monthlyGoalMs = dailyGoalMs * 20 // Monthly goal is 20x daily
                    
                    val todayCompletedMs = completedBlocks.filter { it.startTimeMs >= startOfToday }.sumOf { it.actualTimeTakenMs ?: 0L }
                    val weekCompletedMs = completedBlocks.filter { it.startTimeMs >= startOfToday - 7L*24*3600*1000 }.sumOf { it.actualTimeTakenMs ?: 0L }
                    val monthCompletedMs = completedBlocks.filter { it.startTimeMs >= startOfToday - 30L*24*3600*1000 }.sumOf { it.actualTimeTakenMs ?: 0L }
                    
                    val dailyProgress = (todayCompletedMs.toFloat() / dailyGoalMs).coerceIn(0f, 1f)
                    val weeklyProgress = (weekCompletedMs.toFloat() / weeklyGoalMs).coerceIn(0f, 1f)
                    val monthlyProgress = (monthCompletedMs.toFloat() / monthlyGoalMs).coerceIn(0f, 1f)

                    Text("Goal Tracking", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
                    Spacer(modifier = Modifier.height(16.dp))
                    GoalCard("Daily Goal (${dailyGoalHours.toInt()}h)", dailyProgress, "${String.format("%.1f", todayCompletedMs/3600000f)} / ${dailyGoalHours.toInt()} hrs")
                    Spacer(modifier = Modifier.height(12.dp))
                    GoalCard("Weekly Goal (${(dailyGoalHours*5).toInt()}h)", weeklyProgress, "${String.format("%.1f", weekCompletedMs/3600000f)} / ${(dailyGoalHours*5).toInt()} hrs")
                    Spacer(modifier = Modifier.height(12.dp))
                    GoalCard("Monthly Goal (${(dailyGoalHours*20).toInt()}h)", monthlyProgress, "${String.format("%.1f", monthCompletedMs/3600000f)} / ${(dailyGoalHours*20).toInt()} hrs")
                    
                    Spacer(modifier = Modifier.height(24.dp))
                    
                    // MILESTONE BADGES
                    Text("Milestone Badges", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
                    Spacer(modifier = Modifier.height(16.dp))
                    Card(
                        modifier = Modifier.fillMaxWidth().shadow(4.dp, RoundedCornerShape(24.dp)),
                        shape = RoundedCornerShape(24.dp),
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
                    ) {
                        Column(modifier = Modifier.padding(20.dp)) {
                            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                                PremiumBadgeItem(icon = Icons.AutoMirrored.Filled.DirectionsWalk, label = "First Step", isUnlocked = completedBlocks.isNotEmpty(), progress = if (completedBlocks.isNotEmpty()) 1f else 0f)
                                PremiumBadgeItem(icon = Icons.Default.LocalFireDepartment, label = "7 Day Streak", isUnlocked = currentStreak >= 7, progress = (currentStreak / 7f).coerceIn(0f, 1f))
                                PremiumBadgeItem(icon = Icons.Default.AccessTimeFilled, label = "100 Hours", isUnlocked = totalHours >= 100, progress = (totalHours / 100f).coerceIn(0f, 1f))
                            }
                            Spacer(modifier = Modifier.height(24.dp))
                            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                                PremiumBadgeItem(icon = Icons.Default.Star, label = "Master", isUnlocked = totalHours >= 500, progress = (totalHours / 500f).coerceIn(0f, 1f))
                                PremiumBadgeItem(icon = Icons.Default.CheckCircle, label = "Daily Goal", isUnlocked = dailyProgress >= 1f, progress = dailyProgress)
                                PremiumBadgeItem(icon = Icons.Default.DateRange, label = "Weekly Goal", isUnlocked = weeklyProgress >= 1f, progress = weeklyProgress)
                            }
                        }
                    }
                }
                
                // ACTIVITY MAP
                item {
                    Text("Activity Map", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
                    Spacer(modifier = Modifier.height(16.dp))
                    Card(
                        modifier = Modifier.fillMaxWidth().shadow(8.dp, RoundedCornerShape(24.dp)),
                        shape = RoundedCornerShape(24.dp),
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
                    ) {
                        Column(modifier = Modifier.padding(20.dp)) {
                            val data = mutableListOf<HeatmapDay>()
                            for (i in 29 downTo 0) {
                                val dStart = startOfToday - (i * 24 * 3600 * 1000L)
                                val dEnd = dStart + (24 * 3600 * 1000L)
                                val dayBlocks = completedBlocks.filter { it.startTimeMs in dStart..dEnd }
                                val time = dayBlocks.sumOf { it.actualTimeTakenMs ?: 0L }
                                val intensity = when {
                                    time == 0L -> 0
                                    time < 1 * 3600 * 1000L -> 1
                                    time < 2 * 3600 * 1000L -> 2
                                    time < 4 * 3600 * 1000L -> 3
                                    else -> 4
                                }
                                data.add(HeatmapDay(dStart, intensity, time))
                            }
                            PremiumHeatmap(data)
                        }
                    }
                }
            }
        }
    }
}

data class SubjectStat(val name: String, val timeMs: Long, val sessions: Int, val avgDuration: Long, val completionRate: Float)
data class HeatmapDay(val dateMs: Long, val intensity: Int, val timeMs: Long)

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun PremiumHeatmap(data: List<HeatmapDay>) {
    val primary = premiumSkyBlue
    FlowRow(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.Start,
        maxItemsInEachRow = 10
    ) {
        data.forEach { day ->
            val color = when (day.intensity) {
                0 -> MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f)
                1 -> primary.copy(alpha = 0.3f)
                2 -> primary.copy(alpha = 0.6f)
                3 -> primary.copy(alpha = 0.8f)
                else -> primary
            }
            Box(
                modifier = Modifier
                    .padding(4.dp)
                    .size(24.dp)
                    .clip(RoundedCornerShape(4.dp))
                    .background(color)
            )
        }
    }
}

@Composable
fun AnimatedLinearProgress(progress: Float, color: Color) {
    var animationPlayed by remember { mutableStateOf(false) }
    val currentProgress by animateFloatAsState(
        targetValue = if (animationPlayed) progress else 0f,
        animationSpec = tween(durationMillis = 1500),
        label = "progress"
    )
    LaunchedEffect(key1 = true) { animationPlayed = true }
    
    Box(modifier = Modifier.fillMaxWidth().height(8.dp).clip(CircleShape).background(color.copy(alpha = 0.2f))) {
        Box(modifier = Modifier.fillMaxWidth(currentProgress.coerceAtLeast(0.01f)).height(8.dp).clip(CircleShape).background(color))
    }
}

@Composable
fun AchievementBadge(title: String, icon: ImageVector, color: Color) {
    Card(
        modifier = Modifier
            .size(100.dp)
            .shadow(4.dp, RoundedCornerShape(16.dp)),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.3f)),
        shape = RoundedCornerShape(16.dp)
    ) {
        Column(
            modifier = Modifier.fillMaxSize().padding(8.dp),
            verticalArrangement = Arrangement.Center,
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Icon(icon, contentDescription = null, tint = color, modifier = Modifier.size(32.dp))
            Spacer(modifier = Modifier.height(8.dp))
            Text(title, style = MaterialTheme.typography.labelMedium, fontWeight = FontWeight.Bold, textAlign = TextAlign.Center)
        }
    }
}

@Composable
fun PremiumBadgeItem(icon: ImageVector, label: String, isUnlocked: Boolean, progress: Float) {
    var animationPlayed by remember { mutableStateOf(false) }
    val currentProgress by animateFloatAsState(
        targetValue = if (animationPlayed) progress else 0f,
        animationSpec = tween(durationMillis = 1500),
        label = "badge"
    )
    LaunchedEffect(key1 = true) { animationPlayed = true }
    
    Column(horizontalAlignment = Alignment.CenterHorizontally, modifier = Modifier.width(80.dp)) {
        Box(
            modifier = Modifier.size(64.dp),
            contentAlignment = Alignment.Center
        ) {
            val surfaceVar = MaterialTheme.colorScheme.surfaceVariant
            Canvas(modifier = Modifier.fillMaxSize()) {
                drawArc(
                    color = surfaceVar,
                    startAngle = 0f, sweepAngle = 360f, useCenter = false,
                    style = Stroke(width = 6.dp.toPx(), cap = StrokeCap.Round)
                )
                if (currentProgress > 0) {
                    drawArc(
                        color = premiumSkyBlue,
                        startAngle = -90f, sweepAngle = currentProgress * 360f, useCenter = false,
                        style = Stroke(width = 6.dp.toPx(), cap = StrokeCap.Round)
                    )
                }
            }
            Box(
                modifier = Modifier
                    .size(48.dp)
                    .clip(CircleShape)
                    .background(if (isUnlocked) MaterialTheme.colorScheme.primaryContainer else MaterialTheme.colorScheme.surfaceVariant.copy(alpha=0.5f)),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    icon,
                    contentDescription = null,
                    modifier = Modifier.size(24.dp),
                    tint = if (isUnlocked) MaterialTheme.colorScheme.onPrimaryContainer else MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        }
        Spacer(modifier = Modifier.height(8.dp))
        Text(
            label,
            style = MaterialTheme.typography.labelSmall,
            color = if (isUnlocked) MaterialTheme.colorScheme.onSurface else MaterialTheme.colorScheme.onSurfaceVariant,
            textAlign = TextAlign.Center
        )
    }
}

@Composable
fun InsightRow(icon: ImageVector, label: String, value: String) {
    Row(
        modifier = Modifier.fillMaxWidth().padding(vertical = 8.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Icon(icon, contentDescription = null, modifier = Modifier.size(20.dp), tint = MaterialTheme.colorScheme.onPrimaryContainer.copy(alpha = 0.8f))
            Spacer(modifier = Modifier.width(12.dp))
            Text(label, style = MaterialTheme.typography.bodyLarge, color = MaterialTheme.colorScheme.onPrimaryContainer)
        }
        Text(value, style = MaterialTheme.typography.bodyLarge, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.onPrimaryContainer)
    }
}

@Composable
fun GoalCard(title: String, progress: Float, valueStr: String) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                Text(title, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                Text(valueStr, style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
            Spacer(modifier = Modifier.height(12.dp))
            AnimatedLinearProgress(progress = progress, color = MaterialTheme.colorScheme.secondary)
            Spacer(modifier = Modifier.height(8.dp))
            if (progress >= 1f) {
                Text("Goal Completed!", style = MaterialTheme.typography.labelMedium, color = premiumSkyBlue, fontWeight = FontWeight.Bold)
            } else {
                Text("${(progress * 100).toInt()}% completed", style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
        }
    }
}

