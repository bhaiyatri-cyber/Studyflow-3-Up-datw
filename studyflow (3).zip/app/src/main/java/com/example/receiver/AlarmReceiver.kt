package com.example.receiver

import android.app.NotificationChannel
import android.app.NotificationManager
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.os.Build
import android.util.Log
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import com.example.R
import android.app.PendingIntent
import com.example.MainActivity
import android.content.pm.PackageManager
import androidx.core.content.ContextCompat

class AlarmReceiver : BroadcastReceiver() {
    companion object {
        const val ACTION_START_TASK = "com.example.ACTION_START_TASK"
        const val ACTION_REMINDER_START = "com.example.ACTION_REMINDER_START"
        const val ACTION_REMINDER_DURING = "com.example.ACTION_REMINDER_DURING"
        const val ACTION_REMINDER_END = "com.example.ACTION_REMINDER_END"
        const val ACTION_END_TASK = "com.example.ACTION_END_TASK"

        const val EXTRA_TASK_ID = "EXTRA_TASK_ID"
        const val EXTRA_TASK_NAME = "EXTRA_TASK_NAME"
        const val EXTRA_TASK_END_TIME = "EXTRA_TASK_END_TIME"

        private const val CHANNEL_ID = "study_flow_channel"
    }

    override fun onReceive(context: Context, intent: Intent) {
        val action = intent.action
        val taskId = intent.getIntExtra(EXTRA_TASK_ID, -1)
        val taskName = intent.getStringExtra(EXTRA_TASK_NAME) ?: "Task"
        val taskEndTime = intent.getLongExtra(EXTRA_TASK_END_TIME, -1L)

        Log.d("AlarmReceiver", "Received alarm: $action for task: $taskName")

        createNotificationChannel(context)

        val mainIntent = Intent(context, MainActivity::class.java).apply {
            flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK
        }
        
        val sharedPref = context.getSharedPreferences("studyflow_prefs", Context.MODE_PRIVATE)
        val popupMode = sharedPref.getBoolean("popup_mode", false)

        val pendingIntent = PendingIntent.getActivity(
            context, 0, mainIntent, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        val builder = NotificationCompat.Builder(context, CHANNEL_ID)
            .setSmallIcon(R.drawable.ic_notification)
            .setContentIntent(pendingIntent)
            .setAutoCancel(true)
            .setPriority(NotificationCompat.PRIORITY_HIGH)
            
        val notificationId = taskId + action.hashCode()
        
        val completeIntent = Intent(context, ActionReceiver::class.java).apply {
            this.action = ActionReceiver.ACTION_COMPLETE_TASK
            putExtra(ActionReceiver.EXTRA_TASK_ID, taskId)
            putExtra(ActionReceiver.EXTRA_NOTIFICATION_ID, notificationId)
        }
        val completePendingIntent = PendingIntent.getBroadcast(
            context, taskId + 1000, completeIntent, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        
        val skipIntent = Intent(context, ActionReceiver::class.java).apply {
            this.action = ActionReceiver.ACTION_SKIP_TASK
            putExtra(ActionReceiver.EXTRA_TASK_ID, taskId)
            putExtra(ActionReceiver.EXTRA_NOTIFICATION_ID, notificationId)
        }
        val skipPendingIntent = PendingIntent.getBroadcast(
            context, taskId + 2000, skipIntent, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        when (action) {
            ACTION_REMINDER_START -> {
                builder.setContentTitle("Upcoming: $taskName")
                    .setContentText("Starts in 10 minutes.")
                    .apply { if (popupMode) setFullScreenIntent(pendingIntent, true) }
                    .addAction(0, "Skip", skipPendingIntent)
            }
            ACTION_START_TASK -> {
                try {
                    val serviceIntent = Intent(context, com.example.service.TaskForegroundService::class.java).apply {
                        this.action = com.example.service.TaskForegroundService.ACTION_START
                        putExtra(com.example.service.TaskForegroundService.EXTRA_TASK_ID, taskId)
                        putExtra(com.example.service.TaskForegroundService.EXTRA_TASK_NAME, taskName)
                        putExtra(com.example.service.TaskForegroundService.EXTRA_START_TIME, System.currentTimeMillis()) // or the actual start time if we had it
                        putExtra(com.example.service.TaskForegroundService.EXTRA_END_TIME, taskEndTime)
                    }
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                        context.startForegroundService(serviceIntent)
                    } else {
                        context.startService(serviceIntent)
                    }
                } catch (e: Exception) {
                    Log.e("AlarmReceiver", "Failed to start FGS", e)
                }

                NotificationManagerCompat.from(context).cancel(taskId + ACTION_REMINDER_START.hashCode())
                builder.setContentTitle("Now: $taskName")
                    .setContentText("Time to focus!")
                    .setOngoing(true)
                    .setAutoCancel(false)
                    .addAction(0, "Complete", completePendingIntent)
                
                if (taskEndTime > System.currentTimeMillis()) {
                    builder.setUsesChronometer(true)
                    builder.setWhen(taskEndTime)
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) {
                        builder.setChronometerCountDown(true)
                    }
                }
            }
            
            ACTION_REMINDER_DURING -> {
                builder.setContentTitle("Keep it up: $taskName")
                    .setContentText("You are halfway there!")
                    .apply { if (popupMode) setFullScreenIntent(pendingIntent, true) }
            }
            ACTION_REMINDER_END -> {
                builder.setContentTitle("Wrapping up: $taskName")
                    .setContentText("Ends in 10 minutes.")
                    .addAction(0, "Complete", completePendingIntent)
            }
            ACTION_END_TASK -> {
                try {
                    val serviceIntent = Intent(context, com.example.service.TaskForegroundService::class.java).apply {
                        this.action = com.example.service.TaskForegroundService.ACTION_STOP
                    }
                    context.stopService(Intent(context, com.example.service.TaskForegroundService::class.java))
                } catch(e: Exception) {}

                NotificationManagerCompat.from(context).cancel(taskId + ACTION_REMINDER_END.hashCode())
                NotificationManagerCompat.from(context).cancel(taskId + ACTION_START_TASK.hashCode())
                builder.setContentTitle("Completed: $taskName")
                    .setContentText("Great job!")
                    .addAction(0, "Mark Done", completePendingIntent)
            }
        }

        if (ContextCompat.checkSelfPermission(context, android.Manifest.permission.POST_NOTIFICATIONS) == PackageManager.PERMISSION_GRANTED) {
            with(NotificationManagerCompat.from(context)) {
                notify(notificationId, builder.build())
            }
        }
    }

    private fun createNotificationChannel(context: Context) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val name = "StudyFlow Notifications"
            val descriptionText = "Notifications for study tasks and reminders"
            val importance = NotificationManager.IMPORTANCE_HIGH
            val channel = NotificationChannel(CHANNEL_ID, name, importance).apply {
                description = descriptionText
            }
            val notificationManager: NotificationManager =
                context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
            notificationManager.createNotificationChannel(channel)
        }
    }
}
