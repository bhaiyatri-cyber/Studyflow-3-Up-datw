package com.example.util

import com.example.data.model.TimeBlock

object ScheduleStatusEngine {
    fun calculateStatus(block: TimeBlock, currentTimestampMs: Long): String {
        if (block.status == "Completed" || block.status == "Skipped" || block.status == "Missed") {
            return block.status
        }
        
        if (currentTimestampMs < block.startTimeMs) {
            return "Upcoming"
        }
        
        if (currentTimestampMs >= block.startTimeMs && currentTimestampMs < block.endTimeMs) {
            if (block.status == "Running") return "Running"
            if (block.status == "Paused") return "Paused"
            
            val hasStarted = (block.actualTimeTakenMs ?: 0L) > 0L
            if (hasStarted) return "Paused"
            
            return "Waiting"
        }
        
        if (currentTimestampMs >= block.endTimeMs) {
            val graceMs = 5 * 60 * 1000L // 5 mins grace
            if (currentTimestampMs < block.endTimeMs + graceMs) {
                if (block.status == "Running") return "Running"
                if (block.status == "Paused") return "Paused"
                return "Waiting"
            }
            return "Missed"
        }
        
        return block.status
    }
}
